const fs=require('fs'),vm=require('vm');let tot=0,conf=0;
for(const f of fs.readdirSync('js').filter(f=>/^questionBank_/.test(f))){
  const c={};vm.createContext(c);vm.runInContext(fs.readFileSync('js/'+f,'utf8')+';this.Q=questionBank;this.H=typeof hotsQuestions!=="undefined"?hotsQuestions:[]',c);
  const m=new Map();for(const q of c.Q){const k=q.question.trim().toLowerCase().replace(/\s+/g,' ');(m.get(k)||m.set(k,[]).get(k)).push(q)}
  const d=[...m.values()].filter(a=>a.length>1);let same=0,diff=[];
  for(const a of d){const t=a.map(q=>q.options[q.answer].trim().toLowerCase());if(new Set(t).size===1)same++;else diff.push(a.map(q=>q.id+':'+q.options[q.answer].slice(0,40)))}
  if(d.length)console.log(f.replace('questionBank_','').padEnd30||'',f.replace('questionBank_',''),'dup groups',d.length,'same-answer',same,'CONFLICT',diff.length,diff.length?JSON.stringify(diff.slice(0,3)):'');
  tot+=d.length;conf+=diff.length;
}
console.log('groups',tot,'conflicting',conf);
