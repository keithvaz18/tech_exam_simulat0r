const fs=require('fs'),vm=require('vm');
const h=fs.readFileSync('index.html','utf8'),ex=fs.readFileSync('exam.html','utf8');
const files={};for(const m of ex.matchAll(/'([A-Za-z_0-9]+)':\s*\{[^}]*file:\s*'js\/([^']+)'/g))files[m[1]]=m[2];
const bank={};function B(f){if(!bank[f]){const c={};vm.createContext(c);vm.runInContext(fs.readFileSync('js/'+f,'utf8')+';this.Q=questionBank;this.H=(typeof hotsQuestions==="undefined")?[]:hotsQuestions',c);bank[f]=c;}return bank[f];}
let low=0,clouds=0;
for(const m of h.matchAll(/renderCloud\("(\w+)",\s*([\w\[\]\.\s,]+?),\s*"(\w+)"\)/g)){
  const arr=m[2].trim(),type=m[3];if(!files[type])continue;
  const s=h.indexOf('const '+arr+' ='),e=h.indexOf('];',s);if(s<0)continue;clouds++;
  const words=[...h.slice(s,e).matchAll(/(?:word|text)\s*:\s*"([^"]+)"/g)].map(x=>x[1]);
  const Q=B(files[type]).Q;
  const bad=words.filter(w=>Q.filter(q=>(q.question+' '+(q.category||'')+' '+q.explanation).toLowerCase().includes(w.toLowerCase())).length<2);
  if(bad.length){low+=bad.length;console.log(type,arr,'LOW:',bad)}
}
for(const [t,f] of Object.entries(files)){const c=B(f);const ids=new Set(c.Q.map(q=>q.id));const ok=new Set(c.H.filter(i=>ids.has(i))).size;if(c.H.length&&ok<100)console.log('HOTS LOW',t,ok)}
console.log('clouds checked',clouds,'keywords below 2 matches',low);
