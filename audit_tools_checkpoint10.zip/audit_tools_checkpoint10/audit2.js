const fs=require('fs');const a=require('/home/claude/audit.json');
let tz=0,tl=0;for(const r of Object.values(a)){if(!r.zero)continue;tz+=r.zero.length;tl+=r.low.length;}
console.log('zero total',tz,'low total',tl);
// domain classes
const html=fs.readFileSync('index.html','utf8');const css=fs.readFileSync('css/styles.css','utf8')+html;
const doms=new Set();for(const r of Object.values(a))(r.domains||[]).forEach(d=>doms.add(d));
const miss=[...doms].filter(d=>!new RegExp('\\.'+d.replace(/[-]/g,'\\-')+'\\b').test(css));
console.log('domains without CSS:',miss);
