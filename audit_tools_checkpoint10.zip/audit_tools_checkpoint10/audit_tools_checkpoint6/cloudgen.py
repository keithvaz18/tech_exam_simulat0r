import json,subprocess,re,sys
C={
'ai_data':('saAiDataKeywords','aiData','SA AI & Data Technologies','claude_sa','#38bdf8',{
 'ai':['RAG','LLM','Agentic','Embedding','Vector','Fine-tuning','Hallucination','Guardrails','Prompt Injection','MLOps','Feature Store','Responsible AI','Model Serving','LangGraph'],
 'lakehouse':['Lakehouse','Medallion','Delta Lake','Databricks','Snowflake','Unity Catalog','Auto Loader','Photon','Spark','Data Mesh','Data Lineage'],
 'platform':['Kafka','Streaming','Event-Driven','High Availability','Observability','Cost Optimization','Kubernetes','Multi-Region','Disaster Recovery','Data Residency'],
 'governance':['Governance','Purview','RBAC','Encryption','Compliance','Zero Trust','Stakeholder','TCO']}),
'python_pySpark':('pythonPySparkKeywords','py','Python & PySpark','py','#facc15',{
 'core':['GIL','Decorator','Generator','Iterator','Comprehension','Lambda','Closure','Context Manager','Dataclass','Mutable','Type Hints','Exception','Metaclass','Garbage Collection','Recursion'],
 'concurrency':['Asyncio','Threading','Multiprocessing','Coroutine'],
 'spark':['Spark','PySpark','DataFrame','RDD','Shuffle','Broadcast','Partition','Lazy Evaluation','UDF','Catalyst','Window','Cache'],
 'algorithms':['Big O','Binary Search','Heap','Hash Map','Sorting','Dynamic Programming','Stack','Queue']}),
'sql':('sqlKeywords','sq','SQL','sq','#38bdf8',{
 'query':['Join','Subquery','CTE','Recursive','Window Function','RANK','DENSE_RANK','LAG','GROUP BY','HAVING','UNION','NULL','PIVOT','MERGE'],
 'performance':['Index','Covering Index','Clustered','Execution Plan','SARGable','Partition','Statistics','Query Optimizer'],
 'transactions':['Transaction','ACID','Deadlock','Isolation Level','NOLOCK','Locking','Cursor'],
 'design':['Normalization','Denormalization','Primary Key','Foreign Key','Constraint','Trigger','View','Stored Procedure','Star Schema']}),
'nodejs':('nodeKeywords','nj','Node.js','nj','#84cc16',{
 'runtime':['Event Loop','libuv','V8','Garbage Collection','Memory Leak','Microtask','nextTick','Buffer','Worker Threads','Cluster','Child Process'],
 'async':['Promise','async/await','Callback','EventEmitter','Streams','Backpressure'],
 'web':['Express','Middleware','REST','WebSocket','CORS','Rate Limiting','JWT','Helmet','Graceful Shutdown'],
 'ops':['npm','PM2','Heap Snapshot','Profiling','Docker']}),
'JavaScript':('jsKeywords','js','JavaScript','js','#facc15',{
 'core':['Closure','Hoisting','Prototype','this','Temporal Dead Zone','Strict Mode','Symbol','Proxy','Generator','Destructuring','Spread','Currying'],
 'async':['Event Loop','Promise','async/await','Callback','Fetch','Debounce','Throttle'],
 'data':['Map','Set','WeakMap','Shallow Copy','Deep Copy','Immutable','Memoization'],
 'web':['REST','Versioning','CORS','Event Delegation','LocalStorage','Module','ES6']}),
'dotnet':('dotnetKeywords','dn','.NET & C#','dn','#a78bfa',{
 'language':['LINQ','Async','Delegate','Generics','Record','Span','Task','IDisposable','Nullable'],
 'runtime':['CLR','JIT','Garbage Collection','Kestrel','Docker'],
 'web':['Middleware','Dependency Injection','Minimal API','Blazor','SignalR','gRPC','Razor','Health Checks'],
 'data':['Entity Framework','Dapper','Migration','Transaction'],
 'architecture':['Microservices','SOLID','Polly','JWT','Identity','CQRS','Clean Architecture']}),
'ai_arch':('aiArchKeywords','aar','AI Architecture','aar','#f472b6',{
 'ai':['RAG','Vector Database','LangGraph','Guardrails','Fine-tuning','Model Serving','Prompt Injection','LLMOps','Context Distillation','GPU','Token'],
 'platform':['Kubernetes','Service Mesh','Karpenter','CSI','Traffic Shifting','Canary','Multi-Region','Circuit Breaker'],
 'security':['mTLS','Zero Trust','OIDC','Secrets Management','Data Residency','OWASP'],
 'ops':['Observability','Latency','Throughput','Savings Plans','Distributed Tracing']}),
'hl7':('hl7Keywords','hl','HL7 & FHIR','hl','#34d399',{
 'v2':['ADT','ORU','ORM','SIU','MSH','PID','OBX','Segment','Acknowledgment','MLLP','Z-segment','A01'],
 'fhir':['FHIR','Resource','Bundle','Patient','Observation','Encounter','Profile','SMART on FHIR','REST'],
 'docs':['CDA','C-CDA','LOINC','SNOMED','Terminology'],
 'integration':['Interface Engine','Mirth','OAuth','HIPAA']})}
import os
os.chdir('proj')
js=r"""
const fs=require('fs'),vm=require('vm');const f=process.argv[2];const words=JSON.parse(process.argv[3]);
const c={};vm.createContext(c);vm.runInContext(fs.readFileSync(f,'utf8')+';this.Q=questionBank',c);
console.log(JSON.stringify(words.map(w=>c.Q.filter(q=>q.question.toLowerCase().includes(w.toLowerCase())||(q.category&&q.category.toLowerCase().includes(w.toLowerCase()))||(q.explanation&&q.explanation.toLowerCase().includes(w.toLowerCase()))).length)));"""
open('/tmp/cnt.js','w').write(js)
files={'ai_data':'SA_AI_Data_Technologies','python_pySpark':'python_pySpark','sql':'SQL','nodejs':'nodeJS','JavaScript':'JavaScript','dotnet':'dotnet','ai_arch':'AI_Arch','hl7':'HL7'}
out={}
for ex,(arr,pre,title,cls,col,doms) in C.items():
    words=[w for d in doms.values() for w in d]
    r=json.loads(subprocess.check_output(['node','/tmp/cnt.js','js/questionBank_%s.js'%files[ex],json.dumps(words)]))
    cnt=dict(zip(words,r)); kept=[];drop=[]
    for d,ws in doms.items():
        for w in ws:
            (kept if cnt[w]>=2 else drop).append((w,d,cnt[w]))
    out[ex]=dict(kept=kept,drop=drop)
    print(ex,'kept',len(kept),'dropped',[(w,n) for w,d,n in drop])
json.dump({'C':{k:list(v[:5]) for k,v in C.items()},'out':out},open('/tmp/cloud_sel.json','w'))
