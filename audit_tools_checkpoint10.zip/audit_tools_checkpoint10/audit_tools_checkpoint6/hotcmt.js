const fs=require('fs'),vm=require('vm');
const files=fs.readFileSync('exam.html','utf8');
const tok=s=>new Set((s.toLowerCase().match(/[a-z]{4,}/g)||[]));
for(const x of files.matchAll(/'(\w+)':\s*\{ title: '([^']*)', file: '([^']*)'/g)){
  const src=fs.readFileSync(x[3],'utf8');
  const c={};vm.createContext(c);
  vm.runInContext(src+';this.QB=questionBank;',c);const qb=c.QB;
  const hs=src.indexOf('hotsQuestions');if(hs<0){console.log(x[1],'no hots');continue}
  const lines=src.slice(hs).split('\n');let n=0,idxHit=0,idHit=0,idxNext=0;
  for(const l of lines){const m=l.match(/^\s*(\d+)\s*,?\s*\/\/\s*(.+)$/);if(!m)continue;n++;
    const v=+m[1],ct=tok(m[2]);
    const sc=q=>{if(!q)return 0;const t=tok(q.question+' '+(q.category||''));let k=0;ct.forEach(w=>{if(t.has(w))k++});return k};
    const byIdx=sc(qb[v]),byId=sc(qb.find(q=>q.id===v));
    if(byIdx>byId)idxHit++;else if(byId>byIdx)idHit++;}
  console.log(x[1].padEnd(20),'commented',n,'matches-by-index',idxHit,'matches-by-id',idHit);
}
