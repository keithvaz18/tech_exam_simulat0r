import json,re,subprocess,os
os.chdir('proj')
A={ # array: (bank file, [(word, domain)])
'dbKeywords':('databricks',[('Delta Table','delta'),('Metastore','governance'),('Airflow','tools'),('ADF','tools'),('Databricks SQL','workspace'),('Parquet','delta'),('DataFrame','spark'),('Delta Live Tables','streaming'),('S3','tools'),('Unity Catalog','governance'),('Auto Loader','streaming'),('Z-ORDER','performance')]),
'aiKeywords':('AI',[('LLM','infra'),('GPU','infra'),('MLOps','ops'),('Few-Shot','optim'),('Inference','infra'),('Transformer','infra'),('OpenAI','agent'),('Retrieval','rag'),('Prompt Engineering','optim'),('Fine-tuning','optim'),('Hallucination','eval')]),
'javaKeywords':('Java',[('Docker','spring-build'),('Kubernetes','spring-runtime'),('JVM','spring-runtime'),('Redis','spring-data'),('Java 21','spring-runtime'),('JSON','spring-api'),('Batch','spring-build'),('Garbage Collection','spring-runtime'),('Virtual Threads','spring-runtime')]),
'azKeywords':('Azure',[('Azure Policy','az-gov'),('Azure Advisor','az-gov'),('Front Door','az-net'),('VPN','az-net'),('Firewall','az-security'),('Application Gateway','az-net'),('Blob','az-data'),('Cosmos DB','az-data'),('Virtual Machines','az-compute'),('SQL Database','az-data'),('App Service','az-compute'),('Azure Monitor','az-gov'),('Key Vault','az-security'),('Entra ID','az-identity'),('ExpressRoute','az-net')]),
'awsKeywords':('AWS',[('AWS Config','aws-sec'),('Direct Connect','aws-net'),('EBS','aws-core'),('CloudFormation','aws-core'),('Inspector','aws-sec'),('Trusted Advisor','aws-cost'),('Peering','aws-net'),('Aurora','aws-db'),('GuardDuty','aws-sec'),('Route 53','aws-net'),('CloudTrail','aws-obs')]),
'mgKeywords':('mongoDB',[('Replica Set','mg-arch'),('Sharding','mg-arch'),('Aggregation','mg-crud'),('Index','mg-perf'),('Atlas Search','mg-atlas'),('Change Streams','mg-crud'),('Transaction','mg-crud'),('Schema Design','mg-arch')]),
'rKeywords':('react',[('useMemo','r-hooks'),('useRef','r-hooks'),('useReducer','r-hooks'),('useCallback','r-hooks'),('useContext','r-hooks'),('React.memo','r-perf'),('Re-render','r-perf'),('CSS','r-core'),('React 18','r-core'),('Virtual DOM','r-core'),('Redux','r-state'),('Reconciliation','r-perf')]),
'snKeywords':('snowflake',[('Streams','sn-services'),('Tasks','sn-services'),('Materialized Views','sn-compute'),('Stages','sn-storage'),('Masking Policies','sn-core'),('Query Acceleration','sn-compute'),('Dynamic Tables','sn-services'),('Cloud Services','sn-core'),('Replication','sn-core'),('Metadata','sn-core'),('Time Travel','sn-storage'),('Snowpark','sn-services'),('Iceberg','sn-storage'),('Clustering','sn-compute')]),
'kfKeywords':('kafka',[('ACLs','kf-ops'),('ISR','kf-core'),('SSL','kf-ops'),('Confluent','kf-connect'),('Producer','kf-core'),('Partition','kf-core'),('Offset','kf-core'),('Replication','kf-core'),('Schema Registry','kf-connect'),('Kafka Connect','kf-connect'),('Kafka Streams','kf-stream'),('Rebalance','kf-ops'),('Retention','kf-ops'),('Compaction','kf-core'),('Exactly-once','kf-stream'),('KRaft','kf-core')]),
'dataArchitectKeywords':('Data_Arch',[('HBase','architecture'),('Iceberg','architecture'),('Kafka','streaming'),('Real-time','streaming'),('Delta Lake','architecture'),('ETL','ingestion'),('ELT','ingestion'),('OLAP','analytics')]),
'devOpsKeywords':('devOps',[('VPC','devops-network'),('VNet','devops-network'),('Pod','devops-k8s'),('Kubernetes','devops-k8s'),('Helm','devops-k8s'),('Terraform','devops-iac'),('Prometheus','devops-obs'),('GitOps','devops-cicd'),('ArgoCD','devops-cicd')]),
'typescriptNestjsKeywords':('typescript_nestjs',[('Module','architecture'),('Injectable','architecture'),('Middleware','architecture'),('Controller','architecture'),('Node.js','compute'),('Omit','data'),('Decorator','architecture'),('Dependency Injection','architecture'),('Guard','security'),('Pipe','architecture'),('Interceptor','architecture'),('DTO','data'),('TypeORM','data')]),
'web3BlockChainKeywords':('web3Blockchain',[('Ethereum','wb-core'),('Solidity','wb-tooling'),('MEV','wb-security'),('Mining','wb-infrastructure'),('Bitcoin','wb-core'),('DAO','wb-defi'),('Solana','wb-infrastructure'),('RWA','wb-defi'),('Cross-chain','wb-infrastructure'),('NFT','wb-core'),('EVM','wb-tooling'),('Gas','wb-core'),('On-chain','wb-core'),('Off-chain','wb-core'),('Optimistic','wb-infrastructure'),('Rollup','wb-infrastructure'),('Smart Contract','wb-core'),('Consensus','wb-core'),('Oracle','wb-infrastructure')]),
}
h=open('index.html').read()
def span(h,name):
    m=re.search(r'^const %s = \['%name,h,re.M);i=h.index('[',m.start());d=0
    for j in range(i,len(h)):
        if h[j]=='[':d+=1
        elif h[j]==']':
            d-=1
            if d==0:return i,j
def fq(n): return 5 if n>=40 else 4 if n>=20 else 3 if n>=10 else 2 if n>=5 else 1
rep=[]
for name,(bank,items) in A.items():
    i,j=span(h,name);body=h[i:j]
    have={w.lower() for w in re.findall(r'word:\s*"([^"]+)"',body)}
    cand=[(w,d) for w,d in items if w.lower() not in have]
    if not cand: continue
    cnt=json.loads(subprocess.check_output(['node','/tmp/cnt.js','js/questionBank_%s.js'%bank,json.dumps([w for w,_ in cand])]))
    keep=[(w,d,n) for (w,d),n in zip(cand,cnt) if n>=3]
    nums=[int(x) for x in re.findall(r'(?:freq|weight):\s*(\d+)',body)];mx=max(nums+[5])
    uses_weight=name=='web3BlockChainKeywords';uses_class=uses_weight;nodesc=name=='javaKeywords'
    lines=[]
    for w,d,n in keep:
        v=max(1,round(fq(n)/5*mx))
        if uses_weight: lines.append('    { word: %s, weight: %d, class: "%s" }'%(json.dumps(w),v,d))
        elif nodesc: lines.append('    { word: %s, freq: %d, domain: "%s" }'%(json.dumps(w),v,d))
        else: lines.append('    {word:%s, freq:%d, domain:"%s", desc:%s}'%(json.dumps(w),v,d,json.dumps('%d practice questions'%n)))
    skipped=[(w,n) for (w,d),n in zip(cand,cnt) if n<3]
    print(name,'added',len(keep),'skipped',skipped)
    if lines:
        i,j=span(h,name);body=h[i:j];k=body.rstrip()
        add=('' if k.endswith(',') or k.endswith('[') else ',')+'\n    // --- Reverse-check additions (bank-backed) ---\n'+',\n'.join(lines)+'\n'
        h=h[:i]+k+add+h[j:]
open('index.html','w').write(h)
