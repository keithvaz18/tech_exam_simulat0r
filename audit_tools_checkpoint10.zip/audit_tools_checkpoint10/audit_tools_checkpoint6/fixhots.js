const fs=require('fs'),vm=require('vm');
const rank={hard:0,medium:1,easy:2};
for(const f of process.argv.slice(2)){
  const p='js/questionBank_'+f+'.js';let src=fs.readFileSync(p,'utf8');
  const c={};vm.createContext(c);
  vm.runInContext(src+';this.Q=questionBank;this.H=hotsQuestions;',c);
  const Q=c.Q,ids=new Set(Q.map(q=>q.id)),byId=new Map(Q.map(q=>[q.id,q]));
  let keep=[...new Set(c.H.filter(i=>ids.has(i)))];
  const have=new Set(keep);
  // pool: remaining questions, hard first, round-robin across categories
  const pools={};
  Q.filter(q=>!have.has(q.id)).sort((a,b)=>(rank[a.difficulty]??1)-(rank[b.difficulty]??1)||a.id-b.id)
   .forEach(q=>{(pools[q.category||'x']=pools[q.category||'x']||[]).push(q.id)});
  const cats=Object.keys(pools);let added=[];
  while(keep.length+added.length<100&&cats.some(k=>pools[k].length))
    for(const k of cats){if(keep.length+added.length>=100)break;if(pools[k].length)added.push(pools[k].shift());}
  const all=[...keep,...added];
  const i=src.search(/const\s+hotsQuestions\s*=\s*\[/);
  const body='const hotsQuestions = [\n    // Existing curated entries (valid ids kept)\n    '+keep.join(', ')+',\n\n    // Added: hardest questions, spread across categories\n    '+added.join(', ')+'\n];\n';
  src=src.slice(0,i)+body;
  fs.writeFileSync(p,src);
  console.log(f,'kept',keep.length,'added',added.length,'total',all.length);
}
