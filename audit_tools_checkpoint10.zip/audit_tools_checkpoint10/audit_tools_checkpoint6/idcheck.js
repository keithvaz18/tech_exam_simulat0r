const fs=require('fs'),vm=require('vm');
const files=fs.readFileSync('exam.html','utf8');
for(const x of files.matchAll(/'(\w+)':\s*\{ title: '([^']*)', file: '([^']*)'/g)){
  const c={};vm.createContext(c);
  vm.runInContext(fs.readFileSync(x[3],'utf8')+';this.QB=questionBank;this.HOT=typeof hotsQuestions!=="undefined"?hotsQuestions:null;',c);
  const qb=c.QB,h=c.HOT;
  const offs={};qb.forEach((q,i)=>{const o=q.id-i;offs[o]=(offs[o]||0)+1});
  const ids=qb.map(q=>q.id);const minId=Math.min(...ids),maxId=Math.max(...ids);
  const hmin=h?Math.min(...h):null,hmax=h?Math.max(...h):null;
  const hotInIds=h?h.filter(i=>ids.includes(i)).length:null;
  const hotInIdx=h?h.filter(i=>qb[i]!==undefined).length:null;
  console.log(x[1].padEnd(20),'ids',minId+'..'+maxId,'offsets',JSON.stringify(offs).slice(0,60),'hot',h?h.length:'-',h?`range ${hmin}..${hmax} inIds ${hotInIds} inIdx ${hotInIdx}`:'');
}
