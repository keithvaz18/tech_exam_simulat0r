import json,re,subprocess
sel=json.load(open('/tmp/cloud_sel.json'));C=sel['C'];out=sel['out']
files={'ai_data':'SA_AI_Data_Technologies','python_pySpark':'python_pySpark','sql':'SQL','nodejs':'nodeJS','JavaScript':'JavaScript','dotnet':'dotnet','ai_arch':'AI_Arch','hl7':'HL7'}
pal=['#2563EB','#7C3AED','#10b981','#f59e0b','#e11d48','#0ea5e9','#14b8a6','#64748b']
h=open('proj/index.html').read()
css='\n        /* CLOUD DOMAIN COLORS (generated) */\n';arrs='';sections=''
render='';bind=''
def freq(n): return 5 if n>=40 else 4 if n>=20 else 3 if n>=10 else 2 if n>=5 else 1
for ex,(arr,pre,title,cls,col)in C.items():
    kept=out[ex]['kept'];doms=[]
    for w,d,n in kept:
        if d not in doms:doms.append(d)
    cl={d:'%s-%s'%(pre,d) for d in doms}
    for i,d in enumerate(doms): css+='        .%s { background: %s; }\n'%(cl[d],pal[i%len(pal)])
    arrs+='const %s = [\n%s\n];\n\n'%(arr,",\n".join('{word:%s, freq:%d, domain:"%s", desc:%s}'%(json.dumps(w),freq(n),cl[d],json.dumps('%d practice questions'%n)) for w,d,n in kept))
    leg=''.join('<span class="%s">%s</span>'%(cl[d],d.replace('_',' ').title()) for d in doms)
    cid='%s-cloud'%ex;sid=pre+'Search';cd=pre+'Cloud'
    if ex=='ai_data':
        h,n1=re.subn(r'(<div id="ai_data-cloud".*?<div class="legend">).*?(</div>)',lambda m:m.group(1)+leg+m.group(2),h,count=1,flags=re.S)
        assert n1==1
        h=h.replace('renderCloud("aiDataCloud", dataArchitectKeywords, "ai_data");','renderCloud("aiDataCloud", saAiDataKeywords, "ai_data");')
        h=h.replace('bindSearch("aiDataSearch", "aiDataCloud", dataArchitectKeywords, "ai_data");','bindSearch("aiDataSearch", "aiDataCloud", saAiDataKeywords, "ai_data");')
        assert 'saAiDataKeywords, "ai_data"' in h
        continue
    sections+='''
<div id="%s" class="cloud-section" style="background:#0f172a; color:white;">
    <h2 class="doc-header" data-doc="%s" style="color:%s;cursor:pointer;">%s Cloud</h2>
    <div class="search-box"><input id="%s" placeholder="Search %s keywords..." style="background:#1e293b; color:white;"></div>
    <div class="cloud-display" id="%s"></div>
    <div class="legend">%s</div>
</div>
'''%(cid,cid,col,title,sid,title,cd,leg)
    render+='        renderCloud("%s", %s, "%s");\n'%(cd,arr,ex)
    bind+='        bindSearch("%s", "%s", %s, "%s");\n'%(sid,cd,arr,ex)
h=h.replace("        .legend { margin-top: 20px;",css+"        .legend { margin-top: 20px;",1)
h=h.replace('const dataArchitectKeywords = [',arrs+'const dataArchitectKeywords = [',1)
m='<div id="mongodb-cloud"';assert m in h;h=h.replace(m,sections+m,1)
a='        renderCloud("dbCloud", dbKeywords, "databricks");';assert a in h;h=h.replace(a,render+a,1)
b='        bindSearch("dbSearch", "dbCloud", dbKeywords, "databricks");';assert b in h;h=h.replace(b,bind+b,1)
if '"python_pySpark-cloud"' not in h:
    h=h.replace('  "react-cloud": {','  "python_pySpark-cloud": {\n    file: "docs/python_test_readme.md",\n    title: "Python & PySpark Guide"\n  },\n  "react-cloud": {',1)
open('proj/index.html','w').write(h)
print('patched',len(h))
