Q = []
def q(d, c, text, ok, wrong, ex): Q.append((d, c, text, ok, wrong, ex))
q("medium","Spring Boot","Which statement about dependency injection in Spring is correct?",
  "The IoC Container injects collaborators so classes depend on abstractions instead of constructing dependencies themselves",
  ["Classes must call new for every dependency", "Injection only works with XML", "Injection is a Hibernate feature"],
  "IoC Container: constructor injection is preferred because it makes dependencies explicit and testable.")
q("hard","Spring Boot","A logging aspect needs to run on a private method and on object construction inside a plain Java object. Which technology can do this?",
  "AspectJ with compile-time or load-time weaving, because Proxy-based AOP only intercepts external calls to Spring bean methods",
  ["Spring AOP with JDK proxies", "Spring Data JPA", "Spring MVC interceptors"],
  "AspectJ: weaves advice into bytecode. Proxy-based AOP, used by Spring AOP, cannot advise private methods or constructors.")
q("medium","ORM/Hibernate","A team defines interface OrderRepository extends CrudRepository<Order, Long> and calls save(). Who writes the implementation?",
  "Spring Data generates it at runtime",
  ["The developer must write it", "Hibernate generates a class at build time only", "The database does"],
  "CRUDRepository: Spring Data provides the implementation from the interface. Transaction Management wraps the repository calls in transactions by default.")
q("medium","Microservices","Where do services fetch their properties from in a Spring Cloud Config setup?",
  "From a Config Server that serves properties stored in Git or another backend",
  ["From a sibling microservice's memory", "From the load balancer", "From the browser"],
  "Config Server: central endpoint for externalized properties; clients load them at startup and can refresh them at runtime.")
q("hard","Microservices","An API must allow at most 100 requests per second per client. Which Resilience4j component fits?",
  "A Rate Limiter",
  ["A Bulkhead", "A Circuit Breaker only", "A Retry with backoff"],
  "Rate Limiter: limits calls over a time period, unlike Bulkhead (concurrency) or Retry (repeat failed calls).")
q("medium","Message Queues","A Spring service uses RabbitTemplate to publish to an exchange. Which library is this?",
  "Spring AMQP",
  ["Spring Kafka", "Spring Batch", "Spring Data MongoDB"],
  "Spring AMQP: the Spring integration for AMQP brokers, offering listener containers and RabbitAdmin.")
q("hard","WebFlux","Why can WebFlux handle many concurrent connections with few threads?",
  "It relies on Non-Blocking I/O with an event loop, so threads are not parked waiting on I/O",
  ["It uses a thread per request", "It disables the network stack", "It buffers every request in a database"],
  "Non-Blocking I/O: threads handle events as data is ready. Blocking calls inside a reactive pipeline defeat this benefit.")
q("easy","REST API","Which dependency family adds an interactive API explorer to a Spring Boot REST service?",
  "springdoc-openapi, producing OpenAPI/Swagger documentation",
  ["spring-boot-starter-batch", "spring-kafka", "logback-classic"],
  "OpenAPI/Swagger: describes endpoints, parameters and models and renders a UI for trying them.")
q("medium","Microservices","How does a Feign Client differ from calling RestTemplate manually?",
  "You declare an annotated interface and Spring generates the HTTP client implementation",
  ["It is a database driver", "It only works with SOAP", "It requires no network"],
  "Feign Client: a declarative approach for service-to-service REST calls, often combined with service discovery and circuit breaking.")
q("hard","Security","Which pairing correctly describes centralized identity and fine-grained authorization in a Spring Boot system?",
  "Keycloak issues OIDC tokens, and Method Security with @PreAuthorize enforces roles inside the service",
  ["Keycloak stores Hibernate entities and @PreAuthorize runs SQL", "Both are caching tools", "Both only apply to the front end"],
  "Keycloak: the identity provider. Method Security: enforces RBAC annotations in application code using the token's authorities.")
