Q = []
def q(d, c, text, ok, wrong, ex): Q.append((d, c, text, ok, wrong, ex))
AG,AP,EV,MO,PC,SE,TM = "agents-workflows","applications-integration","eval-debugging","model-optimization","prompt-context","security-safety","tools-mcp"
q("medium",AG,"A weekly report is generated from a fixed pipeline, but a separate research assistant must decide which sources to open. Which labels fit?",
  "The report is a workflow; the research assistant is an agent",
  ["Both are agents", "Both are workflows", "The report is an agent; the assistant is a workflow"],
  "Workflow vs Agent: predefined steps are a workflow, model-directed exploration is an agent. A Batch API job can run the fixed workflow overnight at lower cost.")
q("medium",AP,"A client library gets 429 responses and also intermittently calls via a plain REST + JSON request. Which behavior is correct?",
  "Honor the retry-after header and back off; treat 429 as a Rate Limits condition, not a bad request",
  ["Retry instantly", "Switch to a different endpoint", "Drop the request silently"],
  "Rate Limits 429: retry with backoff. REST + JSON clients must implement this themselves, whereas official SDKs retry automatically by default.")
q("medium",AP,"You package shared commands and hooks as a plugin and also run Claude through a cloud vendor's platform. What do you verify in each case?",
  "Pin plugin versions and dependencies, and confirm model IDs and feature support on the third-party platform",
  ["Nothing", "Only the cloud region", "Only the plugin name"],
  "Plugins: dependencies and versions are part of configuration management. Third-Party Providers: model identifiers and features may differ from the first-party API.")
q("easy",AP,"A cron job runs Claude Code unattended. Which flag makes that possible?",
  "-p, for headless print mode",
  ["--interactive", "--stdin-wait", "--ui"],
  "Headless -p: non-interactive mode that prints the answer and exits. The cron job can add --output-format json for machine-readable results.")
q("medium",MO,"For a high-volume simple extraction job, a team picks the largest model with maximum thinking by default. What is a better approach?",
  "Pick the smallest tier that meets quality targets (often Haiku or Sonnet over Opus) and use lower effort levels, validated by evals",
  ["Always use the largest model", "Avoid evals", "Use Opus only for short prompts"],
  "Opus / Sonnet / Haiku: choose by capability, latency and cost. Effort Levels: lower effort cuts cost and latency when quality allows.")
q("hard",MO,"A prompt contains stable tool definitions, a long guideline document and a per-request question. How should it be arranged for cache hits?",
  "Tools and guidelines first, a cache breakpoint after them, then the per-request question",
  ["Question first", "Random order", "Timestamp first"],
  "Cache Breakpoint: stable prefix before volatile content. System vs User placement also matters, since system content is typically stable while user content varies.")
q("hard",PC,"Model output is fed to a downstream billing system. Which two measures are most important?",
  "Defensive parsing with schema validation, and enforcing authorization server-side rather than trusting the model's claims",
  ["Trusting fluent output", "Longer prompts", "Raising temperature"],
  "Defensive Parsing: validate before acting. Server-Side Authz: the application, not the prompt, decides who may do what.")
q("hard",SE,"A support bot redacts card numbers before prompting the model, then lets Claude decide whether the caller may view an account. What is wrong?",
  "Redaction is good, but access decisions must be enforced in server-side code, not left to the model",
  ["Nothing is wrong", "Redaction should be removed", "Authorization belongs in the system prompt"],
  "PII Redaction: reduces exposure. Server-Side Authz: authentication and authorization are enforced by your application.")
q("medium",TM,"A tool named search and another named lookup have one-line descriptions. Calls are misrouted. Which pair of improvements helps?",
  "Detailed Tool Descriptions with boundaries, and consolidating duplicates or renaming to remove overlap",
  ["Shorter descriptions", "More similar names", "Removing schemas"],
  "Tool Descriptions: explain purpose, inputs, outputs and when to prefer each tool. Fix overlap by renaming or splitting.")
q("medium",TM,"Which pair of statements is correct?",
  "Server tools run on the provider's platform while client tools run in your app, and stdio MCP servers are local while HTTP ones can be remote",
  ["Client tools run on the provider; stdio servers are always remote", "Both client and server tools run in the browser", "HTTP transport is local only"],
  "Client vs Server Tools: who executes the call. stdio vs HTTP: how an MCP server is reached, local subprocess versus network service.")
q("hard",TM,"Which scenario is best served by an MCP server rather than a Skill?",
  "Querying live inventory in an internal system that several Claude apps share",
  ["Teaching a house style for memos", "Documenting a checklist", "Storing a reusable prompt"],
  "Skills vs MCP: skills carry instructions and procedures loaded on demand; MCP exposes tools and data from live systems.")
