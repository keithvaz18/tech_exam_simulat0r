B = {}
def mk(name):
    L = []
    def q(d, c, text, ok, wrong, ex): L.append((d, c, text, ok, wrong, ex))
    B[name] = L
    return q

q = mk('SA_AI_Data_Technologies')
q("medium","architecture","Which controls belong in Guardrails for a production LLM application?",
  "Input and output filtering, topic and PII policies, and tool-permission limits applied outside the model",
  ["A longer system prompt only","Raising temperature","Disabling logging"],
  "Guardrails: layered, independent controls around the model (content filters, PII redaction, allow-listed tools) because prompts alone are probabilistic.")
q("hard","architecture","Why add Guardrails in addition to a well-written system prompt?",
  "Prompts can be bypassed by injection, so enforced checks on inputs, outputs and actions give defense in depth",
  ["Prompts are never read by the model","Guardrails make the model deterministic","Guardrails remove the need for evaluation"],
  "Guardrails complement prompts: enforcement outside the model limits the blast radius of jailbreaks and prompt injection.")
q("medium","architecture","What is the main purpose of a Feature Store in an ML platform?",
  "To share consistent, versioned features between training and online inference, avoiding training-serving skew",
  ["To store model weights only","To replace the data lake","To schedule clusters"],
  "Feature Store: central registry of computed features with offline and online access, lineage and point-in-time correctness.")
q("hard","architecture","A model performs well offline but poorly online because features are computed differently in each path. Which capability addresses this?",
  "A Feature Store that serves the same feature definitions for training and inference",
  ["A larger model","More epochs","A bigger cluster"],
  "Feature Store: one definition, two serving paths, which removes training-serving skew.")
q("medium","architecture","In the Medallion architecture, what distinguishes Gold tables from Silver?",
  "Gold holds business-level aggregates and marts for BI and ML, while Silver holds cleaned, conformed data",
  ["Gold stores raw files","Silver stores dashboards","They are identical"],
  "Medallion: Bronze raw, Silver validated, Gold curated for consumption, typically on Delta Lake.")
q("medium","databricks","What does Auto Loader provide for ingesting files from cloud storage?",
  "Incremental, checkpointed file discovery with schema inference and evolution (cloudFiles)",
  ["Manual file listing each run","Only batch full reloads","A SQL warehouse"],
  "Auto Loader: scalable incremental ingestion using file notification or directory listing with exactly-once checkpoints.")
q("hard","architecture","Which principle does Zero Trust apply to an AI data platform?",
  "Authenticate and authorize every request using identity and least privilege, regardless of network location",
  ["Trust traffic inside the VPC","Use one shared admin key","Disable MFA internally"],
  "Zero Trust: never trust, always verify, with segmentation, private endpoints and short-lived credentials.")
q("medium","architecture","Why does Zero Trust matter for LLM agents that call internal tools?",
  "Each tool call should be authorized with the caller's identity and scoped permissions, not assumed safe",
  ["Agents are always trusted","Network location grants access","Tools need no authentication"],
  "Zero Trust: an agent compromised by prompt injection must not inherit broad access.")
q("medium","architecture","Which design practice supports High Availability for a data platform?",
  "Redundancy across availability zones with automated failover and tested recovery",
  ["A single large node","Manual restarts","One availability zone only"],
  "High Availability: remove single points of failure, use health checks and automated failover, and define RTO and RPO.")
q("medium","architecture","Which levers reduce Cost Optimization risk for Databricks or Spark workloads?",
  "Right-size clusters, use autoscaling and spot capacity, auto-terminate idle compute and tune file layout",
  ["Keep clusters always running","Choose the largest node type","Disable autoscaling"],
  "Cost Optimization: match compute to workload, shut down idle resources, use job compute and monitor with tags and budgets.")
q("hard","architecture","A nightly job uses an always-on large cluster. What is the best first Cost Optimization step?",
  "Move it to job compute with autoscaling and auto-termination, and right-size from Spark UI metrics",
  ["Add more nodes","Disable monitoring","Run it hourly"],
  "Cost Optimization starts with eliminating idle spend and aligning compute with measured need.")
q("medium","architecture","What characterizes an Event-Driven architecture?",
  "Producers emit events to a broker and loosely coupled consumers react asynchronously",
  ["Synchronous chained RPC calls only","A shared database table polled hourly","A monolith with no messaging"],
  "Event-Driven design: Kafka or similar brokers decouple services, enabling replay, scaling and independent evolution.")
q("hard","architecture","Why choose an Event-Driven architecture for real-time analytics ingestion?",
  "It decouples producers from consumers and allows buffering, replay and independent scaling",
  ["It guarantees zero latency","It removes schemas","It avoids all duplicates automatically"],
  "Event-Driven pipelines use durable logs with consumer offsets; idempotent consumers handle at-least-once delivery.")
q("medium","architecture","What is a Hallucination in an LLM application, and how is it mitigated?",
  "Fluent but unsupported output; mitigate with RAG grounding, citations, evaluation and guardrails",
  ["A GPU error; reboot the node","A tokenizer bug","A database deadlock"],
  "Hallucination: the model asserts unsupported facts. Retrieval grounding and verification reduce, but do not eliminate, it.")
q("medium","architecture","What does MLOps add on top of building a model?",
  "Automated training, versioning, deployment, monitoring and retraining pipelines",
  ["Only notebook editing","Only GPU provisioning","Only SQL tuning"],
  "MLOps: CI/CD for ML with experiment tracking, a registry, drift monitoring and governance.")

q = mk('python_pySpark')
q("medium","python_core","What is a Closure in Python?",
  "A function that remembers variables from its enclosing scope even after that scope has finished",
  ["A function that closes files","A class with no methods","A syntax error"],
  "Closure: inner functions capture free variables; used in decorators and factories.")
q("hard","python_core","Why is a Mutable default argument such as def f(x=[]) dangerous?",
  "The default list is created once and shared across calls, so changes persist between calls",
  ["It is copied per call","It raises SyntaxError","It is garbage collected"],
  "Mutable defaults are evaluated at definition time; use None and create the list inside.")
q("medium","python_core","What do Type Hints do at runtime in standard CPython?",
  "They are not enforced by the interpreter; tools like mypy and IDEs use them for static checking",
  ["They enforce types at runtime","They make code faster","They are required"],
  "Type Hints: annotations documenting expected types, checked statically.")
q("easy","python_core","Which benefit do Type Hints provide to large codebases?",
  "Better tooling, earlier bug detection and clearer APIs",
  ["Automatic parallelism","Lower memory","No need for tests"],
  "Type Hints improve readability and static analysis without changing execution.")
q("medium","algorithms","What does Big O notation describe?",
  "How an algorithm's time or space grows with input size, ignoring constants",
  ["Exact seconds of runtime","The number of lines","Memory addresses"],
  "Big O: asymptotic upper bound used to compare algorithms, such as O(n) versus O(log n).")
q("hard","algorithms","What is the Big O of looking up a key in a Python dict on average?",
  "O(1) average, degrading in the worst case to O(n) with many collisions",
  ["O(log n) always","O(n) always","O(n log n)"],
  "Big O of hash lookups: average constant time due to hashing.")
q("medium","algorithms","What is required to use Binary Search?",
  "A sorted sequence, giving O(log n) lookups",
  ["Any unsorted list","A linked list only","A hash table"],
  "Binary Search halves the search space each step; bisect implements it in Python.")
q("hard","algorithms","What is the time complexity of Binary Search and why?",
  "O(log n), because each comparison halves the remaining range",
  ["O(n)","O(n log n)","O(1) always"],
  "Binary Search eliminates half the candidates per step on sorted data.")
q("medium","python_core","What is an RDD in Spark?",
  "A resilient distributed dataset: an immutable, partitioned collection with lineage; DataFrames are preferred for optimization",
  ["A SQL index","A Python decorator","A Delta log"],
  "RDD: low-level API; DataFrames benefit from the Catalyst optimizer.")
q("medium","pythonic","What does @dataclass generate for a class?",
  "Boilerplate such as __init__, __repr__ and __eq__ from annotated fields (a Dataclass)",
  ["A database table","A thread pool","A C extension"],
  "Dataclass: decorator in the standard library reducing boilerplate for data holders.")
q("hard","python_core","How does Garbage Collection work in CPython?",
  "Reference counting frees most objects immediately, and a cyclic collector reclaims reference cycles",
  ["Only a mark-and-sweep run hourly","The GIL frees memory","Objects are never freed"],
  "Garbage Collection in CPython combines reference counts with a generational cycle detector.")

q = mk('SQL')
q("medium","scenarios","Which operator rotates row values into columns in T-SQL reporting queries?",
  "PIVOT",
  ["TRUNCATE","UNION ALL","CROSS APPLY only"],
  "PIVOT: aggregates values and turns distinct row values into columns; UNPIVOT does the reverse.")
q("hard","scenarios","When is conditional aggregation preferred over PIVOT?",
  "When the output columns are not fixed or you need portability, using SUM(CASE WHEN ...)",
  ["Never","Only for NULL","Only for indexes"],
  "PIVOT requires known column values; conditional aggregation works across engines.")
q("medium","scenarios","What does MERGE do?",
  "Performs insert, update or delete in one statement based on a join between source and target",
  ["Only deletes duplicates","Creates an index","Rebuilds statistics"],
  "MERGE: upsert pattern; test carefully for concurrency and ensure the source has unique match keys.")
q("hard","scenarios","What error can MERGE raise when the source has duplicate matching keys?",
  "A target row matched by multiple source rows, which must be resolved by deduplicating the source",
  ["A deadlock always","A syntax error","Nothing"],
  "MERGE requires at most one source row per target row for updates.")
q("medium","performance","Which predicate is SARGable and can use an index seek?",
  "WHERE order_date >= '2025-01-01' AND order_date < '2025-02-01'",
  ["WHERE YEAR(order_date) = 2025","WHERE order_date + 1 > GETDATE()","WHERE CAST(order_date AS varchar) LIKE '2025%'"],
  "SARGable predicates keep the column unwrapped so the optimizer can seek.")
q("medium","performance","Why does the NOLOCK hint risk wrong results?",
  "It allows dirty reads, so uncommitted or inconsistent rows can be returned",
  ["It locks the whole table","It guarantees accuracy","It forces serializable"],
  "NOLOCK: READ UNCOMMITTED; avoid for financial accuracy, prefer snapshot isolation.")
q("medium","design","What is a Star Schema?",
  "A central fact table linked to denormalized dimension tables for analytics",
  ["Fully normalized OLTP tables","A single wide table","A graph database"],
  "Star Schema: fast aggregates and simple joins for BI.")
q("hard","design","Why use Denormalization in a warehouse?",
  "To reduce joins and speed up read-heavy analytics at the cost of redundancy",
  ["To reduce storage always","To enforce 3NF","To avoid indexes"],
  "Denormalization trades redundancy for query simplicity, as in a Star Schema.")
q("medium","performance","What does Locking protect, and what can excessive Locking cause?",
  "It protects consistency during concurrent access; excessive locks cause blocking and deadlocks",
  ["It speeds all queries","It disables transactions","It removes indexes"],
  "Locking: shared and exclusive locks; keep transactions short and use appropriate isolation.")

q = mk('nodeJS')
q("medium","security","What does CORS control?",
  "Which browser origins may call your API from JavaScript, enforced by the browser using response headers",
  ["Server CPU usage","Database access","TLS certificates"],
  "CORS: Access-Control-Allow-Origin headers; configure allowed origins rather than using wildcards with credentials.")
q("hard","security","Is CORS a server-side access control for non-browser clients?",
  "No, it is enforced by browsers only; the API still needs authentication",
  ["Yes, it blocks curl","Yes, it encrypts traffic","Yes, it rate limits"],
  "CORS does not stop direct HTTP clients.")
q("medium","security","How is a JWT typically validated in an Express API?",
  "Verify the signature, expiry and audience or issuer in middleware before trusting claims",
  ["Trust the payload without verification","Decode only","Store it in localStorage and skip checks"],
  "JWT: signed token; verify with the secret or public key and check exp, aud and iss.")
q("medium","security","Why add Rate Limiting to a Node.js API?",
  "To limit abusive or accidental floods and protect resources from overload and brute force",
  ["To speed up responses","To enable CORS","To compress bodies"],
  "Rate Limiting: per-IP or per-key limits, often via middleware and a shared store such as Redis.")
q("medium","scenarios","How should a Node.js server handle SIGTERM for Graceful Shutdown?",
  "Stop accepting new connections, finish in-flight requests, close resources, then exit",
  ["Exit immediately","Ignore the signal","Restart in a loop"],
  "Graceful Shutdown: server.close(), drain connections and close database pools within a timeout.")
q("medium","scenarios","When is WebSocket preferable to HTTP polling?",
  "For low-latency bidirectional real-time communication over a persistent connection",
  ["For static files","For one-time downloads","For batch uploads"],
  "WebSocket keeps a connection open so server and client can push messages.")

q = mk('JavaScript')
q("medium","performance","What does Debounce do to a frequently fired event handler such as search input?",
  "It delays execution until events stop for a set time, reducing calls",
  ["It runs the handler on every event","It runs once ever","It blocks the event loop"],
  "Debounce: resets a timer on each event and executes after quiet, ideal for typing.")
q("hard","performance","How does Throttle differ from Debounce?",
  "Throttle runs at most once per interval, while debounce waits for inactivity",
  ["They are identical","Throttle waits for inactivity","Debounce limits to a fixed rate"],
  "Throttle suits scroll and resize; Debounce suits search input.")
q("medium","performance","What does Throttle guarantee for a scroll handler?",
  "The handler executes at a bounded maximum rate",
  ["It never executes","It executes only after scrolling stops","It executes twice per event"],
  "Throttle limits frequency; Debounce limits bursts.")
q("hard","functions","What is the Temporal Dead Zone?",
  "The period between entering a scope and the let or const declaration where accessing the variable throws ReferenceError",
  ["A timer API","A garbage collection phase","A module cache"],
  "Temporal Dead Zone: let and const are hoisted but uninitialized until declared.")
q("medium","functions","What is Currying?",
  "Transforming a function with multiple arguments into a chain of single-argument functions",
  ["Caching results","Binding this","Parsing JSON"],
  "Currying enables partial application: f(a)(b)(c).")
q("medium","functions","What does Memoization do?",
  "Caches a function's results by arguments to avoid repeated computation",
  ["Deletes variables","Makes functions async","Hoists declarations"],
  "Memoization: store results for pure functions, often with a Map keyed by arguments.")
q("medium","logic","What is Event Delegation?",
  "Attaching one listener to a parent and handling child events through bubbling using event.target",
  ["Attaching a listener to every child","Preventing bubbling always","Using inline handlers"],
  "Event Delegation reduces listeners and supports dynamic elements.")
q("hard","logic","Why is Event Delegation useful for dynamically added list items?",
  "The parent listener catches events from new children without rebinding handlers",
  ["It disables bubbling","It requires reloading","It copies the DOM"],
  "Event Delegation relies on bubbling to a stable ancestor.")
q("hard","functions","What does a Generator function return and how is it used?",
  "An iterator that produces values lazily using yield and can pause and resume",
  ["An array of all values immediately","A Promise","A class"],
  "Generator: function* with yield; useful for lazy sequences and async flows.")
q("hard","objects","How does Proxy let you customize object behavior?",
  "It wraps a target and intercepts operations such as get and set with handler traps",
  ["It copies the object","It freezes the object","It makes it global"],
  "Proxy: metaprogramming for validation, logging and reactive systems.")
q("medium","objects","How do you make an Immutable object shallowly in JavaScript?",
  "Object.freeze, noting that nested objects remain mutable",
  ["const alone","Object.seal alone","Using var"],
  "Immutable data: freeze or copy-on-write; const prevents reassignment, not mutation.")

q = mk('dotnet')
q("medium","C# Language","What is the CLR?",
  "The Common Language Runtime that executes .NET code, providing JIT compilation, garbage collection and type safety",
  ["A database","A web server","A package manager"],
  "CLR: managed runtime executing IL; the JIT compiles it to native code.")
q("hard","C# Language","How does the CLR execute C# code?",
  "C# compiles to IL, which the JIT compiles to machine code at run time under CLR management",
  ["It interprets source directly","It compiles to JVM bytecode","It requires manual memory"],
  "CLR: manages type loading, JIT, garbage collection and security.")
q("medium","C# Language","What do Nullable reference types add in C# 8+?",
  "Compiler warnings for possible null dereferences, enabling null-safety analysis",
  ["Runtime null checks everywhere","A new collection type","Faster code"],
  "Nullable annotations (string?) express intent and warn on misuse.")
q("hard","C# Language","What does enabling Nullable context change?",
  "Reference types are non-null by default and ? marks nullable ones, with static flow analysis",
  ["All values become null","Exceptions are thrown at compile time","The GC runs more often"],
  "Nullable context improves correctness without changing runtime semantics.")
q("medium","ORM (EF Core)","What is Dapper?",
  "A lightweight micro-ORM that maps SQL query results to objects with low overhead",
  ["A full change-tracking ORM","A web framework","A message broker"],
  "Dapper: fast, SQL-first mapping; EF Core offers tracking and migrations.")
q("hard","ORM (EF Core)","When prefer Dapper over EF Core?",
  "For performance-critical, hand-tuned SQL queries and read-heavy paths",
  ["For automatic migrations","For change tracking","For LINQ translation"],
  "Dapper: minimal abstraction; many teams combine it with EF Core.")
q("medium","C# Language","Why implement IDisposable?",
  "To release unmanaged resources deterministically, typically used with using statements",
  ["To speed up GC","To make classes static","To enable LINQ"],
  "IDisposable: Dispose pattern for files, connections and handles.")

q = mk('AI_Arch')
q("medium","ai_engineering","What does Model Serving provide in an LLM platform?",
  "Managed, scalable endpoints with batching, autoscaling, versioning and monitoring for inference",
  ["Only training notebooks","A feature for DNS","A secrets vault"],
  "Model Serving: operationalizes models via APIs with latency, throughput and cost controls.")
q("hard","ai_engineering","Which Model Serving techniques increase GPU throughput?",
  "Continuous batching, quantization and caching of KV state",
  ["Smaller batches only","Disabling caching","Single request per GPU"],
  "Model Serving optimizations trade latency, throughput and cost.")
q("medium","operations","What is LLMOps?",
  "Operational practices for LLM apps: prompt versioning, evaluation, monitoring, guardrails and cost control",
  ["Only fine-tuning","A GPU driver","A vector index type"],
  "LLMOps extends MLOps with prompt and retrieval management plus continuous evaluation.")
q("hard","operations","Which signals belong in LLMOps monitoring?",
  "Quality evals, latency, token cost, guardrail hits and drift in retrieval or outputs",
  ["Only CPU","Only disk","Only uptime"],
  "LLMOps tracks both system and quality metrics.")
q("medium","security","What is the OWASP guidance most relevant to LLM apps?",
  "OWASP Top 10 for LLM Applications, covering prompt injection and insecure output handling",
  ["PCI DSS only","ISO 9000","SOC 1"],
  "OWASP lists risks such as prompt injection, data leakage and excessive agency.")
q("medium","security","Where should API keys for an AI service be stored? (Secrets Management)",
  "In a secrets manager with rotation and least-privilege access, not in code or images",
  ["In Git","In the prompt","In container layers"],
  "Secrets Management: vaults, short-lived credentials and audit logging.")
q("medium","kubernetes","What does Karpenter do on Kubernetes?",
  "Provisions right-sized nodes just in time based on pending pod requirements",
  ["Manages DNS","Encrypts secrets","Builds images"],
  "Karpenter: node autoscaler that can use spot and GPU instances to reduce cost.")
q("medium","security","What does Data Residency require?",
  "Keeping data stored and processed in specified regions or jurisdictions",
  ["Encrypting only","Using CDN","Multi-cloud always"],
  "Data Residency: regional deployment and controls to meet legal requirements.")

q = mk('HL7')
q("medium","fhir","What is SNOMED CT used for in healthcare messaging?",
  "A clinical terminology for diagnoses, findings and procedures",
  ["A transport protocol","A lab-only code set","A billing format"],
  "SNOMED CT: comprehensive clinical terminology; LOINC covers lab and observation identifiers.")
q("hard","fhir","How do LOINC and SNOMED CT differ?",
  "LOINC identifies observations and tests, while SNOMED CT represents clinical concepts",
  ["They are identical","SNOMED is for labs only","LOINC is for diagnoses"],
  "SNOMED and LOINC are complementary terminologies.")
q("medium","structure","How does HIPAA affect HL7 integrations?",
  "It requires safeguarding protected health information with access control, audit and encryption",
  ["It defines segment formats","It replaces FHIR","It applies only to billing"],
  "HIPAA: US privacy and security rules governing PHI in transit and at rest.")
q("hard","structure","Which HIPAA safeguards apply to interfaces sending PHI?",
  "Transmission security such as TLS or VPN, authentication, access logging and minimum necessary use",
  ["No safeguards for internal links","Only passwords","Only backups"],
  "HIPAA technical safeguards cover integrity, access control and audit.")
q("medium","structure","What is an Interface Engine?",
  "Integration middleware that receives, transforms and routes HL7 messages between systems",
  ["A database","A monitor","A storage array"],
  "Interface Engine: Mirth Connect, Rhapsody and others provide channels, mapping and monitoring.")
q("hard","structure","What does an Interface Engine typically provide for HL7 v2 feeds?",
  "Channel routing, transformation, acknowledgment handling, queuing and error reprocessing",
  ["Only storage","Only encryption","No transformation"],
  "Interface Engine functions reduce point-to-point integrations.")
q("medium","structure","What is Mirth Connect?",
  "An open-source integration engine used to build channels that transform and route HL7 and FHIR messages",
  ["A FHIR server only","A terminology","A lab instrument"],
  "Mirth: channel-based engine with JavaScript transformers.")
q("medium","fhir","What is a FHIR Bundle?",
  "A container resource grouping multiple resources, used for transactions, searches and documents",
  ["A single patient","A terminology","A transport"],
  "Bundle types include transaction, batch, searchset and document.")
q("medium","fhir","What does a FHIR Profile do?",
  "Constrains a base resource with required elements, bindings and extensions for a use case",
  ["Encrypts resources","Stores data","Routes messages"],
  "Profile: StructureDefinition constraints such as US Core.")
q("medium","fhir","Why use standard Terminology bindings in FHIR?",
  "They ensure coded values are interoperable across systems using LOINC, SNOMED and similar systems",
  ["They compress payloads","They define HTTP","They replace IDs"],
  "Terminology bindings tie elements to value sets.")
