B = {}
def mk(name):
    L = []
    def q(d, c, text, ok, wrong, ex): L.append((d, c, text, ok, wrong, ex))
    B[name] = (L, q)
    return q

q = mk('databricks')
q("hard","spark_performance","Spark tasks show large 'Spill (Disk)' metrics during a wide aggregation. What is Disk Spilling and what is a first fix?",
  "Execution data exceeded executor memory and was written to local disk; increase shuffle partitions, fix skew or add memory",
  ["Delta files were deleted; run VACUUM", "The driver crashed; restart the cluster", "Caching is disabled; enable DBFS mounts"],
  "Disk Spilling: when sort, join or aggregation state does not fit in executor memory, Spark writes it to disk, slowing the stage. Smaller partitions, reducing skew or larger executors reduce spilling.")
q("medium","spark_performance","Which description best explains why Disk Spilling hurts performance?",
  "Disk I/O is far slower than memory, so tasks that spill take much longer and may cause stragglers",
  ["Spilling deletes shuffle files", "Spilling forces a full table VACUUM", "Spilling only affects the driver UI"],
  "Disk Spilling trades memory pressure for slow local I/O. Spark UI metrics 'Spill (Memory/Disk)' identify the stage to tune.")
q("medium","delta_lake","A query filters on event_date and reads only a few Delta files. Which concept explains this?",
  "Data skipping and partition Pruning use min/max statistics and partition values to avoid reading irrelevant files",
  ["Time travel", "Vacuum", "Checkpointing"],
  "Pruning: Delta stores per-file statistics in the transaction log, so files whose ranges cannot match the predicate are skipped. Z-ORDER or liquid clustering improves the effect.")
q("medium","spark_performance","What does the Photon Engine change for existing SQL and DataFrame workloads?",
  "It accelerates them with a native vectorized C++ engine without requiring code changes",
  ["It converts Spark to Pandas", "It replaces Delta Lake", "It only works for streaming"],
  "Photon Engine: Databricks' vectorized query engine, compatible with Spark APIs, best for scans, joins and aggregations on Delta data.")
q("easy","architecture","In the Medallion pattern, what belongs in the Silver Layer?",
  "Cleaned, deduplicated, validated and conformed data derived from Bronze",
  ["Raw files exactly as received", "Final BI aggregates only", "Model weights"],
  "Silver Layer: the enterprise 'source of truth' with enforced schema and quality rules; Gold then serves business aggregates.")
q("easy","governance","How does the Unity Catalog 3-Layer Namespace identify a table?",
  "catalog.schema.table",
  ["workspace.cluster.table", "bucket.folder.file", "database.partition.table"],
  "3-Layer Namespace: Unity Catalog addresses objects as catalog.schema.table, which is also the unit for grants and lineage.")
q("medium","architecture","A BI team wants instant-start SQL compute without managing clusters. Which option fits?",
  "Serverless SQL warehouses, managed by Databricks with rapid startup and elastic scaling",
  ["A single-node job cluster", "A manually sized interactive cluster", "A local Spark session"],
  "Serverless SQL: compute is provisioned by Databricks, billed per use, and starts in seconds; Photon accelerates the queries.")
q("medium","governance","Which pairing tracks experiments and manages versions of ML models with governance?",
  "MLflow for tracking and the Model Registry (in Unity Catalog) for versions, aliases and lineage",
  ["Delta Sharing and Auto Loader", "DBFS and Z-ORDER", "Photon and AQE"],
  "MLflow: logs parameters, metrics and artifacts. Model Registry: central store with versioning and stage-like aliases for promotion.")
q("hard","architecture","A team builds a RAG application on Databricks. Which components of Mosaic AI support it?",
  "Mosaic AI Vector Search for similarity retrieval plus Model Serving for LLM endpoints",
  ["Auto Loader and Z-ORDER only", "Photon and DBFS only", "Delta Live Tables only"],
  "Mosaic AI: Databricks' AI platform. Vector Search: a managed index synced from Delta tables for embedding retrieval.")
q("hard","architecture","What does a Delta Sync Vector Search index provide?",
  "A managed vector index that stays synchronized with a source Delta table for similarity search",
  ["A copy of Spark logs", "A replacement for Unity Catalog", "A cluster policy"],
  "Vector Search indexes embeddings and keeps them updated as the Delta source changes, supporting RAG retrieval.")
q("easy","governance","What is DBFS, and what does Databricks now recommend for governed file access?",
  "DBFS is an abstraction over cloud object storage; Unity Catalog volumes are recommended for governed access",
  ["DBFS is a SQL engine", "DBFS replaces Delta Lake", "DBFS is a streaming protocol"],
  "DBFS: the Databricks File System layer for workspace storage; legacy mounts are discouraged in favor of Unity Catalog volumes.")
q("easy","spark_performance","In Spark, why does calling filter() or select() not start a job immediately?",
  "Transformations are lazy; Spark builds a plan and executes it only when an action such as count() runs",
  ["Spark only runs on the driver", "Transformations are always cached", "Jobs start only at midnight"],
  "Lazy evaluation lets Catalyst optimize the whole plan before an action triggers execution.")

q = mk('AI')
q("medium","ai_engineering","Which pattern describes Agentic Workflows?",
  "An LLM iteratively plans, calls tools, observes results and decides next steps until the goal is met",
  ["A single prompt with no tools", "A static retrieval index", "A batch fine-tuning job"],
  "Agentic Workflows: loops where the model reasons and acts using tools, with guardrails and termination conditions.")
q("hard","ai_engineering","Retrieved evidence placed in the middle of a very long prompt is often ignored. What is this effect called?",
  "Lost in the Middle: models attend better to the beginning and end of long contexts",
  ["Catastrophic forgetting", "Temperature collapse", "Tokenizer drift"],
  "Lost in the Middle: mitigate by ranking and placing key passages at the edges, trimming context or using reranking.")
q("medium","ai_engineering","A system sends simple queries to a small model and complex ones to a large model. What is this?",
  "Routing, choosing a model or pipeline per request to balance cost, latency and quality",
  ["Quantization", "Distillation", "Tokenization"],
  "Routing: a classifier or rules pick the model or tool; semantic routing and cascades reduce cost.")

q = mk('Azure')
q("medium","scenarios","Which service provides GPT models inside your Azure tenant with enterprise security and regional control?",
  "Azure OpenAI Service",
  ["Azure Cache for Redis", "Azure Front Door", "Azure Monitor"],
  "OpenAI Service: hosted OpenAI models with private networking, Entra ID, content filtering and data residency controls.")
q("hard","scenarios","Which choices make an Azure OpenAI Service deployment safer for sensitive data?",
  "Private endpoints, Entra ID managed identities and content filters",
  ["Public endpoints with shared keys", "Disabling logging", "Sharing one key across apps"],
  "OpenAI Service security: network isolation, identity-based access and policy controls.")
q("medium","scenarios","In the Cloud Adoption Framework, what do Landing Zones provide?",
  "A pre-configured, governed environment with networking, identity, policy and management baselines for workloads",
  ["A pricing discount tier", "A VM image", "A DNS record"],
  "Landing Zones: subscriptions and management groups prepared with guardrails so teams can deploy safely at scale.")
q("hard","scenarios","Which Landing Zones element enforces guardrails such as allowed regions across subscriptions?",
  "Azure Policy assigned at management group scope",
  ["A per-VM startup script", "A NSG on one subnet", "Manual reviews"],
  "Landing Zones rely on management groups and Azure Policy for consistent governance.")
q("medium","scenarios","The Azure Well-Architected Framework is organized around which pillars?",
  "Reliability, Security, Cost Optimization, Operational Excellence and Performance Efficiency",
  ["Compute, Storage, Network, Identity, Billing", "Dev, Test, Stage, Prod, DR", "IaaS, PaaS, SaaS, FaaS, DaaS"],
  "Well-Architected Framework: pillar-based guidance and review assessments for workload design tradeoffs.")
q("hard","scenarios","A Well-Architected Framework review finds one region is a single point of failure. Which pillar is most affected?",
  "Reliability",
  ["Cost Optimization", "Sustainability only", "Billing"],
  "Well-Architected Framework: Reliability covers redundancy, zones, regions, failover and recovery objectives.")
q("medium","scenarios","A team wants a Data Lakehouse on Azure combining ADLS Gen2 storage with Delta tables and warehouse-style SQL. Which services are typical?",
  "ADLS Gen2 with Azure Databricks or Microsoft Fabric",
  ["Azure Cache and Redis", "Azure DNS and Traffic Manager", "Azure Bastion and VPN"],
  "Data Lakehouse: open table formats on a data lake give BI and ML on one copy of data.")
q("hard","scenarios","Why choose a Data Lakehouse over separate lake and warehouse silos?",
  "It reduces duplication and supports BI, streaming and ML on governed open-format data",
  ["It eliminates storage costs", "It removes the need for governance", "It only supports OLTP"],
  "Data Lakehouse: ACID tables such as Delta over object storage unify workloads, with Purview or Unity Catalog for governance.")

q = mk('AWS')
q("medium","security","Which IAM Policy element allows access only if a request comes from a specific VPC endpoint?",
  "A Condition block such as aws:SourceVpce",
  ["The Version field", "The Sid field", "The Principal wildcard"],
  "IAM Policy: statements combine Effect, Action, Resource and Condition. Explicit Deny overrides Allow.")
q("hard","security","An explicit Deny in one IAM Policy conflicts with an Allow in another. What is the outcome?",
  "Access is denied because an explicit Deny always overrides any Allow",
  ["Access is allowed", "The newest policy wins", "The larger policy wins"],
  "IAM Policy evaluation: default deny, explicit Deny beats Allow, and permission boundaries or SCPs further restrict.")
q("easy","scenarios","Which S3 Glacier class is best for archives that are rarely read and can wait hours for retrieval at lowest cost?",
  "S3 Glacier Deep Archive",
  ["S3 Standard", "S3 Express One Zone", "S3 Intelligent-Tiering frequent tier"],
  "S3 Glacier: archive storage classes trade retrieval time for low cost; lifecycle policies transition data automatically.")
q("medium","scenarios","How are objects moved to S3 Glacier automatically after 90 days?",
  "With an S3 lifecycle rule transitioning objects to a Glacier storage class",
  ["A Lambda cron only", "Manually via console", "Using CloudFront"],
  "S3 Glacier transitions are configured by lifecycle rules, optionally with expiration.")
q("medium","security","Which service centralizes fine-grained access control and governance for data lakes on S3?",
  "AWS Lake Formation",
  ["AWS Shield", "Amazon Inspector", "AWS Backup"],
  "Lake Formation: manages permissions at database, table, column and row level for Glue Catalog resources, used by Athena and Redshift Spectrum.")
q("hard","security","Which Lake Formation capability restricts a user to specific columns or rows in a table?",
  "Data filters providing column-level and row-level security",
  ["S3 bucket ACLs only", "VPC flow logs", "KMS key aliases"],
  "Lake Formation permissions apply governed access across analytics engines.")
q("medium","scenarios","Where do Lambda function logs go by default, and how can you search them?",
  "To CloudWatch Logs, searchable with Logs Insights queries",
  ["To S3 Glacier", "To AWS Config only", "To Route 53"],
  "CloudWatch Logs: log groups and streams with retention settings, metric filters and Logs Insights.")
q("hard","scenarios","How do you create an alarm when a log pattern such as ERROR exceeds a threshold?",
  "Create a CloudWatch Logs metric filter and alarm on the resulting metric",
  ["Use S3 Select", "Use Direct Connect", "Use an EBS snapshot"],
  "CloudWatch Logs metric filters convert log patterns into metrics for CloudWatch alarms.")

q = mk('mongoDB')
q("medium","crud","What does an upsert do in MongoDB?",
  "Updates a matching document or inserts a new one if none matches (upsert: true)",
  ["Deletes duplicates", "Rebuilds an index", "Shards a collection"],
  "Upsert: updateOne with { upsert: true } inserts using the filter fields and update operators when no document matches.")

q = mk('react')
q("medium","state","What problem does the Context API solve?",
  "Passing data through the component tree without prop drilling at every level",
  ["Server rendering", "Bundling modules", "CSS scoping"],
  "Context API: createContext, Provider and useContext. Frequent updates can rerender consumers, so split contexts.")
q("hard","state","Why can a single large Context API value hurt performance?",
  "All consumers rerender when the value changes, so split contexts or memoize the value",
  ["It blocks the network", "It disables hooks", "It forces SSR"],
  "Context API consumers re-render on value change; use memoized values or selector libraries.")
q("easy","styling","How does a responsive layout adapt to screen sizes?",
  "Using relative units, flexible grids and media or container queries",
  ["Fixed pixel widths only", "Disabling zoom", "Separate sites per device only"],
  "A responsive design uses CSS techniques such as flexbox, grid and breakpoints.")
q("medium","hooks","What are Custom Hooks?",
  "Functions starting with use that compose built-in hooks to reuse stateful logic",
  ["Class components", "Redux reducers", "Webpack loaders"],
  "Custom Hooks: share logic, not state, across components; they must follow the rules of hooks.")
q("hard","hooks","Do two components calling the same Custom Hooks function share state?",
  "No, each call gets its own isolated state",
  ["Yes, state is global", "Only in class components", "Only with Redux"],
  "Custom Hooks reuse logic; each invocation has independent state unless it reads shared context or stores.")
q("medium","optimization","Which React rendering choices reduce cost on large lists?",
  "Virtualization, stable keys and memoization to cut cost of unnecessary renders",
  ["Using index keys always", "Rendering all rows", "Disabling keys"],
  "Reducing render cost involves windowing, React.memo and avoiding new object props each render.")
q("hard","optimization","How can a team reduce cost of client JavaScript in a data-heavy page?",
  "Use Server Components to render on the server and ship less client code",
  ["Add more client libraries", "Disable code splitting", "Inline all assets"],
  "Server Components: run on the server, can access data directly, and add no client bundle cost.")
q("medium","basics","What is a limitation of Server Components?",
  "They cannot use state, effects or browser-only APIs; interactivity needs Client Components",
  ["They cannot fetch data", "They cannot render HTML", "They require class components"],
  "Server Components render ahead of time; mark interactive parts with 'use client'.")
q("medium","optimization","What does Suspense provide?",
  "A declarative fallback UI while children wait on lazy components or data",
  ["Immediate error recovery", "State persistence", "Routing"],
  "Suspense: shows fallback until content is ready; pairs with lazy and data frameworks.")
q("hard","optimization","How can Suspense improve streaming SSR?",
  "Slow sections stream later while the rest of the page is shown immediately behind fallbacks",
  ["It blocks the whole page", "It disables hydration", "It removes the server"],
  "Suspense boundaries let the server send HTML progressively.")
q("medium","state","Which library manages server state with caching, refetching and deduplication?",
  "React Query (TanStack Query)",
  ["Redux Toolkit only", "Axios only", "Prettier"],
  "React Query: handles stale-while-revalidate, retries and background refetching.")
q("hard","state","Why use React Query instead of storing fetched data in Redux?",
  "It handles caching, invalidation and refetching of server state automatically",
  ["It replaces JSX", "It speeds up CSS", "It bundles code"],
  "React Query treats server data separately from UI state.")
q("medium","state","What is Zustand?",
  "A small hook-based global state library with minimal boilerplate",
  ["A CSS framework", "A bundler", "A test runner"],
  "Zustand: create a store and select slices with hooks to avoid unnecessary renders.")
q("hard","state","How does Zustand limit rerenders?",
  "Components subscribe to selected slices, so unrelated changes do not rerender them",
  ["It rerenders everything", "It uses class state", "It needs Providers"],
  "Zustand selectors give fine-grained subscriptions.")

q = mk('snowflake')
q("medium","architecture","What does a Snowflake Zero-copy clone do?",
  "Creates a metadata-only copy sharing storage until changes diverge",
  ["Duplicates all data immediately", "Exports to S3", "Locks the source"],
  "Zero-copy cloning: instant clone of tables, schemas or databases; only changed micro-partitions use extra storage.")
q("medium","architecture","Which feature is the final recovery option after Time Travel ends?",
  "Fail-safe, a 7-day Snowflake-managed recovery period for permanent tables",
  ["Query acceleration", "Resource monitors", "Search optimization"],
  "Fail-safe: not user-accessible; contact Snowflake support to recover data.")

q = mk('kafka')
q("medium","consumer","How do Consumer Groups scale consumption?",
  "Partitions of a topic are divided among members, so each partition is read by one member of the group",
  ["Every consumer reads every partition", "Groups replace partitions", "Groups remove offsets"],
  "Consumer Groups: parallelism is limited by partition count; membership changes trigger rebalances.")

q = mk('Data_Arch')
q("medium","performance","Why is Columnar Storage efficient for analytics?",
  "Queries read only required columns and benefit from compression and vectorized scans",
  ["It speeds OLTP row updates", "It stores whole rows together", "It avoids compression"],
  "Columnar Storage: formats such as Parquet and ORC reduce I/O for aggregates over few columns.")

q = mk('EA')
q("medium","scenarios","What is SABSA?",
  "A risk-driven enterprise security architecture framework aligned to business requirements",
  ["A cloud billing tool", "A UML notation", "A project scheduling method"],
  "SABSA: Sherwood Applied Business Security Architecture traces security controls to business drivers in layers.")
q("medium","scenarios","What does an enterprise Taxonomy provide?",
  "A controlled classification of terms and artifacts that keeps architecture content consistent",
  ["A network topology", "A budget", "A test plan"],
  "Taxonomy: standard categories in the architecture repository aid reuse and governance.")
q("medium","scenarios","What is ArchiMate used for?",
  "An open modeling language to describe business, application and technology layers and their relationships",
  ["A database engine", "A CI tool", "A programming language"],
  "Archimate: The Open Group standard commonly used with TOGAF to visualize enterprise architecture.")

q = mk('typescript_nestjs')
q("medium","integration_scenarios","What is the AWS CDK?",
  "A framework to define cloud infrastructure in languages such as TypeScript that synthesizes to CloudFormation",
  ["A JavaScript runtime", "A CSS tool", "A load balancer"],
  "AWS CDK: constructs compose resources; cdk synth produces CloudFormation templates.")
q("medium","integration_scenarios","Which service runs containers without managing servers?",
  "AWS Fargate",
  ["Amazon S3", "Route 53", "AWS Config"],
  "Fargate: serverless compute for ECS and EKS tasks, often used for NestJS services.")
q("medium","integration_scenarios","How does Blue-Green deployment reduce release risk?",
  "Traffic switches between two environments, allowing instant rollback",
  ["It deletes the old version first", "It uses one server", "It skips testing"],
  "Blue-Green: keep the previous version live until the new one is verified.")
q("medium","integration_scenarios","Where should a NestJS app on Azure retrieve secrets from?",
  "Azure Key Vault using a managed identity",
  ["A committed .env file", "package.json", "A public blob"],
  "Key Vault: central secret and key storage with RBAC and rotation.")
q("medium","integration_scenarios","Which tool provides end-to-end browser testing for an Angular front end?",
  "Cypress",
  ["Prettier", "Webpack", "Nodemon"],
  "Cypress: runs real browser tests with time-travel debugging and network stubbing.")

q = mk('web3Blockchain')
q("medium","security","In blockchains, what does Asymmetric cryptography use?",
  "A public and private key pair; the private key signs and the public key verifies",
  ["One shared secret", "A password hash only", "No keys"],
  "Asymmetric cryptography: ECDSA signatures prove ownership without revealing the private key.")
q("hard","security","Why is Asymmetric cryptography central to wallets?",
  "Signatures prove ownership of an address without exposing the private key",
  ["It encrypts the entire chain", "It removes gas fees", "It mines blocks"],
  "Asymmetric keys derive addresses and sign transactions.")
q("medium","architecture","What is Web3js?",
  "A JavaScript library to interact with Ethereum nodes, accounts and contracts",
  ["A CSS framework", "A consensus algorithm", "A wallet hardware"],
  "Web3js: connects to JSON-RPC providers to read state and send transactions.")
q("hard","architecture","How does an app call a smart contract method with Web3js?",
  "Create a contract instance with the ABI and address, then call() reads or send() writes",
  ["Use fetch to the contract", "Edit the block", "Mine a block locally"],
  "Web3js contract objects use the ABI; send() requires a signed transaction and gas.")
q("medium","architecture","What is Filecoin?",
  "A decentralized storage network where providers earn tokens for storing data with proofs",
  ["A layer 2 rollup", "A stablecoin", "A wallet"],
  "Filecoin: incentivized storage using proofs of replication and spacetime, often paired with IPFS.")
