Q = []
def q(d, c, text, ok, wrong, ex): Q.append((d, c, text, ok, wrong, ex))
IAC,K8S,CI,OBS,SRE,SEC,NET,FIN,PLAT = "iac-management","k8s-architecture","cicd-gitops","observability-concepts","sre-concepts","devsecops","cloud-networking","finops","platform-engineering"

q("medium",IAC,"A team must configure 200 Linux servers over SSH without installing agents, using idempotent YAML playbooks. Which tool fits?",
  "Ansible",
  ["Prometheus", "Istio", "Jaeger"],
  "Ansible: agentless configuration management using YAML playbooks over SSH. Tasks are idempotent so reruns converge to the desired state.")
q("medium",IAC,"An Azure-only team wants a first-party declarative language that compiles to ARM templates. Which should they choose?",
  "Bicep",
  ["Helm", "Packer", "Ansible Vault"],
  "Bicep: Azure's domain-specific IaC language that transpiles to ARM. Terraform is the multi-cloud alternative.")
q("hard",IAC,"A platform team wants developers to request databases and buckets as Kubernetes custom resources, with the control plane provisioning them in the cloud. Which tool?",
  "Crossplane",
  ["Kustomize", "Fluentd", "Trivy"],
  "Crossplane: a Kubernetes-native control plane that composes cloud resources through CRDs and compositions, continuously reconciling them like any other Kubernetes object.")
q("easy",K8S,"What do AKS and EKS have in common?",
  "They are managed Kubernetes services where the cloud provider operates the control plane",
  ["They are container registries", "They are CI servers", "They are service meshes"],
  "AKS/EKS: Azure Kubernetes Service and Amazon Elastic Kubernetes Service run and patch the control plane, leaving node pools and workloads to you.")
q("hard",K8S,"A queue consumer should scale pods based on queue length, down to zero when empty. Which combination fits?",
  "KEDA for event-driven scaling, which drives the HPA",
  ["VPA alone", "A cron job", "Cluster Autoscaler alone"],
  "KEDA: scales workloads from external event sources, including to zero. HPA: the native controller that adjusts replicas from CPU, memory or custom metrics.")
q("medium",K8S,"Which statement about autoscaling in Kubernetes is correct?",
  "Autoscaling happens at pod level (HPA/KEDA) and node level (cluster autoscaler), and each needs resource requests to be meaningful",
  ["HPA adds nodes directly", "Autoscaling needs no metrics", "Only nodes can scale"],
  "Autoscaling: HPA changes replica counts, the cluster autoscaler adds nodes, and KEDA adds event triggers.")
q("medium",K8S,"How does an Ingress Controller differ from a Service of type LoadBalancer for HTTP apps?",
  "An Ingress Controller routes many hostnames and paths to services through one entry point, applying Ingress rules at layer 7",
  ["It only works for UDP", "It creates pods", "It replaces CoreDNS"],
  "Ingress Controller: NGINX, Traefik or cloud-native implementations realize Ingress resources, consolidating public endpoints and TLS.")
q("medium",CI,"Which statement about Pipelines and CI/CD Pipeline as Code is correct?",
  "Pipeline definitions live in version-controlled YAML next to the application, so changes are reviewed and reproducible",
  ["Pipelines are configured only in a web UI", "Pipelines cannot be tested", "Pipeline as code requires no repository"],
  "CI/CD Pipeline as Code: storing definitions in the repo, as with Azure Pipelines or GitHub Actions, gives review, history and rollbacks for the pipeline itself.")
q("hard",CI,"A GitHub Actions workflow deploys to AWS using long-lived access keys stored as secrets. What is the better practice?",
  "Use OpenID Connect so the workflow obtains short-lived credentials without stored keys",
  ["Check the keys into the repository", "Rotate the keys yearly", "Share one key across all repositories"],
  "GitHub Actions: OIDC federation removes long-lived cloud secrets. This is core Secrets Management and Supply Chain Security hygiene.")
q("medium",CI,"A release must be switched instantly between two identical environments with instant rollback. Which strategy?",
  "Blue-Green deployment",
  ["Rolling restart without a spare", "Big bang on a weekend", "Recreate only"],
  "Blue-Green: run the new version beside the old and flip traffic; rollback means flipping back. Cost is duplicate capacity.")
q("hard",CI,"A team wants to expose a new version to 5% of users, watch error rates, and then expand. Which strategy?",
  "Canary release, optionally automated by a progressive delivery tool",
  ["Blue-Green", "Recreate", "Shadow database migration"],
  "Canary: gradual exposure with metric gates. Unlike Blue-Green it validates with real traffic incrementally.")
q("easy",OBS,"Which tool is most commonly used to build dashboards on top of Prometheus, Loki and Tempo data?",
  "Grafana",
  ["Terraform", "Ansible", "Vault"],
  "Grafana: visualization and alerting across metrics, logs and traces data sources.")
q("hard",OBS,"A company wants vendor-neutral instrumentation across languages, with a collector that routes telemetry to any backend. Which standard?",
  "OpenTelemetry",
  ["A proprietary agent for each vendor", "SNMP", "Syslog only"],
  "OpenTelemetry: CNCF standard APIs, SDKs and collector for traces, metrics and logs. Pair with Grafana and a backend of choice.")
q("hard",OBS,"Which technology gives low-overhead kernel-level visibility and networking without changing application code?",
  "eBPF",
  ["JMX", "Cron", "Log rotation"],
  "eBPF: programs run safely in the Linux kernel for observability, security and networking (for example Cilium CNI), with no sidecar needed.")
q("hard",SRE,"A service has a 99.9% availability objective. What are the SLI, SLO and the error budget?",
  "The SLI is measured availability, the SLO is the 99.9% target, and the error budget is the 0.1% of allowed failure",
  ["The SLO is measured and the SLI is the target", "The error budget is the cloud bill", "They are all identical"],
  "SLI/SLO: indicators measure behavior and objectives set targets. Error Budgets turn the gap into a release-velocity decision: when it is spent, reliability work takes priority.")
q("medium",SRE,"A team wants to verify that the system survives pod and node failures before they happen in production. Which practice?",
  "Chaos Engineering, injecting controlled failures to test resilience",
  ["Load testing only", "Code review", "Backups"],
  "Chaos Engineering: hypothesis-driven fault injection, run with a defined blast radius and steady-state SLI checks.")
q("hard",SEC,"Where should database passwords and API keys for workloads be stored and delivered?",
  "In a secrets manager such as Key Vault or AWS Secrets Manager, delivered at runtime with short-lived identity-based access",
  ["In the Git repository", "In container image layers", "In plain ConfigMaps"],
  "Secrets Management: central vaults, rotation and least-privilege access. Zero Trust adds identity verification for every request.")
q("medium",SEC,"What is the core principle of Zero Trust?",
  "Never trust, always verify: authenticate and authorize every request regardless of network location",
  ["Trust everything inside the VPN", "Trust internal IP ranges", "Disable authentication internally"],
  "Zero Trust: assumes breach, uses strong identity, least privilege and segmentation instead of a trusted perimeter.")
q("hard",SEC,"A new regulation requires you to list every library inside each shipped image and prove it was not tampered with. Which two controls?",
  "An SBOM for each build plus signed artifacts as part of Supply Chain Security",
  ["Only a firewall", "Annual penetration test", "Manual spreadsheet"],
  "SBOM: a software bill of materials in SPDX or CycloneDX format. Supply Chain Security: image signing, provenance and dependency scanning.")
q("easy",NET,"Which AWS service acts as a hub connecting many VPCs and on-premises networks?",
  "Transit Gateway",
  ["Route 53", "CloudFront", "KMS"],
  "Transit Gateway: simplifies many-to-many VPC connectivity versus peering meshes.")
q("medium",NET,"A workload must reach a SaaS or PaaS service without traversing the public internet. Which capability?",
  "Private Link (private endpoints)",
  ["A public IP with a firewall rule", "NAT to the internet", "A larger VM"],
  "Private Link: exposes a service via a private IP in your network. Transit Gateway solves routing between networks instead.")
q("medium",FIN,"Fault-tolerant batch workers can be interrupted. How do you cut compute cost most?",
  "Use Spot Instances with checkpointing, accepting that they can be reclaimed",
  ["Reserved Instances for all", "Larger on-demand nodes", "Disable autoscaling"],
  "Spot Instances: deeply discounted spare capacity that can be reclaimed. Use with Autoscaling and interruption handling.")
q("hard",FIN,"A CTO compares moving to Serverless against running VMs. Which factor belongs in the TCO analysis besides compute price?",
  "Operations and staffing effort, idle capacity, and scaling behavior, not only unit price",
  ["Only the per-hour VM price", "Only the logo of the provider", "Nothing else"],
  "Serverless: pay-per-use compute. TCO (total cost of ownership) includes operations, tooling, licensing and risk alongside runtime cost.")
q("hard",PLAT,"A platform team wants developers to self-serve compliant services quickly. Which approach and tool pairing is common?",
  "Platform Engineering with Golden Paths, surfaced through an internal developer portal such as Backstage",
  ["A ticket queue for every request", "Letting each team invent its own tooling", "A single shared admin account"],
  "Platform Engineering: treats the platform as a product. Golden Paths: opinionated, supported templates. Backstage: an open-source developer portal with a software catalog and scaffolding.")
q("medium",PLAT,"Why do platform teams provide Golden Paths?",
  "They make the secure, compliant way the easiest way, lowering cognitive load while still allowing exceptions",
  ["They forbid all customization", "They remove CI", "They replace monitoring"],
  "Golden Paths: paved, well-supported routes such as service templates and pipelines, typically offered via Backstage and Platform Engineering practices.")
