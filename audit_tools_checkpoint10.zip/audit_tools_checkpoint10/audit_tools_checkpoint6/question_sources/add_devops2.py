Q = []
def q(d, c, text, ok, wrong, ex): Q.append((d, c, text, ok, wrong, ex))
q("medium","iac-management","Which pair is correct for provisioning versus configuring infrastructure?",
  "Crossplane or Terraform provision resources, while Ansible configures what runs on them",
  ["Ansible provisions Kubernetes control planes", "Crossplane installs packages over SSH", "They are interchangeable"],
  "Ansible: configuration management of hosts. Crossplane: declarative provisioning of cloud resources through Kubernetes APIs.")
q("medium","k8s-architecture","In a managed cluster on AKS/EKS, who patches the Kubernetes control plane, and who patches worker node images?",
  "The provider operates the control plane; you manage node image upgrades unless using managed or auto-upgrade options",
  ["The provider patches everything with no options", "You patch the control plane", "Nobody patches anything"],
  "AKS/EKS: the shared responsibility model puts control plane operations with the provider while node lifecycle remains largely with the customer.")
q("hard","cicd-gitops","A canary rollout is gated by SLI/SLO metrics and halts automatically if the error rate exceeds the objective. Which two ideas are combined?",
  "Canary delivery and SLI/SLO-based automated gates",
  ["Blue-Green and manual approval only", "Recreate and chaos testing", "Cron and logging"],
  "Canary: incremental exposure. SLI/SLO: objective measures that decide whether to proceed or roll back.")
q("hard","finops","Compare a Serverless function platform with always-on VMs for spiky traffic. How should TCO be judged?",
  "Include per-invocation cost, idle cost avoided, operational effort, cold-start and limits, not just unit price",
  ["Only the hourly VM rate", "Only the number of regions", "Ignore operations"],
  "Serverless: pay per use and scale to zero. TCO: total cost of ownership across compute, people, tooling and risk.")
q("medium","cicd-gitops","A team keeps its pipeline in the repository and exposes the app through an Ingress Controller in Kubernetes. Which two practices are shown?",
  "CI/CD Pipeline as Code and layer 7 routing through an Ingress Controller",
  ["Manual UI pipelines and NodePort for everything", "Pipelines on one laptop", "Ingress for UDP only"],
  "CI/CD Pipeline as Code: reviewable, versioned automation. Ingress Controller: shared HTTP entry point for many services.")
