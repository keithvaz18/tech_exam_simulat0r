Q = []
def q(d, c, text, ok, wrong, ex): Q.append((d, c, text, ok, wrong, ex))
A, T, C, P, X = "agentic-architecture", "tool-design-mcp", "claude-code", "prompt-structured-output", "context-reliability"
q("hard", T, "A lookup tool is returning a 503 and, separately, a 400 for a malformed order number. How should the agent treat them differently?",
  "Retry the 503 because it is transient; correct the input for the 400 because that validation error is not retryable",
  ["Retry both identically up to ten times", "Escalate both to a human immediately", "Ignore both and answer from memory"],
  "Error Categories: transient, validation, business and permission errors need different handling. isRetryable metadata tells the agent which failures are worth retrying.")
q("medium", T, "Your research coordinator exposes 18 tools to every subagent and tool misuse is rising. Which pair of changes best applies least privilege?",
  "Restrict each subagent to its 4-5 role tools and add a narrow verify_fact tool only where fact-checking is frequent",
  ["Add more tools so subagents can recover on their own", "Give the synthesis agent the web search toolset", "Remove all descriptions to avoid bias"],
  "Scoped Tools: role-limited sets improve selection reliability. A cross-role verify_fact tool is the sanctioned exception for high-frequency simple needs.")
q("medium", T, "An engineer needs all files named *.test.tsx, then all usages of a hook called useCart. Which tools, in order?",
  "Glob for the file pattern, then Grep for the usages",
  ["Grep for both", "Glob for both", "Edit then Read"],
  "Grep vs Glob: Glob finds files by path pattern, Grep finds content. If an Edit later fails on non-unique text, the Edit Fallback is Read plus Write.")
q("medium", C, "A CI job should emit findings that a script can post as inline comments. Which two elements make the output dependable?",
  "--output-format json with a --json-schema, backed by a tool_use schema in your own extraction code",
  ["Parsing the terminal colors", "A prose summary only", "Interactive prompts for confirmation"],
  "--json-schema: constrains CI output to a defined structure. A tool_use Schema in API-based extraction gives the same syntactic guarantee, though semantic checks remain your job.")
q("hard", P, "Reviewers disagree on severity and developers keep dismissing one finding category. Which two practices address both problems?",
  "Concrete severity examples per level, and a detected_pattern field to analyze what triggers dismissed findings",
  ["Tell the model to be conservative and add confidence filters", "Raise the temperature and run twice", "Only report critical issues"],
  "Severity Criteria: examples per level standardize classification. detected_pattern: lets you trace dismissed findings back to constructs and refine prompts.")
q("hard", P, "An extraction schema has a category enum and a total field. Which design handles unexpected categories and arithmetic mistakes?",
  "An enum with \"other\" plus detail text, and calculated_total next to stated_total to flag mismatches",
  ["A closed enum and a single total", "Free text for both", "Numeric category codes and no total"],
  "Enum + other: lets categories extend without forcing wrong values. calculated_total: lets validation flag semantic discrepancies that a schema alone cannot detect.")
q("hard", P, "Some documents in a batch fail validation because of format errors, others because the data is simply missing. Which workflow is right?",
  "Match failures by custom_id, resubmit the format failures with Retry with Feedback including the validation error, and accept nulls for absent data",
  ["Retry every failure with the identical prompt", "Resubmit the entire batch", "Discard all failures"],
  "custom_id: correlates batch results to requests. Retry with Feedback: fixes format and structure errors but cannot invent information absent from the source.")
q("hard", X, "A very large pull request is reviewed in one pass and the agent also pulls 40-field records into context. Which two changes help most?",
  "Split into per-file and integration passes (Multi-Pass Review), and keep only relevant fields (Trim Tool Output)",
  ["Use a larger window and keep everything", "Ask for shorter answers", "Remove the integration step"],
  "Multi-Pass Review: avoids attention dilution. Trim Tool Output: stops irrelevant fields from consuming context.")
q("hard", X, "Customer asks for a policy exception that the written policy does not mention, and a downstream lookup times out. What should the agent do for each?",
  "Escalate the policy gap using Escalation Criteria, and return structured error context on the timeout",
  ["Approve the exception and say \"search unavailable\"", "Guess the policy and hide the timeout", "Terminate the conversation"],
  "Escalation Criteria: a policy gap is a valid trigger. Error Propagation: pass failure type, attempted query, partial results and alternatives instead of a generic status.")
q("medium", X, "A day-long exploration session is running out of context and the process may crash. Which two safeguards apply?",
  "Run /compact to shrink verbose history, and export agent state to files so a coordinator manifest can resume",
  ["Restart each hour with no notes", "Disable tools", "Rely on in-memory state"],
  "/compact: reduces context during extended exploration. Crash Recovery Manifest: persisted state lets the coordinator reload and continue rather than redo work.")
q("hard", X, "A report cites two different growth rates for the same sector from two reputable publications published in different years. What is the best presentation?",
  "Show both figures with their sources and dates, flagged as a conflict rather than silently choosing one",
  ["Report only the newer figure without comment", "Average the figures", "Omit the sector"],
  "Conflict Annotation: structured reports separate well-established from contested findings, keeping source attribution and dates so temporal differences are not misread as contradictions.")
