Q = []
def q(d, c, text, ok, wrong, ex): Q.append((d, c, text, ok, wrong, ex))
A, T, C, P, X = "agentic-architecture", "tool-design-mcp", "claude-code", "prompt-structured-output", "context-reliability"

# ---- Domain 1 ----
q("medium", A, "A research system lets the search, analysis and synthesis subagents message each other directly. Debugging failures is hard and error handling is inconsistent. Which redesign fixes this?",
  "Route all inter-agent communication through a single coordinator",
  ["Give every subagent a shared writable scratch memory", "Add a fourth subagent that monitors the other three", "Let the synthesis subagent become the coordinator"],
  "Hub-and-Spoke: the coordinator manages all communication, error handling and information routing, giving observability and controlled information flow. Subagents never talk to each other directly.")
q("medium", A, "Your coordinator's configuration lists allowedTools without \"Task\", and it never delegates to subagents. What is the cause?",
  "The Task tool is the mechanism for spawning subagents, so allowedTools must include it",
  ["Subagents can only be started from CLAUDE.md", "Coordinators must use tool_choice \"any\"", "Task is only needed for parallel, not sequential, delegation"],
  "Task Tool: spawning a subagent requires the Task tool, and the coordinator's allowedTools must list it. Without it no delegation is possible.")
q("hard", A, "A coordinator needs to research three independent subtopics and wants the lowest latency. How should it invoke the subagents?",
  "Emit three Task calls in a single response so they run concurrently",
  ["Emit one Task call per turn across three turns", "Spawn one subagent and have it spawn the rest", "Merge the three subtopics into one long subagent prompt"],
  "Parallel Subagents: multiple Task tool calls emitted in one coordinator response run in parallel, rather than being serialized across separate turns.")
q("medium", A, "You are defining a subagent type for document analysis. Which AgentDefinition contents matter most?",
  "A clear description, a focused system prompt, and a restricted tool list for that role",
  ["Only the model name", "The coordinator's full conversation history", "A list of every tool available in the system"],
  "AgentDefinition: each subagent type is configured with a description (so the coordinator picks it correctly), a system prompt, and tool restrictions limiting it to what its role needs.")
q("hard", A, "Three MCP tools return timestamps as Unix epoch, ISO 8601 and a numeric status code. Which mechanism lets the agent see consistent data without relying on the model to convert?",
  "A PostToolUse hook that normalizes tool results before the model processes them",
  ["A system prompt asking the model to convert formats mentally", "A PreToolUse hook that blocks the three tools", "A few-shot example showing one conversion"],
  "PostToolUse: this hook pattern intercepts tool results and transforms them, so heterogeneous formats are normalized deterministically before the model reasons over them.")
q("hard", A, "A support agent skips identity verification in 12% of runs before calling process_refund. Refunds are financial operations. Which fix gives a deterministic guarantee?",
  "Programmatic prerequisite gates that block process_refund until get_customer has returned a verified customer ID",
  ["A stronger sentence in the system prompt", "More few-shot examples of verification first", "Lowering the model temperature"],
  "Prerequisite Gates: when ordering is a hard business rule, programmatic gates or hooks enforce it. Prompt instructions alone have a non-zero failure rate.")
q("medium", A, "A 14-file pull request needs consistent depth on every file plus detection of cross-file issues. Which decomposition fits a predictable multi-aspect review?",
  "Prompt chaining: analyze each file individually, then run a cross-file integration pass",
  ["One pass over all 14 files with a larger context window", "Three identical passes with majority voting", "Ask developers to open smaller pull requests"],
  "Prompt Chaining: fixed sequential steps suit predictable, multi-aspect workflows like per-file review followed by an integration pass, avoiding attention dilution.")
q("hard", A, "You are asked to add comprehensive tests to an unfamiliar legacy codebase. Which approach matches the nature of the task?",
  "Map the structure, find high-impact areas, then build a prioritized plan that adapts as dependencies are discovered",
  ["A fixed chain that writes tests for files alphabetically", "Generate tests for every file in a single prompt", "Wait for a complete architecture document before starting"],
  "Dynamic Decomposition: open-ended investigation tasks need adaptive plans that generate subtasks from what is discovered, rather than a fixed pipeline.")
q("medium", A, "Two engineers want to compare a repository-pattern refactor against a service-layer refactor starting from the same codebase analysis. Which feature supports this?",
  "fork_session, creating independent branches from the shared analysis baseline",
  ["Resuming the same session twice", "Compacting the context between experiments", "Spawning the Explore subagent for each approach"],
  "fork_session: forks create independent branches from a shared baseline so divergent approaches can be explored without contaminating each other.")
q("hard", A, "You return to a named investigation after teammates edited several files you had analyzed. What is the best use of --resume?",
  "Resume the named session and explicitly tell it which files changed, or start fresh with a structured summary if the prior tool results are stale",
  ["Resume silently and trust the earlier tool results", "Delete the session and rely on memory", "Resume and ask it to guess what changed"],
  "--resume <session-name> continues a prior conversation, but stale tool results can mislead; inform the session of specific changes or begin a new session with injected findings.")

# ---- Domain 2 ----
q("medium", T, "A tool fails because the backend timed out. How should the MCP server report it?",
  "Return a result with the isError flag set and structured metadata describing the failure",
  ["Return a normal result containing the text \"OK\"", "Return an empty list as a success", "Terminate the MCP server process"],
  "isError: the MCP flag that marks a tool result as a failure so the agent can reason about recovery. Pair it with structured metadata rather than a generic message.")
q("hard", T, "A tool returns the same \"Operation failed\" text for bad input, a policy violation, a timeout and an access denial. Why is this harmful?",
  "The agent cannot distinguish transient, validation, business and permission failures to choose retry, correct, explain or escalate",
  ["It increases token cost only", "MCP forbids generic messages", "It makes descriptions longer"],
  "Error Categories: distinguishing transient, validation, business and permission errors lets the agent pick the right recovery. Uniform errors remove that signal.")
q("hard", T, "A business-rule violation (refund outside policy) is returned with a generic retryable-looking error and the agent retries it five times. What metadata prevents this?",
  "An isRetryable: false flag with a customer-friendly explanation of the rule",
  ["A longer stack trace", "A higher max_tokens", "A different tool name"],
  "isRetryable: structured retryability metadata prevents wasted retries on non-retryable errors and lets the agent explain business rules to the customer.")
q("medium", T, "An agent with 18 tools often misuses them, such as a synthesis agent attempting web searches. What principle fixes this?",
  "Scoped tools: give each agent only the 4-5 tools its role requires, plus limited cross-role tools for frequent needs",
  ["Give the agent all tools so it can self-correct", "Remove all tool descriptions", "Raise the temperature to diversify choices"],
  "Scoped Tools: too many tools degrade selection reliability, and tools outside an agent's specialization get misused. Restrict each subagent to role-relevant tools.")
q("hard", T, "85% of the synthesis agent's verification needs are simple fact checks, and routing each through the coordinator adds latency. What is the best change?",
  "Give it a scoped verify_fact tool for simple lookups and keep complex verification routed through the coordinator",
  ["Give it every web search tool", "Batch all verifications to the end of its pass", "Pre-cache extra context around every source"],
  "verify_fact: a narrow cross-role tool covers the common case under least privilege while preserving coordination for the 15% that need deeper investigation.")
q("medium", T, "Your teammate's personal experimental MCP server should be available only to them, while the GitHub server is shared by the team. Where does each belong?",
  "The shared server in project .mcp.json; the personal one in user-level ~/.claude.json",
  ["Both in ~/.claude.json", "Both in CLAUDE.md", "The shared server in ~/.claude.json and the personal one in .mcp.json"],
  "~/.claude.json: user-scoped configuration for personal or experimental MCP servers. Project-scoped .mcp.json is version-controlled for shared tooling, using ${ENV_VAR} expansion for tokens.")
q("easy", T, "You need every call site of a function named calculateTax. Which built-in tool, and why not the other?",
  "Grep, because it searches file contents; Glob only matches file paths",
  ["Glob, because it searches file contents; Grep only matches file paths", "Read, because it scans the whole repo", "Write, because it can list files"],
  "Grep vs Glob: Grep searches content (function names, error messages, imports); Glob matches file paths by pattern such as **/*.test.tsx.")
q("hard", T, "Edit fails because the text you want to change appears more than once. What is the reliable fallback?",
  "Read the whole file, then Write the modified full contents",
  ["Retry Edit until it succeeds", "Use Glob to locate the text", "Delete the file and recreate it from memory"],
  "Edit Fallback: when Edit cannot find a unique anchor, use Read plus Write so the full file is changed reliably.")

# ---- Domain 3 ----
q("medium", C, "A large CLAUDE.md mixes testing, API and deployment standards. How do you keep it modular?",
  "Use @import to pull in focused standards files, or split topics into .claude/rules/",
  ["Duplicate the whole file in every directory", "Move everything to ~/.claude/CLAUDE.md", "Put it all in a skill"],
  "@import: the import syntax references external files so each package's CLAUDE.md can include only the standards relevant to it.")
q("hard", C, "Test files live next to source across dozens of directories, and all must follow one convention. What loads those rules automatically?",
  "Path-specific rules: a .claude/rules file with paths: [\"**/*.test.tsx\"] frontmatter",
  ["A CLAUDE.md in each directory", "A skill the developer invokes manually", "One root CLAUDE.md that relies on inference"],
  "Path-Specific Rules: glob patterns activate conventions by file type regardless of directory, and the rules load only when editing matching files.")
q("easy", C, "You want a /review command every teammate gets after cloning. Where do slash commands for the whole team live?",
  ".claude/commands/ in the project repository; ~/.claude/commands/ is personal",
  ["~/.claude/commands/ on each machine", "In settings.json under a commands array", "In .mcp.json"],
  "Slash Commands: project-scoped commands in .claude/commands/ are shared through version control, while ~/.claude/commands/ holds personal ones.")
q("medium", C, "A skill that analyzes the whole codebase floods the main conversation with output. Which SKILL.md option isolates it?",
  "context: fork, which runs the skill in an isolated sub-agent context",
  ["allowed-tools: Read", "argument-hint: verbose", "Placing it in ~/.claude/skills/"],
  "context: fork: runs a skill in an isolated context so verbose or exploratory output does not pollute the main session; combine with allowed-tools to restrict actions.")
q("medium", C, "During a library migration affecting 45 files, discovery output keeps filling the context. Which feature helps?",
  "The Explore subagent, which isolates verbose discovery and returns a summary",
  ["Direct execution without exploration", "A longer CLAUDE.md", "Disabling plan mode"],
  "Explore Subagent: delegating discovery to it preserves main-conversation context during multi-phase tasks by returning only summaries.")
q("easy", C, "A CI step runs claude \"Analyze this PR\" and hangs. What is the documented fix?",
  "Run it non-interactively with the -p / --print flag",
  ["Set CLAUDE_HEADLESS=true", "Add a --batch flag", "Redirect stdin from /dev/null only"],
  "-p / --print: processes the prompt, prints to stdout and exits without waiting for interactive input, which is what automated pipelines require.")
q("medium", C, "A CI job must post findings as inline pull request comments automatically. Which output configuration makes that reliable?",
  "--output-format json together with a --json-schema describing the findings",
  ["Plain text output parsed with regex", "The -v verbose flag", "A markdown report posted manually"],
  "--json-schema: with --output-format json it yields machine-parseable structured findings that can be mapped to inline comments.")
q("hard", C, "The session that generated a change is also asked to review it, and it rarely finds problems. What is more effective?",
  "An independent review instance without the generator's reasoning context",
  ["Asking the same session to be more critical", "Enabling extended thinking in the same session", "Reviewing with a smaller context window"],
  "Independent Review: a model keeps its reasoning context from generation and is less likely to question its own decisions; a fresh instance catches subtler issues.")

# ---- Domain 4 ----
q("hard", P, "A code-review prompt generates many findings that developers dismiss, and trust is eroding. Which action targets the cause?",
  "Define explicit categories to report versus skip, and temporarily disable the highest false-positive category while refining it",
  ["Tell the model to be more conservative", "Only report findings with high self-reported confidence", "Increase the number of review passes"],
  "False Positives: high false-positive categories undermine confidence in accurate ones. Specific categorical criteria and disabling noisy categories restore developer trust.")
q("medium", P, "Reviewers label severity inconsistently across runs. What produces consistent classification?",
  "Explicit severity criteria with concrete code examples for each level",
  ["Free-form severity words chosen by the model", "A single severity called \"issue\"", "Removing severity from the output"],
  "Severity Criteria: defining each level with concrete code examples gives the model stable decision boundaries.")
q("medium", P, "You need guaranteed schema-compliant JSON from Claude for downstream systems. Which technique is the most reliable?",
  "Define an extraction tool whose input schema is the target JSON schema, and read the tool_use block",
  ["Ask politely for JSON in the system prompt", "Parse prose with regular expressions", "Set temperature to 0"],
  "tool_use Schema: tool use with JSON schemas eliminates syntax errors. It does not guarantee semantic correctness, so validation is still needed.")
q("hard", P, "Some invoices have no tax ID, yet the schema marks tax_id required and the model sometimes invents one. What should change?",
  "Make the field nullable/optional so the model returns null instead of fabricating a value",
  ["Keep it required and add a default of \"N/A\"", "Remove validation", "Raise max_tokens"],
  "Nullable Fields: optional/nullable schema fields prevent the model from fabricating values just to satisfy required fields.")
q("medium", P, "A category field might encounter types you did not anticipate. Which schema design is recommended?",
  "An enum with an \"other\" value plus a detail string, and an \"unclear\" value for ambiguous cases",
  ["A closed enum with no escape value", "A free-text field only", "Numeric codes only"],
  "Enum + other: extensible categorization uses an \"other\" value with a detail string, and \"unclear\" for ambiguity, instead of forcing wrong categories.")
q("hard", P, "An extraction fails validation because a date came back as \"3rd of May\" instead of ISO 8601. What retry works best?",
  "Resend the original document, the failed extraction and the specific validation error",
  ["Resubmit the identical request unchanged", "Increase max_tokens", "Skip the field"],
  "Retry with Feedback: appending the specific validation error guides the model to correct format or structural mistakes, but it cannot fix information absent from the source.")
q("hard", P, "Which extra fields help catch an invoice whose line items do not add up to the stated total?",
  "A calculated_total extracted alongside stated_total, with a conflict flag when they differ",
  ["Only stated_total", "A longer description field", "A confidence score of 1-10 only"],
  "calculated_total: comparing it against stated_total is a self-correction validation pattern that flags semantic discrepancies a schema cannot catch.")
q("medium", P, "Developers dismiss many automated review findings. How do you analyze dismissal patterns systematically?",
  "Include a detected_pattern field naming the code construct that triggered each finding",
  ["Delete dismissed findings", "Ask developers to write explanations", "Raise the temperature"],
  "detected_pattern: tracking which constructs trigger findings lets you analyze false-positive and dismissal patterns and improve the prompt.")
q("easy", P, "A weekly audit of 10,000 documents has no urgency and the team wants lower cost. Which API fits?",
  "The Message Batches API: 50% cheaper, up to 24 hours, no guaranteed latency",
  ["Synchronous calls with streaming", "The batch API for the blocking pre-merge check", "A smaller max_tokens only"],
  "Message Batches API: ideal for latency-tolerant work, unsuitable for blocking workflows, and it cannot run multi-turn tool calls inside one request.")
q("medium", P, "After a batch of 100 documents completes, 7 results failed. How do you identify and resubmit only those?",
  "Match results to requests by custom_id and resubmit just the failures, with fixes such as chunking",
  ["Rely on the order of the results", "Resubmit all 100", "Discard failed documents"],
  "custom_id: the identifier you assign to each batch request, used to correlate responses and to resubmit only failed items.")
q("hard", P, "A 14-file PR review produces contradictory comments about the same pattern in different files. Which structure fixes it?",
  "Multi-pass review: focused per-file passes for local issues, then an integration pass for cross-file data flow",
  ["Three full-PR runs, keeping findings that appear twice", "A bigger context window with one pass", "Require PRs under four files"],
  "Multi-Pass Review: splitting work avoids attention dilution; majority-voting on full-PR runs would suppress real bugs found only intermittently.")

# ---- Domain 5 ----
q("hard", X, "A long support chat is summarized repeatedly, and the final summary says \"customer wants a refund\" while dropping $84.50 and order 7731. What should have been done?",
  "Extract transactional facts into a persistent case facts block included in every prompt, outside the summarized history",
  ["Summarize even more aggressively", "Drop numeric details to save tokens", "Ask the customer to repeat the facts"],
  "Case Facts Block: amounts, dates, order numbers and statuses are persisted verbatim so progressive summarization cannot erase them.")
q("medium", X, "A synthesis agent drops findings that sit in the middle of a very long aggregated input. What mitigates this?",
  "Place key findings summaries first and organize detailed results under explicit section headers",
  ["Shuffle the order every request", "Remove all headers", "Duplicate the middle content at random"],
  "Lost in the Middle: models process the beginning and end of long inputs most reliably, so put key summaries up front and use headers to counter position effects.")
q("medium", X, "A 40-field order lookup is called repeatedly, but only 5 fields matter for returns. What should you do?",
  "Trim tool output to the relevant fields before it accumulates in context",
  ["Pass all 40 fields and rely on the model to ignore the rest", "Increase max_tokens", "Disable the tool"],
  "Trim Tool Output: verbose tool results consume tokens disproportionate to their relevance; keep only the fields needed.")
q("hard", X, "An agent escalates easy damage-replacement cases but tries to handle policy exceptions alone. First fix?",
  "Add explicit escalation criteria with few-shot examples showing when to escalate versus resolve",
  ["Escalate when self-reported confidence is low", "Add sentiment analysis", "Train a separate classifier"],
  "Escalation Criteria: human request, policy exception or gap, and inability to progress. Self-Reported Confidence and sentiment are poor proxies for case complexity.")
q("hard", X, "A subagent's web search times out. What should it send the coordinator?",
  "Structured error context: failure type, attempted query, partial results and possible alternatives",
  ["\"search unavailable\"", "An empty result marked successful", "Nothing, so the workflow continues quietly"],
  "Error Propagation: structured context enables intelligent coordinator recovery. Generic statuses hide information; swallowing errors or aborting the whole workflow are both anti-patterns.")
q("medium", X, "A subagent hits a transient timeout. What is the right division of responsibility?",
  "The subagent retries locally, and only unresolved errors with partial results propagate to the coordinator",
  ["Propagate every transient failure to the user", "Never retry", "Terminate the whole workflow"],
  "Local Recovery: transient failures are handled within the subagent first; only errors that cannot be resolved locally are propagated, with what was attempted.")
q("medium", X, "In a long codebase exploration the agent starts citing \"typical patterns\" instead of specific classes found earlier. What helps?",
  "Maintain scratchpad files with key findings, reference them, and run /compact when context fills",
  ["Restart without any notes", "Raise the temperature", "Ignore it, since summaries are lossless"],
  "Scratchpad Files: persist key findings across context boundaries. /compact reduces context usage during extended sessions when verbose discovery output piles up.")
q("hard", X, "A multi-agent pipeline crashes mid-run. How should recovery work?",
  "Each agent exports state to a known location and the coordinator loads a manifest on resume and injects it into prompts",
  ["Restart from scratch", "Rely on in-memory state", "Ask the user to re-enter everything"],
  "Crash Recovery Manifest: structured state exports let the coordinator resume instead of repeating completed work.")
q("hard", X, "Overall extraction accuracy is 97%, and the team wants to automate review for high-confidence results. What should come first?",
  "Stratified random sampling and accuracy analysis by document type and field",
  ["Trust the aggregate figure", "Remove human review immediately", "Sample only the lowest-confidence items"],
  "Stratified Sampling: aggregate accuracy can mask poor performance on specific document types or fields, so measure error rates per segment and detect novel error patterns.")
q("hard", X, "Two credible sources report different market-size figures for the same year, and the synthesis agent silently picks one. What is the correct handling?",
  "Preserve both values with source attribution and annotate the conflict, with dates to avoid false contradictions",
  ["Average the values", "Keep the larger value only", "Drop the statistic"],
  "Conflict Annotation: keep both values with sources and publication dates. Claim-Source Mapping must survive summarization so provenance is not lost in synthesis.")
q("medium", X, "A synthesis step compresses findings and the report loses which source supported which claim. What should subagents provide?",
  "Structured claim-source mappings (URL or document, excerpt, date) that downstream agents preserve and merge",
  ["Plain prose summaries without citations", "Only a list of URLs at the end", "A single confidence number"],
  "Claim-Source Mapping: structured mappings preserve attribution through summarization and synthesis; reports should separate well-established from contested findings.")
q("medium", X, "A new agent keeps asking the model for a 1-10 confidence score before deciding to escalate. Why is this a weak design?",
  "Self-reported confidence is poorly calibrated, since the agent is often already confident on hard cases",
  ["Models cannot output numbers", "Confidence scores are banned by the API", "It adds one extra token"],
  "Self-Reported Confidence: not a reliable proxy for complexity. Field-level confidence is useful only when calibrated with labeled validation sets.")
q("medium", X, "Summaries of a multi-turn session keep losing customer-stated expectations such as \"by Friday\". Which risk is this?",
  "Progressive summarization condenses numbers, dates and expectations into vague text",
  ["Lost tokens in the system prompt", "A bug in tool_choice", "Prompt injection"],
  "Progressive Summarization: repeated condensing drops numerical values, percentages, dates and customer expectations, so keep them in a case facts block.")
