Q = []
def q(d, c, text, ok, wrong, ex): Q.append((d, c, text, ok, wrong, ex))
SB,MS,SEC,ORM,RX,TST,MQ,API = "Spring Boot","Microservices","Security","ORM/Hibernate","WebFlux","Testing","Message Queues","REST API"

q("easy",SB,"In the Spring Framework, what does the IoC Container do?",
  "It creates, wires and manages the lifecycle of application objects (beans) and injects their dependencies",
  ["It compiles Java code to bytecode", "It only serves HTTP requests", "It replaces the JVM garbage collector"],
  "IoC Container: the ApplicationContext instantiates and wires Spring Beans, inverting control of object creation from your code to the framework. Spring Framework is the base on which Spring Boot is built.")
q("medium",SB,"Two beans implement PaymentGateway and injection of PaymentGateway fails with NoUniqueBeanDefinitionException. Which annotation chooses the right one at the injection point?",
  "@Qualifier with the bean name",
  ["@Lazy", "@Scope(\"prototype\")", "@Profile"],
  "@Qualifier: disambiguates among multiple Spring Beans of the same type; @Primary marks a default candidate.")
q("medium",SB,"What does Spring Boot's Auto Configuration do?",
  "It registers beans automatically based on the classpath and properties, using conditional annotations such as @ConditionalOnClass",
  ["It generates SQL schemas for every entity", "It deploys the app to the cloud", "It disables component scanning"],
  "Auto Configuration: Boot applies configuration classes conditionally, backing off when you define your own bean. Starter Dependencies supply the libraries that trigger it.")
q("easy",SB,"Why do projects declare spring-boot-starter-web instead of listing every web library?",
  "Starter Dependencies bundle a curated, version-compatible set of libraries for a feature",
  ["Starters compile the code faster", "Starters replace Maven", "They are required for Java 17"],
  "Starter Dependencies: a single dependency pulls in compatible transitive libraries, including an Embedded Tomcat server for web starters.")
q("medium",SB,"How is a Spring Boot application typically packaged and run in a container?",
  "As an executable Fat JAR with an Embedded Tomcat, started with java -jar",
  ["As a WAR that must be deployed to an external Tomcat", "As a set of loose class files", "As a native Windows installer"],
  "Fat JAR: Maven or Gradle plugins repackage the app with its dependencies. Embedded Tomcat is the default servlet container, so no external server is needed.")
q("medium",SB,"Which build tool pairing is correct for creating the executable archive?",
  "The Spring Boot plugin for Maven or Gradle repackages the JAR",
  ["Only Ant can build Boot apps", "javac alone", "The JRE builds it at runtime"],
  "Gradle: supports the spring-boot plugin and bootJar task just as Maven does with its Boot plugin, producing a Fat JAR.")
q("hard",SB,"A @Transactional method calls another @Transactional method in the same class and the second annotation has no effect. Why?",
  "Spring AOP is Proxy-based AOP, so calls inside the same object bypass the proxy",
  ["Transactions only work on static methods", "The JVM ignores annotations", "Self-invocation is cached"],
  "Spring AOP: implemented with JDK dynamic or CGLIB proxies, so self-invocation skips advice. Proxy-based AOP only intercepts calls arriving through the proxy.")
q("hard",SB,"When would you pick AspectJ over Spring AOP?",
  "When you need to advise field access, constructors or non-Spring objects, using compile-time or load-time weaving",
  ["When you want less setup", "When advising only Spring bean methods", "Never, they are identical"],
  "AspectJ: a full AOP implementation using weaving, broader than Spring AOP's proxy approach, which is limited to method execution on beans.")
q("medium",ORM,"What is the JPA EntityManager responsible for?",
  "Managing the persistence context and entity lifecycle, and executing queries",
  ["Opening HTTP connections", "Scheduling cron jobs", "Compiling JPQL to Java"],
  "EntityManager: the central JPA API, backing Spring Data JPA Repositories. Lazy Loading of associations depends on it being open.")
q("easy",ORM,"Which interface gives you save, findById and deleteById without writing code in Spring Data?",
  "CrudRepository (extended by JpaRepository)",
  ["EntityManagerFactory", "DataSource", "TransactionTemplate"],
  "CRUDRepository: the CrudRepository base interface provides generic CRUD methods; JPA Repositories declare an interface and Spring generates the implementation.")
q("hard",ORM,"What does Spring Transaction Management roll back by default?",
  "Unchecked exceptions (RuntimeException and Error); checked exceptions commit unless rollbackFor is set",
  ["All exceptions including checked ones", "Only SQL exceptions", "Nothing unless configured in XML"],
  "Transaction Management: declarative @Transactional works through a proxy and defaults to rollback on unchecked exceptions.")
q("hard",ORM,"A controller accesses order.getItems() after the transaction ended and gets LazyInitializationException. What is the best fix?",
  "Fetch what you need inside the transaction, for example with a fetch join, entity graph or DTO projection",
  ["Make every association EAGER globally", "Disable the persistence context", "Catch and ignore the exception"],
  "Lazy Loading: associations load on access and need an open session; prefer targeted fetching over global EAGER mapping, and use DTO Mapping to return only needed fields.")
q("medium",API,"Why map entities to DTOs in a REST API?",
  "To avoid exposing internal entity structure and lazy associations, using DTO mapping such as MapStruct",
  ["DTOs are faster than JSON", "Entities cannot be serialized", "It removes the need for validation"],
  "DTO Mapping: decouples API contracts from persistence models and prevents over-posting and lazy-loading problems. MapStruct generates the mappers at compile time.")
q("easy",API,"How do you document a Spring Boot REST API automatically?",
  "Use springdoc to generate an OpenAPI/Swagger specification and UI",
  ["Write HTML by hand", "Enable JMX", "Use Hibernate Envers"],
  "OpenAPI/Swagger: generates a machine-readable contract and interactive docs from controllers and annotations.")
q("medium",MS,"Where should configuration for dozens of microservices be centralized?",
  "In Spring Cloud Config, served by a Config Server backed by a Git repository",
  ["Hard-coded in each JAR", "In the database", "In browser local storage"],
  "Spring Cloud Config: Distributed Configuration and Externalized Config keep settings outside the artifact so the same build runs in every environment.")
q("medium",MS,"A service must find other services whose instances scale up and down. Which pattern and tool?",
  "Service Discovery, for example with Eureka or Kubernetes DNS",
  ["Hard-coded IP addresses", "A shared spreadsheet", "A cron job that edits hosts files"],
  "Service Discovery: instances register with a registry such as Eureka, and clients resolve logical names rather than fixed addresses.")
q("hard",MS,"A downstream service is slow and exhausts the caller's threads. Which Resilience4j pattern isolates resources per dependency?",
  "Bulkhead, optionally with Retry and a Rate Limiter",
  ["Singleton", "Factory", "Adapter"],
  "Bulkhead: caps concurrent calls to protect other work. Retry repeats transient failures; Rate Limiter bounds request rate.")
q("medium",MS,"Which Spring Cloud component provides declarative HTTP clients between services?",
  "OpenFeign (Feign Client)",
  ["JdbcTemplate", "Thymeleaf", "Flyway"],
  "Feign Client: you declare an interface annotated with @FeignClient and Spring generates the REST client, usually combined with load balancing and resilience.")
q("medium",MQ,"Which Spring project simplifies producing and consuming Kafka messages?",
  "Spring Kafka, with KafkaTemplate and @KafkaListener",
  ["Spring Batch only", "Spring Data JPA", "Spring Security"],
  "Spring Kafka: integrates Kafka producers and consumers with the Spring programming model. Kafka Streams is a separate stream-processing library that can run inside a Spring app.")
q("hard",MQ,"Which statement about Kafka Streams is correct?",
  "It is a client library for stateful stream processing that runs inside your application, without a separate cluster",
  ["It is a separate cluster product", "It replaces Kafka brokers", "It only works with RabbitMQ"],
  "Kafka Streams: a library for transformations, joins and aggregations on topics. Spring Kafka offers integration support.")
q("easy",MQ,"Which Spring module integrates RabbitMQ using the AMQP protocol?",
  "Spring AMQP, with RabbitTemplate and @RabbitListener",
  ["Spring MVC", "Spring Data Redis", "Spring Cloud Gateway"],
  "Spring AMQP: the abstraction for AMQP brokers such as RabbitMQ, in an Event-Driven design.")
q("hard",MQ,"A bank wants an audit-complete history where state is rebuilt from past facts. Which pattern fits?",
  "Event Sourcing, storing every state change as an immutable event in an Event-Driven architecture",
  ["Overwriting rows in place", "Caching only", "Two-phase commit"],
  "Event Sourcing: the event log is the source of truth and current state is a projection. Event-Driven systems communicate through events rather than direct calls.")
q("medium",RX,"What is the core idea of Reactive Programming in Spring WebFlux?",
  "Non-Blocking I/O with asynchronous streams and backpressure, so a few threads serve many requests",
  ["One thread per request always", "Blocking JDBC everywhere", "Synchronous servlet only"],
  "Reactive Programming: uses Non-Blocking I/O on an event loop (Netty by default) and signals demand with backpressure.")
q("easy",RX,"In Project Reactor, what do Mono and Flux represent?",
  "Mono emits 0 or 1 element and Flux emits 0 to N elements",
  ["Mono is a thread and Flux is a lock", "Both emit exactly one value", "They are database types"],
  "Mono/Flux: the two reactive publisher types; nothing happens until something subscribes.")
q("medium",SEC,"A company wants single sign-on with OAuth2 and OpenID Connect and manages users centrally. Which open-source tool is commonly used?",
  "Keycloak as the identity provider",
  ["Logstash", "Hystrix", "Flyway"],
  "Keycloak: an identity and access management server supporting OIDC/OAuth2, used with Spring Security resource servers and RBAC roles.")
q("hard",SEC,"How do you restrict a service method to administrators in Spring Security 6?",
  "Enable Method Security and annotate with @PreAuthorize(\"hasRole('ADMIN')\")",
  ["Rename the method", "Use @Transactional", "Set server.port"],
  "Method Security: annotations like @PreAuthorize enforce RBAC at the method level, via @EnableMethodSecurity.")
q("hard",MS,"In Spring Boot 3, which tracing approach replaced Spring Cloud Sleuth, and where can traces be sent?",
  "Micrometer Tracing, exporting to a backend such as Zipkin",
  ["JMX beans", "Logback only", "Hibernate statistics"],
  "Sleuth: supported Spring Boot 2.x distributed tracing, superseded by Micrometer Tracing in Boot 3. Zipkin stores and visualizes traces.")
q("medium",TST,"What is the purpose of Mockito in a unit test?",
  "To create mock or spy collaborators so a class can be tested in isolation",
  ["To start a database", "To build a Docker image", "To package a JAR"],
  "Mockito: a mocking framework; combine with @MockBean in Spring tests. It does not replace Integration Testing with real components.")
q("medium",TST,"You need an integration test against a real PostgreSQL rather than H2. Which approach is best?",
  "TestContainers running a disposable PostgreSQL container, used with @SpringBootTest",
  ["Mock the repository", "Use production credentials", "Skip tests"],
  "TestContainers: starts real dependencies in Docker for Integration Testing, giving production-like behavior within @SpringBootTest.")
q("hard",TST,"Which statement about Integration Testing in Spring Boot is correct?",
  "@SpringBootTest loads the application context so beans, configuration and wiring are tested together",
  ["It never loads beans", "It replaces unit tests", "It requires an external Tomcat"],
  "Integration Testing: verifies components working together, unlike isolated Mockito unit tests.")
q("medium",SB,"Which statement best describes Spring Beans?",
  "They are objects instantiated, configured and managed by the Spring IoC container, singleton by default",
  ["They are only JDBC connections", "They are always prototypes", "They are HTML templates"],
  "Spring Beans: managed objects defined through annotations, Java config or XML; singleton is the default scope within the Spring Framework.")
q("medium",MS,"Where do Externalized Config and Distributed Configuration meet in Spring Boot?",
  "Properties can come from environment variables, config files and a Config Server, overriding packaged defaults",
  ["Only from application.properties inside the JAR", "Only from the database", "Only from command line"],
  "Externalized Config: Boot's property source hierarchy allows overrides without rebuilding; Spring Cloud Config adds Distributed Configuration for many services.")
q("medium",SB,"What does the Spring Framework add that plain Java does not?",
  "Dependency injection via an IoC container, AOP, transaction management and data access abstractions",
  ["A new JVM", "A replacement for HTTP", "A SQL database"],
  "Spring Framework: provides the core programming and configuration model. Spring Boot adds Auto Configuration and Starter Dependencies on top.")
