const fs=require('fs'),vm=require('vm');
const html=fs.readFileSync('index.html','utf8');const ctx={};vm.createContext(ctx);
const re=/^const (\w+Keywords) = \[/gm;let m;
while((m=re.exec(html))){let i=html.indexOf('[',m.index),d=0,j=i;for(;j<html.length;j++){if(html[j]=='[')d++;else if(html[j]==']'){d--;if(d==0)break;}}vm.runInContext('var '+m[1]+'='+html.slice(i,j+1),ctx);}
const map=JSON.parse(process.env.MAP||'{}');
const BAR=+process.env.BAR||2;
const exam=fs.readFileSync('exam.html','utf8');const em={};for(const x of exam.matchAll(/'(\w+)':\s*\{ title: '([^']*)', file: '([^']*)'/g))em[x[1]]=x[3];
const M={ai_data:'saAiDataKeywords',claude_architect:'claudeArchitectKeywords',claude_developer:'claudeDeveloperKeywords',databricks:'dbKeywords',ai:'aiKeywords',java:'javaKeywords',azure:'azKeywords',aws:'awsKeywords',mongodb:'mgKeywords',react:'rKeywords',snowflake:'snKeywords',kafka:'kfKeywords',data_architect:'dataArchitectKeywords',devOps:'devOpsKeywords',enterprise_architect:'eaKeywords',TypeScript_NestJS:'typescriptNestjsKeywords',web3_blockchain:'web3BlockChainKeywords',...map};
const only=process.argv[2];const rows=[];
for(const t of Object.keys(M)){ if(only&&t!==only)continue; if(!ctx[M[t]]||!em[t])continue;
  const c={};vm.createContext(c);vm.runInContext(fs.readFileSync(em[t],'utf8')+';this.QB=questionBank;',c);
  const need=[];let tot=0;
  for(const k of ctx[M[t]]){const w=k.word.trim().toLowerCase();
    const n=c.QB.filter(q=>q.question.toLowerCase().includes(w)||(q.category&&q.category.toLowerCase().includes(w))||(q.explanation&&q.explanation.toLowerCase().includes(w))).length;
    if(n<BAR){need.push(k.word+'('+n+')');tot+=BAR-n;}}
  rows.push([t,c.QB.length,ctx[M[t]].length,need.length,tot,need]);}
for(const r of rows){console.log(r[0].padEnd(22),'Q',r[1],'kw',r[2],'below-bar',r[3],'shortfall',r[4]); if(only)console.log(r[5].join(' | '));}
