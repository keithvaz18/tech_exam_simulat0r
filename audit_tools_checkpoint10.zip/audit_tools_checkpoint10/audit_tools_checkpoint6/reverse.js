const fs=require('fs'),vm=require('vm');
const html=fs.readFileSync('index.html','utf8');const ctx={};vm.createContext(ctx);
const re=/^const (\w+Keywords) = \[/gm;let m;
while((m=re.exec(html))){let i=html.indexOf('[',m.index),d=0,j=i;for(;j<html.length;j++){if(html[j]=='[')d++;else if(html[j]==']'){d--;if(d==0)break;}}vm.runInContext('var '+m[1]+'='+html.slice(i,j+1),ctx);}
const exam=fs.readFileSync('exam.html','utf8');const em={};for(const x of exam.matchAll(/'(\w+)':\s*\{ title: '([^']*)', file: '([^']*)'/g))em[x[1]]=x[3];
const M={databricks:'dbKeywords',ai:'aiKeywords',java:'javaKeywords',azure:'azKeywords',aws:'awsKeywords',mongodb:'mgKeywords',react:'rKeywords',snowflake:'snKeywords',kafka:'kfKeywords',data_architect:'dataArchitectKeywords',devOps:'devOpsKeywords',enterprise_architect:'eaKeywords',TypeScript_NestJS:'typescriptNestjsKeywords',web3_blockchain:'web3BlockChainKeywords'};
const stop=new Set('the a an and or of to in on for with is are be by as at it this that which what when how why from into not no only can will should would use used using your you their its than then over under more most each any all both other such these those has have had does do did was were been via per vs also but if so there here out up down off new one two three first second primary main best key common typically always never between within without across after before during while because since about like'.split(' '));
const only=process.argv[2];
for(const t of Object.keys(M)){if(only&&t!==only)continue;
  const c={};vm.createContext(c);vm.runInContext(fs.readFileSync(em[t],'utf8')+';this.Q=questionBank',c);
  const cloud=ctx[M[t]].map(k=>(k.word||'').toLowerCase());
  const cnt={};
  for(const q of c.Q){const txt=(q.question+' '+q.options.join(' ')+' '+(q.explanation||'')).replace(/[^A-Za-z0-9_\-\/\.\+# ]/g,' ');
    const toks=txt.split(/\s+/).filter(Boolean);const seen=new Set();
    for(let i=0;i<toks.length;i++){
      for(const n of [1,2]){const g=toks.slice(i,i+n);if(g.length<n)continue;
        if(stop.has(g[0].toLowerCase())||stop.has(g[n-1].toLowerCase()))continue;
        const s=g.join(' ');if(s.length<3)continue;
        // technical-looking: capitalised or has digit/symbol/camel
        if(!/^[A-Z]/.test(g[0])&&!/[0-9_\/\.\-]/.test(s)&&!/[a-z][A-Z]/.test(s))continue;
        const k=s.toLowerCase();if(!seen.has(k)){seen.add(k);cnt[k]=(cnt[k]||0)+1;}}}}
  const top=Object.entries(cnt).filter(([k,v])=>v>=8&&!cloud.some(w=>w&&(k.includes(w)||w.includes(k)))).sort((a,b)=>b[1]-a[1]).slice(0,28);
  console.log('## '+t+' ('+c.Q.length+'q, cloud '+cloud.length+')\n'+top.map(([k,v])=>k+'('+v+')').join(' | '));}
