const fs=require('fs'),vm=require('vm'),path=require('path');
const rank={hard:0,medium:1,easy:2};
for(const fn of fs.readdirSync('js').filter(f=>/^questionBank_.*\.js$/.test(f))){
  const p='js/'+fn;let src=fs.readFileSync(p,'utf8');
  if(!/const\s+hotsQuestions\s*=\s*\[/.test(src))continue;
  const c={};vm.createContext(c);
  try{vm.runInContext(src+';this.Q=questionBank;this.H=hotsQuestions;',c);}catch(e){console.log('skip',fn);continue;}
  const ids=new Set(c.Q.map(q=>q.id)),valid=[...new Set(c.H.filter(i=>ids.has(i)))];
  if(valid.length>=100)continue;
  const have=new Set(valid),pool=c.Q.filter(q=>!have.has(q.id)).sort((a,b)=>(rank[a.difficulty]??1)-(rank[b.difficulty]??1)||a.id-b.id);
  const add=pool.slice(0,100-valid.length).map(q=>q.id);
  const i=src.search(/const\s+hotsQuestions\s*=\s*\[/),j=src.indexOf('];',i);
  let body=src.slice(i,j).replace(/[\s,]*$/,'');
  src=src.slice(0,i)+body+',\n\n    // Top-up: replaced stale ids with hardest unlisted questions\n    '+add.join(', ')+'\n'+src.slice(j);
  fs.writeFileSync(p,src);console.log(fn,'valid',valid.length,'added',add.length);
}
