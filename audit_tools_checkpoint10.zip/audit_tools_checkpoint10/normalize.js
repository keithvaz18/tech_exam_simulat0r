const fs=require('fs'),vm=require('vm');
const dir='js';const stats={};
function rng(seed){let s=seed>>>0;return()=>((s=(s*1664525+1013904223)>>>0)/4294967296)}
const REF=/\b(both|all of the above|none of the above|neither|a and b|a & b|b and c|a, b|options? [a-d]\b|statements? [a-c1-3])/i;
const EXREF=/\b(option|choice|answer|statement) ?\(?[A-D]\)?\b|\b[A-D]\) /;
for(const fn of fs.readdirSync(dir).filter(f=>/^questionBank_.*\.js$/.test(f))){
  const src=fs.readFileSync(dir+'/'+fn,'utf8');
  const c={};vm.createContext(c);vm.runInContext(src+';this.Q=questionBank',c);
  const Q=c.Q;const st={fixedAns:0,diff:0,prefix:0,shuffled:0,skipped:0};
  const rnd=rng(fn.length*7919+Q.length);
  for(const q of Q){
    // manual fixes
    if(fn.includes('AWS')&&q.id===359){q.question="A company wants to prevent accidental permanent deletion of objects in an S3 bucket. Which feature requires a second authentication factor to permanently delete an object version?";q.answer=1;}
    if(fn.includes('react')&&q.id===17){q.options[3]="<!-- comment -->";}
    // strip letter prefixes
    if(q.options.every(o=>/^[A-F][\)\.] /.test(o))){q.options=q.options.map(o=>o.replace(/^[A-F][\)\.] /,''));st.prefix++;}
    // normalise answer
    let a=q.answer;
    if(a===undefined&&q.correctAnswer!==undefined)a=q.correctAnswer;
    if(typeof a==='string'){
      if(/^[A-F]$/i.test(a.trim()))a=a.trim().toUpperCase().charCodeAt(0)-65;
      else{const k=q.options.findIndex(o=>o.trim().toLowerCase()===a.trim().toLowerCase());a=k;}
    }
    if(Array.isArray(a))throw new Error('array answer left '+fn+q.id);
    if(a!==q.answer||q.correctAnswer!==undefined)st.fixedAns++;
    q.answer=a;delete q.correctAnswer;
    if(!Number.isInteger(a)||a<0||a>=q.options.length)throw new Error('bad ans '+fn+' '+q.id);
    if(!q.difficulty){q.difficulty='hard';st.diff++;}
    // shuffle
    const eligible=!q.options.some(o=>REF.test(o))&&!EXREF.test(q.explanation||'')&&!EXREF.test(q.question||'')&&q.options.length>=3;
    if(!eligible){st.skipped++;continue;}
    const ok=q.options[a];const rest=q.options.filter((_,j)=>j!==a);
    for(let j=rest.length-1;j>0;j--){const k=Math.floor(rnd()*(j+1));[rest[j],rest[k]]=[rest[k],rest[j]];}
    const tgt=Math.floor(rnd()*q.options.length);rest.splice(tgt,0,ok);
    q.options=rest;q.answer=tgt;st.shuffled++;
  }
  const hi=src.search(/^const hotsQuestions/m);
  let tail='';
  if(hi>=0){let lines=src.slice(0,hi).split('\n');let k=lines.length-1;while(k>0&&/^\s*(\/\/|\/\*|\*)/.test(lines[k-1]))k--;tail=lines.slice(k).join('\n')+src.slice(hi);}
  const hm=src.match(/^\/\*[\s\S]*?\*\//);const head=hm?hm[0].replace(/\(Batch[^)]*\)/,'').replace(/\n\s*Topics:[^\n]*/,''):'';
  fs.writeFileSync(dir+'/'+fn,(head?head+'\n\n':'')+'const questionBank = '+JSON.stringify(Q,null,2)+';\n\n'+tail);
  stats[fn.replace('questionBank_','')]=st;
}
console.table(stats);
