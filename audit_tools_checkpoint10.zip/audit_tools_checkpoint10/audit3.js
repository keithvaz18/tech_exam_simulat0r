const fs=require('fs'),vm=require('vm');
const html=fs.readFileSync('index.html','utf8');const ctx={};vm.createContext(ctx);
const re=/^const (\w+Keywords) = \[/gm;let m;
while((m=re.exec(html))){let i=html.indexOf('[',m.index),d=0,j=i;for(;j<html.length;j++){if(html[j]=='[')d++;else if(html[j]==']'){d--;if(d==0)break;}}vm.runInContext('var '+m[1]+'='+html.slice(i,j+1),ctx);}
const css=fs.readFileSync('css/styles.css','utf8')+html.slice(0,html.indexOf('<body'));
for(const n of Object.keys(ctx)){
  const bad=ctx[n].filter(k=>!k.domain);const noDesc=ctx[n].filter(k=>!k.desc).length;const noFreq=ctx[n].filter(k=>!k.freq||k.freq<1||k.freq>5).length;
  const doms=[...new Set(ctx[n].filter(k=>k.domain).flatMap(k=>k.domain.split(/\s+/)))];
  const miss=doms.filter(d=>!new RegExp('\\.'+d.replace(/[-.]/g,'\\$&')+'(?![\\w-])').test(css));
  console.log(n.padEnd(28),'kw',String(ctx[n].length).padEnd(3),'noDomain',bad.map(k=>k.word).join(',')||0,'| noDesc',noDesc,'| badFreq',noFreq,'| domains w/o CSS:',miss.join(',')||'-');
}
