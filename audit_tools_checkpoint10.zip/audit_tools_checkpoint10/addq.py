import re, random, sys, json, importlib.util

def find_bank_end(src):
    m = re.search(r'(?:const|var|let)\s+questionBank\s*=\s*\[', src)
    i = m.end(); depth = 1; n = len(src)
    while i < n:
        c = src[i]
        if c in '"\'`':
            q = c; i += 1
            while i < n and src[i] != q:
                if src[i] == '\\': i += 1
                i += 1
        elif src.startswith('//', i):
            i = src.find('\n', i)
        elif src.startswith('/*', i):
            i = src.find('*/', i) + 1
        elif c == '[': depth += 1
        elif c == ']':
            depth -= 1
            if depth == 0: return i
        i += 1
    raise ValueError('bank end not found')

def js(s): return json.dumps(s, ensure_ascii=False)

def append(path, items, seed, style='compact'):
    src = open(path, encoding='utf8').read()
    ids = [int(x) for x in re.findall(r"(?<!\w)[\"']?id[\"']?\s*:\s*(\d+)", src)]
    nxt = max(ids) + 1
    end = find_bank_end(src)
    rng = random.Random(seed)
    pos = [i % 4 for i in range(len(items))]; rng.shuffle(pos)
    out = []
    for k, (d, c, q, ok, wrong, ex) in enumerate(items):
        assert len(wrong) == 3, q
        opts = wrong[:]; rng.shuffle(opts); opts.insert(pos[k], ok)
        out.append('  {\n    id: %d,\n    difficulty: %s,\n    category: %s,\n    question: %s,\n    options: [\n      %s\n    ],\n    answer: %d,\n    explanation: %s\n  }' % (
            nxt + k, js(d), js(c), js(q), ',\n      '.join(js(o) for o in opts), pos[k], js(ex)))
    body = src[:end].rstrip()
    if not body.endswith(','): body += ','
    new = body + '\n\n  /* ---- Keyword-coverage additions ---- */\n' + ',\n'.join(out) + '\n' + src[end:]
    open(path, 'w', encoding='utf8').write(new)
    return nxt, nxt + len(items) - 1

def load(modpath):
    spec = importlib.util.spec_from_file_location('m', modpath); m = importlib.util.module_from_spec(spec); spec.loader.exec_module(m); return m.Q
