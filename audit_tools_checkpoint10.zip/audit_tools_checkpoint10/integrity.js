const fs=require('fs'),vm=require('vm');
const dir=process.argv[2]||'js';let issues=0;
for(const fn of fs.readdirSync(dir).filter(f=>/^questionBank_.*\.js$/.test(f))){
  const c={};vm.createContext(c);
  try{vm.runInContext(fs.readFileSync(dir+'/'+fn,'utf8')+';this.Q=questionBank',c);}catch(e){console.log(fn,'PARSE',e.message);issues++;continue;}
  const Q=c.Q,r={badAns:[],dupOpt:[],emptyOpt:[],dupId:[]},ids=new Set();const pos=[0,0,0,0,0,0];
  for(const q of Q){
    if(ids.has(q.id))r.dupId.push(q.id);ids.add(q.id);
    if(!Number.isInteger(q.answer)||q.answer<0||q.answer>=q.options.length)r.badAns.push(q.id);else pos[q.answer]++;
    const lo=q.options.map(o=>String(o).trim().toLowerCase());
    if(new Set(lo).size!==lo.length)r.dupOpt.push(q.id);if(lo.some(o=>!o))r.emptyOpt.push(q.id);
  }
  const bad=Object.entries(r).filter(([k,v])=>v.length).map(([k,v])=>k+':'+v.length+'['+v.slice(0,6)+']');
  console.log(fn.replace('questionBank_','').padEnd26?'':'',fn.replace('questionBank_','').padEnd(28),String(Q.length).padStart(4),pos.slice(0,4).map(x=>Math.round(100*x/Q.length)+'%').join('/').padEnd(16),bad.join(' ')||'OK');
  if(bad.length)issues++;
}
console.log('banks with issues',issues);
