const fs=require('fs'),vm=require('vm');
function load(p){const c={};vm.createContext(c);vm.runInContext(fs.readFileSync(p,'utf8')+';this.Q=questionBank;this.H=(typeof hotsQuestions!=="undefined")?hotsQuestions:[]',c);return c;}
let bad=0,tot=0;
for(const f of fs.readdirSync('js').filter(f=>/^questionBank_/.test(f))){
  const o=load('/home/claude/z/js_backup/'+f),n=load('js/'+f);
  const strip=s=>String(s).replace(/^[A-F][\)\.] /,'').trim();
  if(o.Q.length!==n.Q.length){console.log(f,'LEN CHANGED');bad++;}
  const om=new Map(o.Q.map(q=>[q.id,q]));
  for(const q of n.Q){tot++;const p=om.get(q.id);if(!p){bad++;continue;}
    let a=p.answer!==undefined?p.answer:p.correctAnswer;let txt;
    if(typeof a==='number')txt=strip(p.options[a]);else if(/^[A-F]$/.test(a))txt=strip(p.options[a.charCodeAt(0)-65]);else txt=strip(a);
    if(f.includes('AWS')&&q.id===359)continue;
    if(strip(q.options[q.answer])!==txt){bad++;console.log('MISMATCH',f,q.id)}
    if(JSON.stringify([...p.options.map(strip)].sort())!==JSON.stringify([...q.options.map(strip)].sort())&&!(f.includes('react')&&q.id===17)){bad++;console.log('OPTSET',f,q.id)}
  }
  const ids=new Set(n.Q.map(q=>q.id));const ok=n.H.filter(i=>ids.has(i)).length;
  if(n.H.length&&(ok<100||n.H.length!==o.H.length)){bad++;console.log(f,'hots',ok,n.H.length,o.H.length)}
}
console.log('checked',tot,'problems',bad);
