const fs=require('fs'),vm=require('vm');const rows=[['bank','questions','correct_is_longest','pct','flagged_margin_25pct','top100_flagged','top100_total']];const detail={};
for(const f of fs.readdirSync('js').filter(f=>/^questionBank_/.test(f))){
  const c={};vm.createContext(c);vm.runInContext(fs.readFileSync('js/'+f,'utf8')+';this.Q=questionBank;this.H=typeof hotsQuestions==="undefined"?[]:hotsQuestions',c);
  const flag=[];let lg=0;
  for(const q of c.Q){const L=q.options.map(o=>o.length);const others=Math.max(...L.filter((_,i)=>i!==q.answer));if(L[q.answer]>others)lg++;if(L[q.answer]>others*1.25)flag.push(q.id)}
  const hs=new Set(c.H),fl=new Set(flag);const name=f.replace('questionBank_','').replace('.js','');
  detail[name]=flag;rows.push([name,c.Q.length,lg,Math.round(100*lg/c.Q.length),flag.length,[...hs].filter(i=>fl.has(i)).length,hs.size]);
}
fs.writeFileSync('/home/claude/z/answer_length_bias_report.csv',rows.map(r=>r.join(',')).join('\n'));
fs.writeFileSync('/home/claude/z/answer_length_bias_flagged_ids.json',JSON.stringify(detail));
console.table(rows.slice(1).map(r=>({bank:r[0],n:r[1],pct_longest:r[3],flagged:r[4],top100_flagged:r[5]+'/'+r[6]})));
