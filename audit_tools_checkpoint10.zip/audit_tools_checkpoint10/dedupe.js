const fs=require('fs'),vm=require('vm');
for(const f of fs.readdirSync('js').filter(f=>/^questionBank_/.test(f))){
  const p='js/'+f,src=fs.readFileSync(p,'utf8');const c={};vm.createContext(c);
  vm.runInContext(src+';this.Q=questionBank;this.H=typeof hotsQuestions!=="undefined"?hotsQuestions:null',c);
  const Q=c.Q,H=c.H;const norm=s=>s.trim().toLowerCase().replace(/\s+/g,' ');
  const first=new Map(),remap=new Map(),drop=new Set();
  for(const q of Q){const k=norm(q.question)+'||'+norm(q.options[q.answer]);if(first.has(k)){remap.set(q.id,first.get(k));drop.add(q.id);}else first.set(k,q.id);}
  if(!drop.size)continue;
  const NQ=Q.filter(q=>!drop.has(q.id));
  let hots=null;
  if(H){const seen=new Set();hots=[];for(const id of H){const t=remap.has(id)?remap.get(id):id;if(!seen.has(t)){seen.add(t);hots.push(t)}}
    if(hots.length<100){const rank={hard:0,medium:1,easy:2};const pool=NQ.filter(q=>!seen.has(q.id)).sort((a,b)=>(rank[a.difficulty]||1)-(rank[b.difficulty]||1));
      for(const q of pool){if(hots.length>=100)break;hots.push(q.id);}}}
  const hi=src.search(/^const hotsQuestions/m);
  const hm=src.match(/^\/\*[\s\S]*?\*\//);
  let tail='';
  if(hi>=0){let lines=src.slice(0,hi).split('\n');let k=lines.length-1;while(k>0&&/^\s*(\/\/|\/\*|\*)/.test(lines[k-1]))k--;
    const cm=lines.slice(k).join('\n');tail=cm+'const hotsQuestions = [\n    '+hots.join(',\n    ')+'\n];\n';}
  fs.writeFileSync(p,(hm?hm[0]+'\n\n':'')+'const questionBank = '+JSON.stringify(NQ,null,2)+';\n\n'+tail);
  console.log(f.replace('questionBank_','').padEnd(26),'removed',drop.size,'bank',Q.length,'->',NQ.length,H?('hots '+H.length+'->'+hots.length):'');
}
