from playwright.sync_api import sync_playwright
errs=[]
with sync_playwright() as p:
    b=p.chromium.launch(); pg=b.new_page(); pg.on("pageerror",lambda e:errs.append(str(e))); pg.on("dialog",lambda d:(errs.append("DIALOG "+d.message),d.accept()))
    banks=["snowflake","databricks","claude_architect","claude_developer","data_architect","aws","react","python_pySpark","mongodb","typescript_nestjs"]
    for t in banks:
        pg.goto(f"http://localhost:8765/exam.html?type={t}"); pg.wait_for_timeout(600)
        full=pg.evaluate("fullBank.length")
        for k in range(25):
            pg.evaluate("document.querySelector(`input[name=opt][value='${examQuestions[current].answer}']`).click()")
            pg.evaluate("nextQuestion()")
        score=pg.inner_text("#runningScore")
        pg.check("#hotToggle"); pg.wait_for_timeout(500)
        hot=pg.evaluate("fullBank.length")
        for k in range(10):
            pg.evaluate("document.querySelector(`input[name=opt][value='${examQuestions[current].answer}']`).click()")
            pg.evaluate("nextQuestion()")
        print(f"{t:18} bank={full:4} 25 correct clicks -> [{score.strip()}]  top100={hot}  hot-score=[{pg.inner_text('#runningScore').strip()}]")
    pg.goto("http://localhost:8765/exam.html?type=claude_architect&focus=tool_choice"); pg.wait_for_timeout(700)
    print("focus tool_choice ->",pg.evaluate("fullBank.length"))
    b.close()
print("errors:",errs)
