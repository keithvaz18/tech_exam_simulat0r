const fs=require('fs'),vm=require('vm');
const html=fs.readFileSync('index.html','utf8');
// extract keyword arrays
const ctx={};vm.createContext(ctx);
const re=/^const (\w+Keywords) = \[/gm;let m;const names=[];
while((m=re.exec(html))){names.push([m[1],m.index]);}
for(const [n,idx] of names){
  let i=html.indexOf('[',idx),d=0,j=i;
  for(;j<html.length;j++){if(html[j]=='[')d++;else if(html[j]==']'){d--;if(d==0)break;}}
  try{vm.runInContext('var '+n+'='+html.slice(i,j+1),ctx);}catch(e){console.log('PARSE FAIL',n,e.message)}
}
const map={ai_data:'dataArchitectKeywords',claude_architect:'claudeArchitectKeywords',claude_developer:'claudeDeveloperKeywords',databricks:'dbKeywords',ai:'aiKeywords',java:'javaKeywords',azure:'azKeywords',aws:'awsKeywords',mongodb:'mgKeywords',react:'rKeywords',snowflake:'snKeywords',kafka:'kfKeywords',data_architect:'dataArchitectKeywords',devOps:'devOpsKeywords',enterprise_architect:'eaKeywords',TypeScript_NestJS:'typescriptNestjsKeywords',web3_blockchain:'web3BlockChainKeywords'};
const files=fs.readFileSync('exam.html','utf8');
const em={};for(const x of files.matchAll(/'(\w+)':\s*\{ title: '([^']*)', file: '([^']*)'/g))em[x[1]]=x[3];
const out={};
for(const t of Object.keys(em)){
  const c={};vm.createContext(c);
  let src=fs.readFileSync(em[t],'utf8');
  try{vm.runInContext(src+';this.QB=questionBank;this.HOT=typeof hotsQuestions!=="undefined"?hotsQuestions:null;',c);}catch(e){console.log(t,'LOAD FAIL',e.message);continue;}
  const qb=c.QB;const kws=map[t]?ctx[map[t]]:null;
  const r={type:t,n:qb.length,hot:c.HOT?c.HOT.length:null,cloud:map[t]||'NONE'};
  // integrity
  const ids=new Set(),dup=[];qb.forEach(q=>{if(ids.has(q.id))dup.push(q.id);ids.add(q.id)});
  r.dupIds=dup.length;
  r.badAnswer=qb.filter(q=>!Array.isArray(q.options)||q.answer==null||q.answer<0||q.answer>=q.options.length).length;
  r.noExpl=qb.filter(q=>!q.explanation).length;
  r.idxMismatch=qb.filter((q,i)=>q.id!==i).length;
  r.hotBad=c.HOT?c.HOT.filter(i=>qb[i]===undefined).length:null;
  r.hotDup=c.HOT?c.HOT.length-new Set(c.HOT).size:null;
  if(kws){
    r.kw=kws.length;
    r.zero=[];r.low=[];
    const dupk={};kws.forEach(k=>{const w=k.word.toLowerCase();dupk[w]=(dupk[w]||0)+1});
    r.dupKw=Object.keys(dupk).filter(w=>dupk[w]>1);
    for(const k of kws){const w=k.word.trim().toLowerCase();
      const n=qb.filter(q=>q.question.toLowerCase().includes(w)||(q.category&&q.category.toLowerCase().includes(w))||(q.explanation&&q.explanation.toLowerCase().includes(w))).length;
      if(n==0)r.zero.push(k.word);else if(n<3)r.low.push(k.word+'('+n+')');}
    r.domains=[...new Set(kws.map(k=>k.domain))];
  }
  out[t]=r;
}
fs.writeFileSync('/home/claude/audit.json',JSON.stringify(out,null,1));
for(const r of Object.values(out))console.log(r.type.padEnd(22),'Q',String(r.n).padEnd(4),'hot',String(r.hot).padEnd(4),'cloud',(r.cloud||'').padEnd(26),'kw',r.kw??'-','zero',r.zero?r.zero.length:'-','low',r.low?r.low.length:'-','dupId',r.dupIds,'badAns',r.badAnswer,'noExpl',r.noExpl,'idx!=i',r.idxMismatch,'hotBad',r.hotBad,'hotDup',r.hotDup,'dupKw',r.dupKw?r.dupKw.length:'-');
