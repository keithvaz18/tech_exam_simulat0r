const fs=require('fs'),vm=require('vm');
for(const f of fs.readdirSync('js').filter(f=>/^questionBank_/.test(f))){
  const c={};vm.createContext(c);vm.runInContext(fs.readFileSync('js/'+f,'utf8')+';this.Q=questionBank',c);
  let lg=0,top2=0,n=0;for(const q of c.Q){const L=q.options.map(o=>o.length);const m=Math.max(...L);n++;if(L[q.answer]===m&&L.filter(x=>x===m).length===1)lg++;
    if([...L].sort((a,b)=>b-a).slice(0,2).includes(L[q.answer]))top2++}
  console.log(f.replace('questionBank_','').padEnd28||'',f.replace('questionBank_','').padEnd(28),'longest',Math.round(100*lg/n)+'%','top2',Math.round(100*top2/n)+'%','(chance 25%/50%)');
}
