/* ======================================================
ENTERPRISE DATA ARCHITECTURE & DATA WAREHOUSE
====================================================== */

const questionBank = [
  {
    "id": 1,
    "difficulty": "easy",
    "category": "architecture",
    "question": "What is the primary goal of an Enterprise Data Warehouse?",
    "options": [
      "Store application configuration",
      "Replace operational databases",
      "Support analytics and reporting",
      "Serve transactional workloads"
    ],
    "answer": 2,
    "explanation": "Enterprise Data Warehouses are designed for analytics, BI reporting, and decision support rather than operational transaction processing."
  },
  {
    "id": 2,
    "difficulty": "easy",
    "category": "architecture",
    "question": "Which architecture separates compute and storage for scalability?",
    "options": [
      "Flat File Architecture",
      "Cloud Data Warehouse",
      "On-Prem Data Warehouse",
      "Client Server Model"
    ],
    "answer": 1,
    "explanation": "Cloud warehouses like Snowflake and BigQuery separate storage and compute for elastic scalability."
  },
  {
    "id": 3,
    "difficulty": "medium",
    "category": "data-modelling",
    "question": "Who popularized dimensional modelling used in data warehouses?",
    "options": [
      "Bill Inmon",
      "Michael Stonebraker",
      "Ralph Kimball",
      "Edgar Codd"
    ],
    "answer": 2,
    "explanation": "Ralph Kimball introduced dimensional modelling using star schemas for analytics systems."
  },
  {
    "id": 4,
    "difficulty": "easy",
    "category": "data-modelling",
    "question": "Which schema is most commonly used in analytics data warehouses?",
    "options": [
      "Star Schema",
      "Hierarchical Schema",
      "Graph Schema",
      "Network Schema"
    ],
    "answer": 0,
    "explanation": "Star schema is widely used because it simplifies analytical queries."
  },
  {
    "id": 5,
    "difficulty": "medium",
    "category": "data-modelling",
    "question": "What is the grain of a fact table?",
    "options": [
      "Level of detail stored in each row",
      "Number of columns in a table",
      "Number of indexes",
      "Data compression level"
    ],
    "answer": 0,
    "explanation": "Grain defines the lowest level of detail represented in the fact table."
  },
  {
    "id": 6,
    "difficulty": "medium",
    "category": "data-modelling",
    "question": "Which fact table type records every individual event?",
    "options": [
      "Aggregate Fact",
      "Snapshot Fact",
      "Transaction Fact",
      "Accumulating Fact"
    ],
    "answer": 2,
    "explanation": "Transaction fact tables store each event such as purchases or financial transactions."
  },
  {
    "id": 7,
    "difficulty": "medium",
    "category": "data-modelling",
    "question": "Which Slowly Changing Dimension preserves full historical data?",
    "options": [
      "SCD Type 1",
      "SCD Type 3",
      "SCD Type 0",
      "SCD Type 2"
    ],
    "answer": 3,
    "explanation": "SCD Type 2 stores history by creating new rows for each change."
  },
  {
    "id": 8,
    "difficulty": "medium",
    "category": "data-engineering",
    "question": "Which ingestion technique captures database changes from transaction logs?",
    "options": [
      "Change Data Capture",
      "Snapshot replication",
      "Data scraping",
      "Manual batch export"
    ],
    "answer": 0,
    "explanation": "Log-based Change Data Capture captures changes directly from database transaction logs."
  },
  {
    "id": 9,
    "difficulty": "medium",
    "category": "data-engineering",
    "question": "Which architecture layer stores raw unprocessed data in a lakehouse?",
    "options": [
      "Silver Layer",
      "Bronze Layer",
      "Gold Layer",
      "Diamond Layer"
    ],
    "answer": 1,
    "explanation": "Bronze layer stores raw ingested data before transformation."
  },
  {
    "id": 10,
    "difficulty": "medium",
    "category": "lakehouse",
    "question": "Which architecture combines data lakes and warehouses?",
    "options": [
      "Lambda Architecture",
      "OLTP Architecture",
      "Lakehouse Architecture",
      "Service Mesh"
    ],
    "answer": 2,
    "explanation": "Lakehouse architecture merges lake flexibility with warehouse performance."
  },
  {
    "id": 11,
    "difficulty": "medium",
    "category": "streaming",
    "question": "What is the main purpose of an event streaming platform?",
    "options": [
      "Provide BI dashboards",
      "Process real-time data streams",
      "Store relational data",
      "Replace databases"
    ],
    "answer": 1,
    "explanation": "Streaming platforms process high-volume real-time event streams."
  },
  {
    "id": 12,
    "difficulty": "hard",
    "category": "architecture",
    "question": "Which architecture layer defines business metrics like revenue or churn?",
    "options": [
      "Data Lake",
      "ETL Layer",
      "Streaming Layer",
      "Semantic Layer"
    ],
    "answer": 3,
    "explanation": "Semantic layers standardize business metrics used across analytics tools."
  },
  {
    "id": 13,
    "difficulty": "medium",
    "category": "governance",
    "question": "Which concept tracks how data flows from source systems to dashboards?",
    "options": [
      "Data caching",
      "Data replication",
      "Data indexing",
      "Data lineage"
    ],
    "answer": 3,
    "explanation": "Data lineage shows how data moves across pipelines and systems."
  },
  {
    "id": 14,
    "difficulty": "medium",
    "category": "security",
    "question": "Which security model assigns permissions based on roles?",
    "options": [
      "RBAC",
      "DAC",
      "MAC",
      "ABAC"
    ],
    "answer": 0,
    "explanation": "Role-Based Access Control assigns permissions via roles."
  },
  {
    "id": 15,
    "difficulty": "hard",
    "category": "ml-platform",
    "question": "What is the primary function of a Feature Store?",
    "options": [
      "Store images",
      "Store SQL queries",
      "Replace data warehouses",
      "Manage ML features for training and inference"
    ],
    "answer": 3,
    "explanation": "Feature stores store ML features for model training and real-time inference."
  },
  {
    "id": 16,
    "difficulty": "medium",
    "category": "performance",
    "question": "Which technique improves query performance by splitting large tables?",
    "options": [
      "Encryption",
      "Partitioning",
      "Normalization",
      "Masking"
    ],
    "answer": 1,
    "explanation": "Partitioning divides large tables into smaller segments to improve query performance."
  },
  {
    "id": 17,
    "difficulty": "hard",
    "category": "data-fabric",
    "question": "What is the primary purpose of a Data Fabric architecture?",
    "options": [
      "Store machine learning models",
      "Unified data access across distributed systems",
      "Centralized OLTP processing",
      "Replace data lakes"
    ],
    "answer": 1,
    "explanation": "Data Fabric provides unified data access across distributed data sources."
  },
  {
    "id": 18,
    "difficulty": "hard",
    "category": "big-data",
    "question": "Which modeling approach separates Hubs, Links, and Satellites?",
    "options": [
      "Data Vault Modeling",
      "Graph Modeling",
      "Columnar Modeling",
      "Dimensional Modeling"
    ],
    "answer": 0,
    "explanation": "Data Vault uses Hubs, Links, and Satellites to enable scalable data warehouse modeling."
  },
  {
    "id": 19,
    "difficulty": "hard",
    "category": "event-architecture",
    "question": "Which modeling pattern records every user interaction as an event?",
    "options": [
      "Snowflake Schema",
      "Network Model",
      "Activity Schema",
      "Hierarchical Model"
    ],
    "answer": 2,
    "explanation": "Activity schemas store all user interactions as events."
  },
  {
    "id": 20,
    "difficulty": "hard",
    "category": "scale",
    "question": "Which architecture supports 100B+ events per day systems?",
    "options": [
      "Single-node database",
      "Manual ETL processing",
      "Excel spreadsheets",
      "Distributed streaming architecture"
    ],
    "answer": 3,
    "explanation": "Petabyte-scale architectures rely on distributed event streaming platforms."
  },
  {
    "id": 21,
    "difficulty": "medium",
    "category": "architecture",
    "question": "Which Medallion Architecture layer is used for 'cleansed' and 'filtered' data?",
    "options": [
      "Platinum",
      "Silver",
      "Gold",
      "Bronze"
    ],
    "answer": 1,
    "explanation": "The Silver layer represents validated, cleansed, and enriched data ready for downstream use."
  },
  {
    "id": 22,
    "difficulty": "easy",
    "category": "architecture",
    "question": "What is the primary benefit of a Lakehouse architecture?",
    "options": [
      "Providing warehouse performance on lake storage",
      "Replacing all BI tools",
      "Running only on local servers",
      "Eliminating the need for storage"
    ],
    "answer": 0,
    "explanation": "Lakehouse architecture brings ACID transactions and warehouse-like performance directly to low-cost cloud object storage."
  },
  {
    "id": 23,
    "difficulty": "hard",
    "category": "architecture",
    "question": "In a Data Fabric, what is the 'Active Metadata' used for?",
    "options": [
      "Storing user passwords",
      "Automating data discovery and orchestration",
      "Compressed backup storage",
      "Manual documentation"
    ],
    "answer": 1,
    "explanation": "Data Fabric uses AI-driven active metadata to automate data integration and governance across distributed environments."
  },
  {
    "id": 24,
    "difficulty": "medium",
    "category": "streaming",
    "question": "Which concept defines an architecture that reacts to state changes in real-time?",
    "options": [
      "Batch-Driven",
      "Manual-Entry",
      "Event-Driven",
      "Static-Schema"
    ],
    "answer": 2,
    "explanation": "Event-Driven architectures process data as a continuous stream of events rather than periodic batches."
  },
  {
    "id": 25,
    "difficulty": "medium",
    "category": "ingestion",
    "question": "Why is log-based CDC preferred over query-based CDC?",
    "options": [
      "It captures every change without impacting source performance",
      "It is slower",
      "It cannot capture deletions",
      "It puts zero load on the source database"
    ],
    "answer": 0,
    "explanation": "Log-based Change Data Capture reads database logs directly, capturing all changes (including deletes) without putting high query load on the database."
  },
  {
    "id": 26,
    "difficulty": "medium",
    "category": "modelling",
    "question": "In Kimball's Dimensional Modelling, what is a 'Conformed Dimension'?",
    "options": [
      "A dimension shared across multiple fact tables",
      "A dimension with no attributes",
      "A dimension stored in a CSV",
      "A dimension used only once"
    ],
    "answer": 0,
    "explanation": "Conformed dimensions ensure consistency by using the same reference data across different business processes."
  },
  {
    "id": 27,
    "difficulty": "medium",
    "category": "modelling",
    "question": "In Data Vault modeling, which component stores the descriptive attributes of a business key?",
    "options": [
      "Fact",
      "Link",
      "Satellite",
      "Hub"
    ],
    "answer": 2,
    "explanation": "Satellites store the time-variant descriptive information for Hubs or Links."
  },
  {
    "id": 28,
    "difficulty": "easy",
    "category": "modelling",
    "question": "What does the 'S' in SCD Type 2 stand for?",
    "options": [
      "Static",
      "Schema",
      "Slowly",
      "System"
    ],
    "answer": 2,
    "explanation": "SCD stands for Slowly Changing Dimension, which tracks historical changes over time."
  },
  {
    "id": 29,
    "difficulty": "hard",
    "category": "ml",
    "question": "What problem does a Feature Store solve for ML Engineers?",
    "options": [
      "SQL syntax errors",
      "Data visualization",
      "Training-serving skew",
      "Operating system updates"
    ],
    "answer": 2,
    "explanation": "Feature Stores ensure that the same feature logic is used during model training and real-time production inference."
  },
  {
    "id": 30,
    "difficulty": "hard",
    "category": "analytics",
    "question": "How does an Activity Schema differ from a Star Schema?",
    "options": [
      "It requires complex joins",
      "It is only for Excel",
      "It uses a single wide table for all events",
      "It has more tables"
    ],
    "answer": 2,
    "explanation": "Activity schemas simplify modeling by using a single table for all entity-related events, reducing the need for complex multi-table joins."
  },
  {
    "id": 31,
    "difficulty": "medium",
    "category": "analytics",
    "question": "What is the end goal of a Customer 360 initiative?",
    "options": [
      "A unified, single view of the customer across all touchpoints",
      "Sending 360 emails per day",
      "Deleting customer data",
      "Storing customer emails"
    ],
    "answer": 0,
    "explanation": "Customer 360 aims to provide a consolidated, holistic view of a customer by integrating data from silos."
  },
  {
    "id": 32,
    "difficulty": "medium",
    "category": "analytics",
    "question": "Which layer allows business users to interact with data using 'Revenue' instead of complex SQL formulas?",
    "options": [
      "Semantic Layer",
      "Network Layer",
      "Storage Layer",
      "Ingestion Layer"
    ],
    "answer": 0,
    "explanation": "The Semantic Layer abstracts technical complexity into business-friendly terms."
  },
  {
    "id": 33,
    "difficulty": "easy",
    "category": "governance",
    "question": "Which tool acts as a search engine for an organization's data assets?",
    "options": [
      "Firewall",
      "RAM",
      "Data Catalog",
      "Data Lineage"
    ],
    "answer": 2,
    "explanation": "Data Catalogs help users discover, understand, and trust data through metadata and documentation."
  },
  {
    "id": 34,
    "difficulty": "medium",
    "category": "performance",
    "question": "How does Columnar Storage speed up analytical queries?",
    "options": [
      "It uses more storage space",
      "It disables all security",
      "It only reads the specific columns required for the query",
      "It reads every row"
    ],
    "answer": 2,
    "explanation": "Columnar storage minimizes I/O by only reading the data for specific columns needed for aggregation/filtering."
  },
  {
    "id": 35,
    "difficulty": "hard",
    "category": "scale",
    "question": "At Petabyte Scale, what is the main drawback of vertical scaling (scaling up)?",
    "options": [
      "It is too fast",
      "It is too cheap",
      "It requires no configuration",
      "Hardware limits and extreme cost"
    ],
    "answer": 3,
    "explanation": "Scaling up (bigger RAM/CPU) hits a physical ceiling and becomes exponentially expensive compared to horizontal scaling."
  },
  {
    "id": 36,
    "difficulty": "medium",
    "category": "architecture",
    "question": "In Medallion architecture, which layer is best for 'Power BI' or 'Tableau' dashboards?",
    "options": [
      "Gold",
      "Raw",
      "Bronze",
      "Silver"
    ],
    "answer": 0,
    "explanation": "The Gold layer contains consumption-ready, business-level aggregates ideal for BI reporting."
  },
  {
    "id": 37,
    "difficulty": "medium",
    "category": "streaming",
    "question": "What is 'Latent data' in a real-time analytics system?",
    "options": [
      "Fast data",
      "Temporary data",
      "Encrypted data",
      "Data that arrives late"
    ],
    "answer": 3,
    "explanation": "Latency refers to the delay between data generation and the data being available for query."
  },
  {
    "id": 38,
    "difficulty": "medium",
    "category": "modelling",
    "question": "In a Star Schema, which table usually contains the foreign keys?",
    "options": [
      "Config Table",
      "Dimension Table",
      "Look-up Table",
      "Fact Table"
    ],
    "answer": 3,
    "explanation": "The Fact table contains foreign keys that link it to various Dimension tables."
  },
  {
    "id": 39,
    "difficulty": "hard",
    "category": "modelling",
    "question": "In Data Vault, which table connects two or more Hubs to represent a business process?",
    "options": [
      "Schema",
      "Satellite",
      "Reference",
      "Link"
    ],
    "answer": 3,
    "explanation": "Link tables represent the relationships/interactions between business keys (Hubs)."
  },
  {
    "id": 40,
    "difficulty": "medium",
    "category": "governance",
    "question": "What is the primary use of Data Lineage during a system migration?",
    "options": [
      "Calculating CPU usage",
      "Changing passwords",
      "Performing impact analysis of changes",
      "Cleaning the server room"
    ],
    "answer": 2,
    "explanation": "Data Lineage helps engineers understand which downstream systems will break if an upstream source is modified."
  },
  {
    "id": 41,
    "difficulty": "medium",
    "category": "performance",
    "question": "Which technique is used to skip reading data files based on filter conditions?",
    "options": [
      "Compression",
      "Encryption",
      "Partition Pruning",
      "Normalization"
    ],
    "answer": 2,
    "explanation": "Partition pruning allows the query engine to ignore files that don't match the filter (e.g., skipping all months except 'January')."
  },
  {
    "id": 42,
    "difficulty": "hard",
    "category": "architecture",
    "question": "What is the 'Virtualization' approach in a Data Fabric?",
    "options": [
      "Using VR headsets for DBAs",
      "Deleting all source data",
      "Accessing data where it lives without moving it",
      "Copying all data to one place"
    ],
    "answer": 2,
    "explanation": "Data virtualization allows querying data from multiple sources without needing to move it to a central repository."
  },
  {
    "id": 43,
    "difficulty": "easy",
    "category": "ingestion",
    "question": "What does the 'C' in CDC stand for?",
    "options": [
      "Control",
      "Change",
      "Cloud",
      "Column"
    ],
    "answer": 1,
    "explanation": "CDC stands for Change Data Capture."
  },
  {
    "id": 44,
    "difficulty": "medium",
    "category": "streaming",
    "question": "Which of the following is a distributed event streaming platform?",
    "options": [
      "Notepad++",
      "Microsoft Excel",
      "Apache Kafka",
      "Postgres"
    ],
    "answer": 2,
    "explanation": "Apache Kafka is a widely used distributed event streaming platform."
  },
  {
    "id": 45,
    "difficulty": "hard",
    "category": "analytics",
    "question": "A 'Headless BI' architecture is primarily built on top of which keyword?",
    "options": [
      "Semantic Layer",
      "CSV file",
      "Data Lake",
      "Bronze Layer"
    ],
    "answer": 0,
    "explanation": "Headless BI decouples the semantic layer (metrics) from the visualization tool, allowing any tool to use the same definitions."
  },
  {
    "id": 46,
    "difficulty": "easy",
    "category": "governance",
    "question": "Who is the primary user of a Data Catalog?",
    "options": [
      "Data Analysts and Scientists",
      "HR Managers",
      "Office Janitors",
      "Front-end Developers"
    ],
    "answer": 0,
    "explanation": "Data Analysts and Scientists use catalogs to find the right datasets for their work."
  },
  {
    "id": 47,
    "difficulty": "medium",
    "category": "modelling",
    "question": "In SCD Type 2, what column is typically added to track current records?",
    "options": [
      "Record_ID",
      "Price",
      "Username",
      "Is_Current or Active_Flag"
    ],
    "answer": 3,
    "explanation": "A flag or an end-date is used to distinguish the active record from historical records."
  },
  {
    "id": 48,
    "difficulty": "medium",
    "category": "performance",
    "question": "Why is Parquet storage better than CSV for analytics?",
    "options": [
      "It doesn't support schemas",
      "It supports columnar storage and compression",
      "It is older",
      "It is human readable in Notepad"
    ],
    "answer": 1,
    "explanation": "Parquet is a binary columnar format that is highly optimized for analytical read patterns."
  },
  {
    "id": 49,
    "difficulty": "hard",
    "category": "analytics",
    "question": "In Customer 360, what is 'Identity Resolution'?",
    "options": [
      "Changing a user's password",
      "Scanning a driver's license",
      "Deleting duplicate emails",
      "Linking records from different systems to the same person"
    ],
    "answer": 3,
    "explanation": "Identity resolution matches and merges various data fragments into a single unique customer profile."
  },
  {
    "id": 50,
    "difficulty": "easy",
    "category": "architecture",
    "question": "The 'Bronze' layer in Medallion architecture is also known as:",
    "options": [
      "Aggregate Layer",
      "Raw Layer",
      "Metric Layer",
      "Report Layer"
    ],
    "answer": 1,
    "explanation": "The Bronze layer stores raw data as it arrives from the source system."
  },
  {
    "id": 51,
    "difficulty": "medium",
    "category": "ml",
    "question": "Offline feature stores are typically used for what purpose?",
    "options": [
      "Storing source code",
      "Real-time predictions",
      "Sending emails",
      "Batch model training"
    ],
    "answer": 3,
    "explanation": "Offline stores hold massive historical data used for model training and experimentation."
  },
  {
    "id": 52,
    "difficulty": "medium",
    "category": "streaming",
    "question": "What is 'Backpressure' in a streaming system?",
    "options": [
      "The cooling fan speed",
      "A hardware failure",
      "The receiver signalling the sender to slow down",
      "Data flowing too slowly"
    ],
    "answer": 2,
    "explanation": "Backpressure occurs when the consumer cannot keep up with the producer, requiring flow control."
  },
  {
    "id": 53,
    "difficulty": "hard",
    "category": "analytics",
    "question": "Which schema uses 'Activity ID', 'Timestamp', and 'Entity' as its core columns?",
    "options": [
      "Star Schema",
      "Relational Schema",
      "Snowflake Schema",
      "Activity Schema"
    ],
    "answer": 3,
    "explanation": "The Activity Schema uses a simplified, standardized column structure for all event data."
  },
  {
    "id": 54,
    "difficulty": "medium",
    "category": "performance",
    "question": "What does 'Data Skew' refer to in a distributed system?",
    "options": [
      "Data is missing",
      "Uneven distribution of data across nodes",
      "Data is too clean",
      "Data is perfectly balanced"
    ],
    "answer": 1,
    "explanation": "Data skew happens when one partition/node holds significantly more data than others, causing performance bottlenecks."
  },
  {
    "id": 55,
    "difficulty": "medium",
    "category": "governance",
    "question": "Technical Metadata in a Data Catalog includes which of the following?",
    "options": [
      "Table names and Data types",
      "The CEO's home address",
      "Employee coffee preferences",
      "Business ROI of the table"
    ],
    "answer": 0,
    "explanation": "Technical metadata covers structural information like schemas, column names, and types."
  },
  {
    "id": 56,
    "difficulty": "hard",
    "category": "architecture",
    "question": "What is the 'Semantic Gap'?",
    "options": [
      "A slow internet connection",
      "A hard drive failure",
      "The difference between technical data storage and business meaning",
      "A missing database index"
    ],
    "answer": 2,
    "explanation": "The Semantic Gap is the distance between how data is stored (complex tables) and how it is understood by business users."
  },
  {
    "id": 57,
    "difficulty": "easy",
    "category": "modelling",
    "question": "Which Kimball model resembles a 'star' shape?",
    "options": [
      "Hub Schema",
      "Circle Schema",
      "Star Schema",
      "Linear Schema"
    ],
    "answer": 2,
    "explanation": "The Star Schema consists of a central fact table surrounded by dimension tables."
  },
  {
    "id": 58,
    "difficulty": "medium",
    "category": "ingestion",
    "question": "In CDC, what happens when a record is UPDATED in the source?",
    "options": [
      "The CDC tool captures the change and sends it to the target",
      "The network is reset",
      "The CDC tool ignores it",
      "The source database crashes"
    ],
    "answer": 0,
    "explanation": "CDC is designed to capture Inserts, Updates, and Deletes in near real-time."
  },
  {
    "id": 59,
    "difficulty": "medium",
    "category": "performance",
    "question": "Which storage format is most efficient for 'SELECT SUM(Sales) FROM Table'?",
    "options": [
      "XML",
      "Row-based",
      "Column-based",
      "Text file"
    ],
    "answer": 2,
    "explanation": "Column-based storage is highly efficient for aggregations on specific columns."
  },
  {
    "id": 60,
    "difficulty": "hard",
    "category": "architecture",
    "question": "A 'Data Mesh' differs from a 'Data Fabric' primarily by focusing on:",
    "options": [
      "Technology",
      "Centralization",
      "Organizational and Decentralized Ownership",
      "Manual entry"
    ],
    "answer": 2,
    "explanation": "Data Mesh is an organizational shift toward decentralized data ownership by business domains."
  },
  {
    "id": 61,
    "difficulty": "medium",
    "category": "scale",
    "question": "Horizontal scaling is also known as:",
    "options": [
      "Scaling In",
      "Scaling Up",
      "Scaling Down",
      "Scaling Out"
    ],
    "answer": 3,
    "explanation": "Scaling out involves adding more machines to a cluster to handle increased load."
  },
  {
    "id": 62,
    "difficulty": "medium",
    "category": "analytics",
    "question": "Real-time analytics often requires an 'OLAP' engine. What does OLAP stand for?",
    "options": [
      "Only Local Access Point",
      "Off-site Analytical Power",
      "Online Analytical Processing",
      "Open Layer Architecture Pattern"
    ],
    "answer": 2,
    "explanation": "OLAP engines are optimized for complex analytical queries and aggregations."
  },
  {
    "id": 63,
    "difficulty": "hard",
    "category": "modelling",
    "question": "In Data Vault, which component is used to track business keys that are unique across the enterprise?",
    "options": [
      "Hub",
      "Link",
      "Satellite",
      "Pit"
    ],
    "answer": 0,
    "explanation": "Hubs contain a list of unique business keys (like CustomerID or OrderID)."
  },
  {
    "id": 64,
    "difficulty": "medium",
    "category": "governance",
    "question": "What is a 'Data Steward'?",
    "options": [
      "A cloud storage provider",
      "A database server",
      "A security firewall",
      "A person responsible for data quality and definitions"
    ],
    "answer": 3,
    "explanation": "Data Stewards are roles within an organization responsible for managing data assets and ensuring they are fit for use."
  },
  {
    "id": 65,
    "difficulty": "easy",
    "category": "architecture",
    "question": "What storage technology is commonly used for the 'Lake' in Lakehouse?",
    "options": [
      "Object Storage (e.g., S3, ADLS)",
      "Tape Drives",
      "RAM",
      "Floppy Disks"
    ],
    "answer": 0,
    "explanation": "Cloud object storage provides the scalable, low-cost foundation for modern data lakes."
  },
  {
    "id": 66,
    "difficulty": "medium",
    "category": "streaming",
    "question": "In a stream processing pipeline, what is 'Windowing'?",
    "options": [
      "Looking through a glass pane",
      "Limiting the number of users",
      "Closing the computer window",
      "Grouping data into time-based buckets for analysis"
    ],
    "answer": 3,
    "explanation": "Windowing allows you to perform aggregations (like SUM or AVG) over specific time intervals (e.g., every 5 minutes)."
  },
  {
    "id": 67,
    "difficulty": "hard",
    "category": "analytics",
    "question": "Which technology is often used to build a Semantic Layer for 'Headless BI'?",
    "options": [
      "PostgreSQL",
      "Apache Spark",
      "Excel Macros",
      "dbt Semantic Layer / Cube"
    ],
    "answer": 3,
    "explanation": "Tools like Cube or dbt Semantic Layer provide a centralized definition of metrics for multiple consumers."
  },
  {
    "id": 68,
    "difficulty": "medium",
    "category": "performance",
    "question": "What is a 'Z-Order' index used for in Lakehouse storage?",
    "options": [
      "Alphabetizing files",
      "Deleting old files",
      "Optimizing multi-dimensional data clustering",
      "Hiding data"
    ],
    "answer": 2,
    "explanation": "Z-Ordering improves query performance by co-locating related information in the same files."
  },
  {
    "id": 69,
    "difficulty": "hard",
    "category": "ingestion",
    "question": "Which CDC method is most likely to miss 'DELETE' operations if not carefully implemented?",
    "options": [
      "Log-based",
      "Timestamp-based (Query-based)",
      "Trigger-based",
      "None of the above"
    ],
    "answer": 1,
    "explanation": "Timestamp-based CDC only sees rows that exist; if a row is deleted, the query won't find it to update the target."
  },
  {
    "id": 70,
    "difficulty": "easy",
    "category": "scale",
    "question": "Petabyte scale data platforms are most commonly hosted where?",
    "options": [
      "Desktop PCs",
      "USB Drives",
      "Public Cloud (AWS/GCP/Azure)",
      "Local Laptops"
    ],
    "answer": 2,
    "explanation": "The elastic resources of the public cloud are essential for handling petabytes of data efficiently."
  },
  {
    "id": 71,
    "difficulty": "hard",
    "category": "migration",
    "question": "When migrating from Apache Hive to Apache Iceberg, which 'in-place' mechanism creates a new table without rewriting data files?",
    "options": [
      "Hive Metastore 'Sync' command",
      "Iceberg 'Migrate' procedure",
      "Iceberg 'Snapshot' procedure",
      "Iceberg 'Import' function"
    ],
    "answer": 1,
    "explanation": "The 'Migrate' procedure replaces the Hive table with an Iceberg table by mapping existing data files into a new Iceberg manifest list without data duplication."
  },
  {
    "id": 72,
    "difficulty": "hard",
    "category": "architecture",
    "question": "In a Data Mesh architecture, what is the 'Architectural Quantum' used to define a Data Product?",
    "options": [
      "A shared metadata repository",
      "A centralized data warehouse cluster",
      "A single SQL view",
      "An autonomous unit containing data, code, and infrastructure"
    ],
    "answer": 3,
    "explanation": "Data Mesh defines a Data Product as an encapsulated unit (quantum) that includes its own data, the code to process it, and the infrastructure needed to serve it."
  },
  {
    "id": 73,
    "difficulty": "medium",
    "category": "performance",
    "question": "Which factor most heavily influences the physical design of an Apache HBase Row Key for high-throughput streaming?",
    "options": [
      "The size of the Java Heap",
      "Prevention of region server 'hotspotting'",
      "Third Normal Form (3NF) requirements",
      "The number of Kafka partitions"
    ],
    "answer": 1,
    "explanation": "HBase stores data lexicographically; row keys must be designed (often using hashing or salting) to distribute writes evenly across region servers and avoid hotspotting."
  },
  {
    "id": 74,
    "difficulty": "medium",
    "category": "mlops",
    "question": "In an MLOps pipeline, what is the primary cause of 'Training-Serving Skew'?",
    "options": [
      "Inconsistent feature logic between batch training and real-time inference",
      "Using different versions of Python",
      "Slow network latency",
      "Low GPU utilization"
    ],
    "answer": 0,
    "explanation": "Skew occurs when the data preprocessing logic used for model training differs from the logic applied during real-time scoring in production."
  },
  {
    "id": 75,
    "difficulty": "hard",
    "category": "data-modelling",
    "question": "Which step is critical when translating a Logical Data Model into a Physical Model for a NoSQL database like HBase or Cassandra?",
    "options": [
      "Ensuring all tables are in 5th Normal Form",
      "Using only integer-based primary keys",
      "Modelling tables based on specific query access patterns",
      "Eliminating all data redundancy"
    ],
    "answer": 2,
    "explanation": "Unlike relational databases, NoSQL physical models are 'query-first,' meaning tables are structured specifically to optimize for the exact queries the application will run."
  },
  {
    "id": 76,
    "difficulty": "medium",
    "category": "streaming",
    "question": "What is the role of the 'Lily HBase Indexer' in an architecture using Apache Solr?",
    "options": [
      "Translating SQL into HBase Get operations",
      "Compressing HBase HFiles",
      "Asynchronously updating Solr indices based on HBase Write-Ahead Logs (WAL)",
      "Managing Kafka offsets"
    ],
    "answer": 2,
    "explanation": "The Lily Indexer provides near real-time search capabilities by listening to HBase replication logs and automatically updating Solr collections."
  },
  {
    "id": 77,
    "difficulty": "hard",
    "category": "lakehouse",
    "question": "Which Apache Iceberg feature allows users to query a table as it existed at a specific point in time?",
    "options": [
      "Partition Pruning",
      "File Compaction",
      "Schema Evolution",
      "Time Travel (Snapshot Reads)"
    ],
    "answer": 3,
    "explanation": "Iceberg maintains immutable snapshots of the table state, allowing users to query 'as of' a specific timestamp or snapshot ID."
  },
  {
    "id": 78,
    "difficulty": "medium",
    "category": "dataops",
    "question": "In DataOps, what is the 'Strangler Fig' pattern used for during legacy migrations?",
    "options": [
      "Automatically fixing data quality errors",
      "Increasing the compression ratio of Parquet files",
      "Deleting all legacy data immediately",
      "Gradually replacing legacy system components with new services until the old system is retired"
    ],
    "answer": 3,
    "explanation": "The Strangler Fig pattern reduces migration risk by incrementally moving traffic/functionality to the new architecture while keeping the legacy system operational."
  },
  {
    "id": 79,
    "difficulty": "hard",
    "category": "governance",
    "question": "In a decentralized Data Mesh, who is responsible for the 'Quality' of a specific Data Product?",
    "options": [
      "The Central IT Team",
      "The Domain Data Product Owner",
      "The Data Platform Team",
      "The Chief Security Officer"
    ],
    "answer": 1,
    "explanation": "Data Mesh shifts accountability to the domain; the business unit producing the data owns the quality and SLA of that specific data product."
  },
  {
    "id": 80,
    "difficulty": "medium",
    "category": "streaming",
    "question": "How does Apache Kafka ensure 'Idempotency' for producers during a network retry?",
    "options": [
      "By assigning unique Producer IDs and Sequence Numbers to every batch of messages",
      "By deleting duplicate messages in the consumer",
      "By increasing the number of replicas",
      "By using SSL encryption"
    ],
    "answer": 0,
    "explanation": "Kafka brokers use Producer IDs and sequence numbers to identify and discard duplicate requests caused by producer retries after a network error."
  },
  {
    "id": 81,
    "difficulty": "medium",
    "category": "architecture",
    "question": "Which pattern is used to handle 'Late Arriving Data' in a Medallion Architecture?",
    "options": [
      "Drop the late records",
      "Blocking the pipeline until data arrives",
      "Manual SQL inserts",
      "In-place updates in the Silver layer using Delta/Iceberg MERGE"
    ],
    "answer": 3,
    "explanation": "Modern table formats like Iceberg and Delta Lake support ACID MERGE operations, allowing late-arriving data to be integrated into existing partitions without full table rewrites."
  },
  {
    "id": 82,
    "difficulty": "hard",
    "category": "performance",
    "question": "What is 'Write Amplification' in the context of Apache Iceberg?",
    "options": [
      "The speed of disk writes",
      "Increasing the volume of incoming Kafka messages",
      "Using multiple threads for ingestion",
      "The overhead of updating metadata and rewriting data files during small updates"
    ],
    "answer": 3,
    "explanation": "Write amplification occurs when a small data change requires rewriting a large underlying file or significant metadata updates, a common challenge in Copy-on-Write (CoW) strategies."
  },
  {
    "id": 83,
    "difficulty": "medium",
    "category": "governance",
    "question": "In Apache Atlas, what is a 'Glossary' used for?",
    "options": [
      "Managing Kafka offsets",
      "Defining business concepts and terms independently of the physical technical metadata",
      "Indexing log files",
      "Storing database passwords"
    ],
    "answer": 1,
    "explanation": "The Atlas Glossary provides a business-friendly vocabulary to categorize and find technical assets based on organizational terminology."
  },
  {
    "id": 84,
    "difficulty": "hard",
    "category": "data-modelling",
    "question": "When mapping a Logical Model to an HBase Physical Model, what is the primary purpose of 'Salting' a Row Key?",
    "options": [
      "Sorting data alphabetically",
      "Encrypting the data",
      "Distributing writes across multiple RegionServers to avoid hotspots",
      "Improving data compression"
    ],
    "answer": 2,
    "explanation": "Salting adds a prefix to the row key to ensure that sequentially generated keys (like timestamps) are distributed across the cluster rather than hitting a single server."
  },
  {
    "id": 85,
    "difficulty": "medium",
    "category": "streaming",
    "question": "In Kafka, what does the 'Compact' cleanup policy do?",
    "options": [
      "Compresses the data using Gzip",
      "Only retains the latest value for a specific message key",
      "Moves data to S3 storage",
      "Deletes messages after 7 days"
    ],
    "answer": 1,
    "explanation": "Log compaction ensures that Kafka retains at least the last known value for each message key within a partition, ideal for restoring state in 'KTable' scenarios."
  },
  {
    "id": 86,
    "difficulty": "hard",
    "category": "mlops",
    "question": "What is the role of 'Human-in-the-loop' (HITL) in a Banking AI Risk pipeline?",
    "options": [
      "Replacing all AI models with manual labor",
      "Managing the data center cooling",
      "Teaching employees how to code in Python",
      "Providing manual verification for low-confidence model predictions before a final decision"
    ],
    "answer": 3,
    "explanation": "HITL is a requirement in highly regulated industries (like Banking) where a human must review edge cases or high-risk AI decisions to ensure compliance and accuracy."
  },
  {
    "id": 87,
    "difficulty": "medium",
    "category": "lakehouse",
    "question": "How does Apache Iceberg handle 'Schema Evolution' differently than traditional Hive?",
    "options": [
      "It requires a full table rewrite",
      "It uses unique ID-based column mapping instead of column names or positions",
      "It only supports CSV files",
      "It doesn't support adding new columns"
    ],
    "answer": 1,
    "explanation": "Iceberg tracks columns by ID. This allows for renaming or reordering columns without the risk of data corruption, as the mapping is not dependent on the column's position in the file."
  },
  {
    "id": 88,
    "difficulty": "medium",
    "category": "security",
    "question": "What is 'Column-Level Encryption' (CLE) in a PCI-DSS compliant data platform?",
    "options": [
      "Encrypting the entire hard drive",
      "Password-protecting the Excel export",
      "Encrypting sensitive fields like Credit Card numbers before they are stored in the Lake",
      "Hiding the column from the UI"
    ],
    "answer": 2,
    "explanation": "CLE ensures that sensitive data is unreadable at the storage layer, requiring specific keys to decrypt even if a user has access to the physical file."
  },
  {
    "id": 89,
    "difficulty": "hard",
    "category": "architecture",
    "question": "What is a 'Saga Pattern' used for in distributed data systems?",
    "options": [
      "Indexing Solr collections",
      "Data visualization",
      "Managing long-running transactions and data consistency across multiple microservices",
      "Scaling Kafka brokers"
    ],
    "answer": 2,
    "explanation": "Sagas manage distributed transactions by using a sequence of local transactions and compensations to ensure eventual consistency if one step fails."
  },
  {
    "id": 90,
    "difficulty": "medium",
    "category": "dataops",
    "question": "In a CI/CD pipeline, what is a 'Quality Gate'?",
    "options": [
      "A physical door to the server room",
      "An automated check that stops the pipeline if data quality or code tests fail",
      "The login page of the Data Catalog",
      "A manual spreadsheet of bugs"
    ],
    "answer": 1,
    "explanation": "Quality Gates ensure that only code or data that meets predefined standards (e.g., SonarQube scores or Great Expectations tests) moves to production."
  },
  {
    "id": 91,
    "difficulty": "hard",
    "category": "streaming",
    "question": "In Kafka, what is a 'Zombie Instance' in the context of Transactions?",
    "options": [
      "A producer instance that was thought to be dead but continues to send messages",
      "A message that cannot be deleted",
      "An empty topic",
      "A broker that has crashed"
    ],
    "answer": 0,
    "explanation": "Zombie instances occur when a producer times out and is replaced, but the original producer recovers and attempts to send data. Kafka uses 'Epochs' to fence these out."
  },
  {
    "id": 92,
    "difficulty": "medium",
    "category": "architecture",
    "question": "Which architecture is optimized for sub-second 'Points Lookups' on billions of rows?",
    "options": [
      "S3 Object Storage",
      "Batch-based Hive",
      "Standard Python Lists",
      "HBase (NoSQL)"
    ],
    "answer": 3,
    "explanation": "HBase is a wide-column store designed for low-latency, random access (point lookups) by primary key, even at massive scales."
  },
  {
    "id": 93,
    "difficulty": "hard",
    "category": "migration",
    "question": "During a Hive-to-Iceberg migration, what is 'Shadow Ingestion'?",
    "options": [
      "Encrypting the source files",
      "Ingesting data at night",
      "Running the new Iceberg pipeline in parallel with the legacy Hive pipeline to validate data parity",
      "Hiding the data from users"
    ],
    "answer": 2,
    "explanation": "Shadow ingestion (or Dual Writing) allows teams to compare the output of the new system against the old 'Source of Truth' before the final cutover."
  },
  {
    "id": 94,
    "difficulty": "medium",
    "category": "governance",
    "question": "What is the primary benefit of 'Data Lineage' for a Data Engineer?",
    "options": [
      "Conducting impact analysis to see what downstream reports will break if a table changes",
      "Managing employee payroll",
      "Choosing a color for a dashboard",
      "Increasing storage speed"
    ],
    "answer": 0,
    "explanation": "Lineage provides a map of data dependencies, allowing engineers to prevent breaking downstream BI tools when modifying upstream pipelines."
  },
  {
    "id": 95,
    "difficulty": "hard",
    "category": "performance",
    "question": "What does 'Predicate Pushdown' do in a Spark-Iceberg query?",
    "options": [
      "It moves the data to the user's laptop",
      "It filters data at the storage level so only relevant rows are read into memory",
      "It deletes old snapshots",
      "It renames columns automatically"
    ],
    "answer": 1,
    "explanation": "Predicate pushdown improves performance by 'pushing' the SQL 'WHERE' clause filters down to the file level, reducing I/O and memory overhead."
  },
  {
    "id": 96,
    "difficulty": "medium",
    "category": "analytics",
    "question": "What is 'Near Real-Time' (NRT) latency usually defined as in Banking?",
    "options": [
      "Once a month",
      "Hours to days",
      "Seconds to minutes",
      "Nanoseconds"
    ],
    "answer": 2,
    "explanation": "NRT typically refers to processing that happens within a few seconds to a few minutes of the event occurring."
  },
  {
    "id": 97,
    "difficulty": "hard",
    "category": "mlops",
    "question": "Which tool is commonly used to manage the lifecycle (versioning, tracking) of ML models?",
    "options": [
      "MLflow",
      "Apache Hive",
      "Apache Solr",
      "Microsoft Word"
    ],
    "answer": 0,
    "explanation": "MLflow is an open-source platform used to manage the ML lifecycle, including experimentation, reproducibility, and deployment."
  },
  {
    "id": 98,
    "difficulty": "medium",
    "category": "performance",
    "question": "In Solr, what is 'Sharding' used for?",
    "options": [
      "Changing the font of search results",
      "Deleting data",
      "Splitting a large index across multiple servers for horizontal scaling",
      "Backing up data to tape"
    ],
    "answer": 2,
    "explanation": "Sharding allows Solr to handle massive document collections by distributing the search load across multiple nodes."
  },
  {
    "id": 99,
    "difficulty": "hard",
    "category": "architecture",
    "question": "In a 'Hub and Spoke' data architecture, what is the 'Hub'?",
    "options": [
      "A remote office location",
      "A type of network cable",
      "A specific Kafka topic",
      "A centralized data repository or master data store"
    ],
    "answer": 3,
    "explanation": "The Hub serves as the central integration point for data, which is then distributed to various 'Spokes' (department-specific data marts)."
  },
  {
    "id": 100,
    "difficulty": "medium",
    "category": "data-modelling",
    "question": "What is a 'Bridge Table' used for in Dimensional Modelling?",
    "options": [
      "Connecting two different databases",
      "Storing image files",
      "Handling many-to-many relationships between dimensions and facts",
      "Speeding up network traffic"
    ],
    "answer": 2,
    "explanation": "A bridge table allows you to resolve complex many-to-many relationships (e.g., one bank account having multiple owners)."
  },
  {
    "id": 101,
    "difficulty": "medium",
    "category": "architecture",
    "question": "What is 'Hidden Partitioning' in Apache Iceberg?",
    "options": [
      "Hiding data from auditors",
      "Using secret folder names",
      "The ability to derive partition values automatically from columns without adding extra 'partition' columns",
      "Encryption of partitions"
    ],
    "answer": 2,
    "explanation": "Iceberg handles the relationship between a column (like a timestamp) and its partition (like a day) internally, so users don't have to manually specify partition filters."
  },
  {
    "id": 102,
    "difficulty": "hard",
    "category": "streaming",
    "question": "What is the 'Exact-Once' (EOS) semantic in Kafka?",
    "options": [
      "Data is sent at least once",
      "Data is sent only on Tuesdays",
      "Data is never lost but can be duplicated",
      "Data is guaranteed to be processed exactly once, even if producers or consumers fail"
    ],
    "answer": 3,
    "explanation": "EOS uses transactional producers and idempotent writes to ensure that duplicate data is never committed to the log, ensuring total data integrity."
  },
  {
    "id": 103,
    "difficulty": "medium",
    "category": "governance",
    "question": "Which regulation primarily governs data privacy for EU citizens and impacts data engineering design?",
    "options": [
      "GDPR",
      "HIPAA",
      "SOX",
      "PCI-DSS"
    ],
    "answer": 0,
    "explanation": "GDPR (General Data Protection Regulation) requires features like the 'Right to be Forgotten,' which necessitates efficient record-level deletion in data lakes."
  },
  {
    "id": 104,
    "difficulty": "hard",
    "category": "architecture",
    "question": "In Data Mesh, what is 'Federated Computational Governance'?",
    "options": [
      "A type of government election",
      "Global standards enforced automatically through the platform's code and policies",
      "A central team that makes all decisions",
      "Manual audits once a year"
    ],
    "answer": 1,
    "explanation": "It is the practice of embedding governance (security, quality, compliance) directly into the automated platform used by all domain teams."
  },
  {
    "id": 105,
    "difficulty": "medium",
    "category": "dataops",
    "question": "What is the purpose of 'Data Observability'?",
    "options": [
      "Storing data in a transparent box",
      "Checking the server's physical temperature",
      "Watching people work",
      "Monitoring the health, performance, and quality of data pipelines in real-time"
    ],
    "answer": 3,
    "explanation": "Observability tools (like Monte Carlo or DataDog) help teams detect 'silent' failures like data drift or empty tables before they impact business users."
  },
  {
    "id": 106,
    "difficulty": "hard",
    "category": "lakehouse",
    "question": "What is a 'Manifest File' in the Iceberg architecture?",
    "options": [
      "An installation script",
      "A document for shipping hardware",
      "A file that tracks a subset of data files and their associated metadata/statistics",
      "A list of all users"
    ],
    "answer": 2,
    "explanation": "Manifest files are the middle layer of Iceberg's metadata, providing the query engine with information on which data files to read and which to skip."
  },
  {
    "id": 107,
    "difficulty": "medium",
    "category": "security",
    "question": "In an IAM 'Least Privilege' model, what access should a service account have?",
    "options": [
      "Only the specific permissions required to perform its task",
      "Full Admin access to everything",
      "Read-only access to all databases",
      "No access at all"
    ],
    "answer": 0,
    "explanation": "Least Privilege reduces the 'blast radius' of a security breach by ensuring accounts only have the minimum access needed for their specific function."
  },
  {
    "id": 108,
    "difficulty": "hard",
    "category": "performance",
    "question": "What is 'Compaction' in a Log-Structured Merge (LSM) tree database like HBase?",
    "options": [
      "Shrinking the physical size of the server",
      "Merging small sorted files into larger ones to reduce read I/O",
      "Compressing the CPU cache",
      "Deleting old data"
    ],
    "answer": 1,
    "explanation": "Compaction in HBase (Major and Minor) cleans up deleted records and merges files to keep search performance efficient."
  },
  {
    "id": 109,
    "difficulty": "medium",
    "category": "analytics",
    "question": "What is a 'Metric Store'?",
    "options": [
      "A place to buy rulers",
      "A type of data warehouse",
      "A centralized repository for standardized business logic (e.g., 'Gross Margin')",
      "A folder for log files"
    ],
    "answer": 2,
    "explanation": "A Metric Store (or Semantic Layer) ensures that 'Revenue' is calculated the same way across every dashboard and application in the company."
  },
  {
    "id": 110,
    "difficulty": "hard",
    "category": "architecture",
    "question": "What is 'Data Gravity'?",
    "options": [
      "The cost of storage",
      "The speed at which data falls",
      "A physics experiment",
      "The concept that as datasets grow, they attract more applications and services to them"
    ],
    "answer": 3,
    "explanation": "Data Gravity implies that moving massive datasets is hard, so it's more efficient to move the 'compute' (applications) to the 'data'."
  },
  {
    "id": 111,
    "difficulty": "medium",
    "category": "no-sql",
    "question": "How does HBase optimize storage for 'Sparse' datasets compared to traditional RDBMS?",
    "options": [
      "By using advanced bitmask compression",
      "By storing all nulls in a separate metadata file",
      "By using a fixed-width row format",
      "By simply not storing null values or empty columns on disk"
    ],
    "answer": 3,
    "explanation": "HBase is designed for sparse data; if a row does not have a value for a specific column, no space is consumed, unlike RDBMS which often reserves space for null fields."
  },
  {
    "id": 112,
    "difficulty": "hard",
    "category": "architecture",
    "question": "In the CAP theorem, which two characteristics does HBase prioritize?",
    "options": [
      "Consistency and Availability (CA)",
      "Latency and Durability (LD)",
      "Availability and Partition Tolerance (AP)",
      "Consistency and Partition Tolerance (CP)"
    ],
    "answer": 3,
    "explanation": "HBase is a CP system, prioritizing strict data consistency over availability during certain network or node failures."
  },
  {
    "id": 113,
    "difficulty": "medium",
    "category": "data-modelling",
    "question": "Which HBase component must be defined at table creation time because it determines physical storage on disk?",
    "options": [
      "Timestamps",
      "Row Key Salts",
      "Column Qualifiers",
      "Column Families"
    ],
    "answer": 3,
    "explanation": "Column Families are logical groupings of related columns that must be defined upfront as they dictate how data is physically partitioned on the filesystem."
  },
  {
    "id": 114,
    "difficulty": "hard",
    "category": "performance",
    "question": "Why does HBase store Row Keys in lexicographical order?",
    "options": [
      "To make the data human-readable in HDFS",
      "To ensure data is encrypted alphabetically",
      "To optimize for range scans across related keys",
      "To prevent any duplicate keys from being written"
    ],
    "answer": 2,
    "explanation": "Lexicographical ordering allows HBase to perform highly efficient range scans, as logically related data (based on the key) is physically stored close together."
  },
  {
    "id": 115,
    "difficulty": "medium",
    "category": "no-sql",
    "question": "What functionality do 'Column Qualifiers' provide in an HBase schema?",
    "options": [
      "They act as flexible sub-labels that can be added dynamically without a predefined schema",
      "They define the data type of the row",
      "They are used to salt the row keys",
      "They determine the replication factor of the region"
    ],
    "answer": 0,
    "explanation": "Unlike Column Families, Column Qualifiers are flexible and can be added to any row at write-time, supporting a dynamic 'schema-on-write' approach."
  },
  {
    "id": 116,
    "difficulty": "hard",
    "category": "architecture",
    "question": "HBase achieves horizontal scalability by partitioning tables into which distributed units?",
    "options": [
      "Blocks",
      "Regions",
      "Shards",
      "Buckets"
    ],
    "answer": 1,
    "explanation": "HBase partitions tables into Regions, which are then distributed across a cluster of RegionServers to balance the load."
  },
  {
    "id": 117,
    "difficulty": "medium",
    "category": "no-sql",
    "question": "Which underlying storage system does HBase typically leverage for its data persistence?",
    "options": [
      "Local Linux EXT4 partitions",
      "Amazon S3",
      "In-memory Redis clusters",
      "Hadoop Distributed File System (HDFS)"
    ],
    "answer": 3,
    "explanation": "HBase is designed to run on top of HDFS, providing real-time random access to data that is physically stored in the Hadoop ecosystem."
  },
  {
    "id": 118,
    "difficulty": "hard",
    "category": "data-modelling",
    "question": "How does HBase handle multiple versions of the same cell (row/column intersection)?",
    "options": [
      "By creating a new Row Key for every change",
      "By using Timestamps to distinguish between different versions",
      "By overwriting the previous value immediately",
      "By storing changes in a separate delta-table"
    ],
    "answer": 1,
    "explanation": "HBase supports multi-versioning by assigning a timestamp to each cell, allowing the system to store and retrieve historical states of data."
  },
  {
    "id": 119,
    "difficulty": "medium",
    "category": "architecture",
    "question": "Which tool would a developer use to execute SQL-style queries against an HBase cluster?",
    "options": [
      "PrestoDB",
      "Apache Phoenix",
      "Apache Spark SQL",
      "Apache Hive"
    ],
    "answer": 1,
    "explanation": "Apache Phoenix provides a relational layer and JDBC driver, allowing users to query HBase using standard SQL syntax."
  },
  {
    "id": 120,
    "difficulty": "hard",
    "category": "data-engineering",
    "question": "HBase is primarily optimized for which type of workload?",
    "options": [
      "Write-heavy workloads with high-throughput",
      "Complex multi-table JOINs",
      "Ad-hoc reporting on unindexed columns",
      "Small datasets under 10GB"
    ],
    "answer": 0,
    "explanation": "HBase is optimized for massive volumes (billions of rows) and high-throughput, write-heavy workloads where random access is required."
  },
  {
    "id": 121,
    "difficulty": "hard",
    "category": "architecture",
    "question": "In HBase, what happens to data when a 'Delete' command is issued?",
    "options": [
      "The Row Key is renamed to 'deleted'",
      "The data is immediately erased from HDFS",
      "The RegionServer is rebooted",
      "A 'Tombstone' marker is written to the MemStore"
    ],
    "answer": 3,
    "explanation": "HBase uses an LSM-tree architecture. Deletes are handled by writing a 'Tombstone' marker; the data is only physically removed during a Major Compaction."
  },
  {
    "id": 122,
    "question": "As a Data Architect, you are designing a daily batch pipeline that joins a massive 10TB clickstream table with a 500GB user dimension table on 'user_id'. Both tables are frequently used in other downstream workloads. Which storage strategy yields the best architectural outcome for performance?",
    "options": [
      "Rely on Broadcast Joins by increasing the broadcast threshold to 600GB on the executors.",
      "Bucket both tables by 'user_id' with the same number of buckets during initial ingestion to enable collocated joins without shuffles.",
      "Keep both tables as standard Delta tables and let Spark's default sort-merge join handle the shuffle operations daily.",
      "Denormalize the data at the Bronze layer to eliminate the need for any Silver layer joins."
    ],
    "explanation": "For recurring joins between two massive tables on a consistent key, pre-bucketing both tables on that key ('user_id') with the exact same number of buckets eliminates the shuffle step during joins. This is much more reliable than trying to broadcast a massive 500GB table, which would likely cause Out Of Memory (OOM) errors.",
    "answer": 1,
    "difficulty": "hard"
  },
  {
    "id": 123,
    "question": "When designing a Delta Lake Medallion Architecture, a developer proposes Z-Ordering the Silver tables on 'ingestion_date' and Partitioning them by 'user_id'. Why might you reject this design as an Architect?",
    "options": [
      "You cannot combine Z-Ordering and Partitioning on Delta Lake; it's a hard engine limitation.",
      "Partitioning by high-cardinality columns like 'user_id' leads to a 'tiny file problem' and degrades metadata performance; 'user_id' is better suited for Z-Ordering instead.",
      "'Ingestion_date' is a low-cardinality column and is a perfect candidate for physical directory partitioning.",
      "Both B and C are correct."
    ],
    "explanation": "Partitioning should be reserved for low-cardinality columns (like a date or region) to avoid creating thousands of small directories/files. High-cardinality columns (like unique user IDs) are terrible for partitioning but are perfect for Z-Ordering, which arranges data efficiently within the files themselves without metadata bloat.",
    "answer": 3,
    "difficulty": "hard"
  },
  {
    "id": 124,
    "question": "A financial organization is migrating on-premises Hadoop workloads to Databricks. They require strict ACID compliance and the ability to time-travel back to data states from 30 days ago. Which combination should you recommend as the Architect?",
    "options": [
      "Standard RDD structures written directly to AWS S3 buckets to maintain control over execution.",
      "Parquet format with external custom checkpointing logic.",
      "Delta Lake tables with a VACUUM retention period set to at least 30 days.",
      "Delta Lake tables with an aggressive daily VACUUM to keep storage costs low."
    ],
    "explanation": "Delta Lake natively supports ACID transactions and Time Travel out of the box. However, running a VACUUM command deletes old data files no longer referenced by the current transaction log. To look back 30 days, the VACUUM retention period must be configured to retain at least 30 days of history, otherwise, time travel will fail for those older states.",
    "answer": 2,
    "difficulty": "hard"
  },
  {
    "id": 125,
    "difficulty": "medium",
    "category": "architecture",
    "question": "A Data Architect is designing a processing pipeline for unstructured data streams (such as video or raw text) where schema enforcement is not required. Which Spark core construct does the material recommend for this specific scenario?",
    "options": [
      "Resilient Distributed Datasets (RDDs)",
      "Datasets",
      "DataFrames",
      "Spark SQL Tables"
    ],
    "answer": 0,
    "explanation": "According to the reading material, RDDs are useful in scenarios handling unstructured data and where strict schema enforcement isn’t necessary."
  },
  {
    "id": 126,
    "difficulty": "hard",
    "category": "performance",
    "question": "To optimize a complex join between two enormous tables where broadcasting is not feasible due to cluster memory limits, which technique can Spark leverage to filter out non-matching rows early and reduce the volume of shuffled data?",
    "options": [
      "Bloom Filter Joins",
      "Vectorized Python Joins",
      "Cartesian Product Joins",
      "Broadcast Hash Joins"
    ],
    "answer": 0,
    "explanation": "The material outlines that Spark can employ Bloom filters to reduce shuffled rows during joins by filtering out non-matching rows early when broadcasting isn't feasible."
  },
  {
    "id": 127,
    "difficulty": "medium",
    "category": "performance",
    "question": "A Data Architect is analyzing storage levels to balance memory footprints against read efficiency. If they choose 'MEMORY_ONLY_SER' for dataset persistence, what is the primary architectural trade-off highlighted?",
    "options": [
      "It writes all overflow partitions directly to hard disks",
      "It makes data faster to read but occupies twice as much JVM heap space",
      "It limits the execution to Scala tasks only",
      "It is more space-efficient than storing deserialized objects but becomes more CPU-intensive to read"
    ],
    "answer": 3,
    "explanation": "According to the material, 'MEMORY_ONLY_SER' is generally more space-efficient than deserialized objects, but it is more CPU-intensive to read because of serialization overhead."
  },
  {
    "id": 128,
    "difficulty": "medium",
    "category": "performance",
    "question": "Why is Columnar Storage efficient for analytics?",
    "options": [
      "It speeds OLTP row updates",
      "It stores whole rows together",
      "Queries read only required columns and benefit from compression and vectorized scans",
      "It avoids compression"
    ],
    "answer": 2,
    "explanation": "Columnar Storage: formats such as Parquet and ORC reduce I/O for aggregates over few columns."
  }
];

// --- TOP 100 INTERVIEW INDICES ---
// These indices point to unique, high-value questions from the bank for rapid interview prep.
// Note: As the bank currently has 70 questions, all are prioritized for complete domain coverage.
const hotsQuestions = [
    // Core Architecture & Modeling (Indices 0-19)
    0, 1, 2, 3, 4, 5, 6, 7, 8, 9,           // DW Goals, Cloud Scalability, Kimball, Star Schema, Grain, SCD Type 2, CDC, Lakehouse
    10, 11, 12, 13, 14, 15, 16, 17, 18, 19, // Streaming, Semantic Layer, Lineage, RBAC, Feature Stores, Partitioning, Data Fabric, Data Vault

    // Advanced Patterns & Medallion (Indices 20-39)
    20, 21, 22, 23, 24, 25, 26, 27, 28, 29, // Silver Layer, Active Metadata, Event-Driven, Conformed Dimensions, Training-Serving Skew
    30, 31, 32, 33, 34, 35, 36, 37, 38, 39, // Customer 360, Data Catalog, Columnar Storage, Vertical vs Horizontal Scaling, Gold Layer

    // Performance & Governance (Indices 40-59)
    40, 41, 42, 43, 44, 45, 46, 47, 48, 49, // Impact Analysis, Partition Pruning, Virtualization, Kafka, Headless BI, Parquet, Identity Resolution
    50, 51, 52, 53, 54, 55, 56, 57, 58, 59, // Offline Feature Stores, Backpressure, Activity Schema, Data Skew, Semantic Gap, Column-based

    // Specialized Scale & Strategy (Indices 60-69)
    60, 61, 62, 63, 64, 65, 66, 67, 68, 69,  // Data Mesh, OLAP, Hubs, Data Stewards, S3/ADLS, Windowing, Cube/dbt, Z-Order, Petabyte Scale

    // Advanced data architecture - migration and modernization 
    70, 71, 72, 73, 74, 75, 76, 77, 78, 79,
    80, 81, 82, 83, 84, 85, 86, 87, 88, 89,
    90, 91, 92, 93, 94, 95, 96, 97, 98, 99,
    100, 101, 102, 103, 104, 105, 106, 107, 108, 109,
    // Hbase questions 
    110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120,
    // Spark Performance 
    121, 122, 123, 124, 125, 126,
];
