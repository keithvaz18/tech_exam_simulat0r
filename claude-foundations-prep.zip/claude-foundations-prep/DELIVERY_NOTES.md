# Claude Foundations Exam Simulator Update

## Included
- `js/questionBank_claude_developer.js` — 150 CCDV-F practice questions and 100 weighted priority indices.
- `js/questionBank_claude_architect.js` — 150 CCAR-F practice questions and 100 weighted priority indices.
- `exam.html` — updated only the two Claude exam-bank script paths to load the exact filenames above.
- `assets/claude_developer_detailed_one_pager.png`
- `assets/claude_architect_detailed_one_pager.png`
- Both certification-specific readmes.

## Integration
Replace the corresponding files in the existing simulator:
1. Copy both files from `js/` into the simulator's `js/` directory.
2. Replace the simulator's `exam.html` with this version, or apply the two Claude path changes from its `examMap`.
3. Put both PNGs in the simulator's `assets/` directory.

The existing `index.html` was intentionally not changed, so its exam dropdown, word clouds, and domain styling remain intact. The bank category strings preserve the existing Claude-specific taxonomy used by the simulator.

## Validation performed
- Both banks execute as JavaScript without syntax errors.
- Each bank has exactly 150 sequentially numbered questions.
- Every question has four options, a valid answer index, a category, and an explanation.
- Each `hotsQuestions` list has exactly 100 unique, in-range zero-based indices.
- Hot 100 category allocations follow the official exam blueprint weights.
- The exam map points to the new exact filenames.

## Exam facts
The 150-question banks are practice material, not the official live exam length. The supplied guides state 53 items for CCDV-F and 60 items for CCAR-F; both have a 120-minute time limit and scaled passing score of 720/1000. CCAR-F draws four scenarios from a bank of six.
