# Checkpoint 2 - changes so far
## Cloud / engine fixes (unchanged from checkpoint 1)
- index.html: renderCloud normalises all keyword schemas (freq 1-5, freq 1-10, weight, domain/class, missing desc); 12 missing domain colour classes added; Web3 legend uses wb-* classes.
- js/examEngine.js: Top-100 mode resolves hotsQuestions by question id (was array index, off by one in 1-based banks); keyword focus has a token-AND fallback.
## Question banks (new in checkpoint 2) - every cloud keyword now has >= 2 matching questions
- questionBank_claude_architect.js: 150 -> 211 (+61)
- questionBank_claude_developer.js: 150 -> 195 (+45)
- questionBank_Java.js: 400 -> 443 (+43; ids 401-443)
New entries sit under the marker comment "Keyword-coverage additions" at the end of each questionBank array.

## Checkpoint 4 - Top-100 lists repaired
- devOps: hotsQuestions 3 -> 100 valid ids; sql: 57 -> 100 valid (list pointed at ids up to 400 in a 261-question bank); ai: 96 -> 100.
- 11 more banks had one stale id each (99/100 valid); each topped up with the hardest unlisted question. All 21 banks with Top-100 now resolve >= 100 ids.
- Fix scripts: fixhots.js (rebuild), topup.js (append filler).

## Checkpoint 5 - clouds for every exam
- New clouds (index.html): python_pySpark, sql, nodejs, JavaScript, dotnet, ai_arch, hl7. ai_data now has its own array (saAiDataKeywords); it previously showed the Data Architect list.
- Every displayed keyword has >= 2 matching questions in its bank; frequency (size) is derived from the keyword's real match count.
- +77 questions for essential terms that were under-covered: ai_data +15, python +11, JavaScript +11, HL7 +10, SQL +9, AI_Arch +8, dotnet +7, nodeJS +6 (e.g. Guardrails, Feature Store, Zero Trust, Big O, MERGE, CORS, Debounce, CLR, SNOMED, HIPAA).
- Niche candidates with <2 matches were left out of the clouds (e.g. PM2, Metaclass, CSI, C-CDA, Data Mesh) rather than shown without support.
- Browser-tested (Chromium): all clouds render, tag click -> exam with focus filter, Top 100 toggle works, no page errors.

## Checkpoint 6 - reverse check on older clouds
- Mined each bank's most frequent technical terms and compared with its cloud; added bank-backed essentials (>=3 matching questions) to 13 clouds: databricks +9, ai +9, java +9, azure +9, aws +9, mongodb +5, react +8, snowflake +13, kafka +12, data_architect +6, devOps +3, typescript_nestjs +9, web3 +18 (e.g. Snowflake Streams/Tasks/Masking Policies, Azure Policy/Front Door, AWS Config/Direct Connect, React useMemo/useCallback, Kafka ISR/ACLs, Web3 Solidity/MEV/EVM).
- Sizes scaled to each array's own range (java 1-10, web3 weights). Entries marked "Reverse-check additions".
- Terms with <3 matches were skipped (e.g. Atlas Search, useRef, ETL, Mining) rather than shown unsupported.
- need.js: all 24 clouds below-bar 0.
## Still to do
Readmes for the 6 new clouds without a doc (sql, nodejs, JavaScript, dotnet, ai_arch, hl7); enterprise_architect cloud reverse check (bank text too generic for auto-mining); remaining 1-match niche terms (Medallion-type in ai_data).

## Checkpoint 7 - answer keys, option order, readmes
- Answer keys repaired in 7 banks: databricks 431-433, data_architect 122-124 (letter `correctAnswer`), snowflake 282-285 (string answers) and AWS 359 (array answer, rewritten as single-answer) are now integer `answer` indexes. They were unanswerable before (engine compares `answers[i] === q.answer`). React 17 empty option replaced; missing `difficulty` filled on 6 items; "A) " letter prefixes stripped from options.
- Option order re-randomised in 8,000+ questions (correct answer sat at position B 70-94% of the time in most banks); now ~25% per position in all 24 banks. Questions whose options/explanations refer to letters ("Both A and B", "Option C") were left in place.
- Verified on all 8,115 questions: correct-answer text unchanged, option sets unchanged, Top-100 lists still resolve. Browser test: all 24 exams score N/N when answering via the UI.
- Readmes added: sql, nodejs, JavaScript, dotnet, AI_Architecture, HL7 (every cloud keyword is covered in its readme); python_pySpark cloud now wired to python_test_readme.md.
- assets/: claude_architect_detailed_one_pager.png and claude_developer_detailed_one_pager.png added (readmes referenced them but assets/ was empty).
- Scripts: normalize.js, integrity.js, verify.js (audit_tools).
## Still to do
- Enterprise Architect cloud reverse check; remaining 1-match niche ai_data terms.
- Readme modal showed "Failed to load documentation" in the sandbox browser for every cloud (incl. pre-existing ones); investigating whether it is the sandbox (no CDN for marked.js) or a real bug.

## Checkpoint 8 - EA cloud + ai_data niche terms
- enterprise_architect cloud: +21 bank-backed terms (Risk, Vendor, Architecture Vision, Target Architecture, Baseline, Architecture Board/Repository/Contract, Building Block, Security Architecture, Disaster Recovery...). Ambiguous substrings (SSO, SLA, Vision, RPO) deliberately excluded.
- ai_data: +4 questions (Photon x2, Data Lineage x2; ids 236-239) and both terms added to the cloud.
- All 24 clouds: every keyword has >= 2 matching questions under the engine's focus filter.
- Readme markdown rendering needs the marked.js CDN (not reachable in the sandbox); doc files themselves all fetch OK.
## Still to do
- Nothing blocking. Optional: fact-check pass on individual question content; the python/TypeScript "dupOpt" audit flags are case-only false positives.

## Checkpoint 9 - duplicates + strict cloud coverage
- Removed 32 true duplicate questions (same question text AND same correct-answer text): mongoDB 20, snowflake 2, typescript_nestjs 2, AI_Arch 1, Azure 1, web3 1; deleted ids were remapped inside each Top-100 list and topped up so every list resolves 100 ids.
- 58 further groups are paraphrases of the same concept with differently worded answers (not wrong keys); left in place.
- Strict cloud check (only text the engine filters on: question + category + explanation): databricks "Feature Store" had 0 matches and "Tungsten" 1 -> +4 questions (ids 449-452). All 24 clouds now: every keyword >= 2 matches.
- Full UI regression: all 24 exams, normal and Top-100 modes, N/N correct, no page errors.
- Scripts added to audit_tools: dups.js, dedupe.js, need.js, fix2.js.
