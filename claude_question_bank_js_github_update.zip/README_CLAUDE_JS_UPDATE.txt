Claude question-bank JavaScript update

Contents are repository-relative and should be extracted at the repository root.
The four files belong in the existing js/ directory.

Reviewed files:
- questionBank_claude_architect.js (211 questions)
- questionBank_claude_architect_professional.js (172 questions; cleaned repeated question wording and includes the 22 added questions)
- questionBank_claude_developer.js (195 questions)
- questionBank_claude_developer_professional.js (150 questions)

The architect professional bank is the only one that differs from the original baseline.
The other three are included unchanged for a complete Claude question-bank replacement set.
All four passed `node --check`; no adjacent repeated-sentence patterns were detected in their question text.
